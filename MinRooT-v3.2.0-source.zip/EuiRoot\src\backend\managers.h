#pragma once
// 四个 Root 管理器的配置表 + 安装 / 卸载 / 检测 / 启动 / 退群逻辑。
#include <functional>
#include <string>
#include <vector>

namespace backend {

enum class InstallState {
    Unknown,
    NotInstalled,
    Installing,
    Installed,
    Failed,
};

const char* stateLabel(InstallState state);
const char* stateKey(InstallState state);   // 用于 dirtyKey / 图标选择

struct ManagerInfo {
    // 字段顺序必须与 managers.cpp 的初始化列表一致
    std::string key;          // 内部 id
    std::string name;         // 显示名
    std::string description;  // 简介
    std::string package;      // Android 包名
    std::string version;      // 内置 APK 版本
    std::string apkFile;      // assets/apk 下的文件名
    std::string installerType;// APK / EXE / ZIP
    std::string url;          // 官网或下载页
    std::string github;       // GitHub 仓库
    std::string checkCommand; // 附加检测命令（空则跳过）
    std::string downloadUrl;  // APK 直链（release 资产），内置包缺失时用它在线下载
    std::string assetPattern; // 从 release JSON 里挑资产用的 apk 名模糊匹配
    // 同一管理器的其它包名别名（历史版本 / 社区改包）：第一个 primary 已在 package 里，
    // 这里只列额外候选，检测与退群时会逐个尝试。
    std::vector<std::string> aliases;
    // 兜底识别关键词：候选包名都查不到时，遍历设备全部包名找包含该关键词的包
    // （应对改包名/自定义构建，例如 7kimi 用 com.sevenk.core 而不是 com.7kimi.su）
    std::string searchHint;
};

const std::vector<ManagerInfo>& managers();
const ManagerInfo* findManager(const std::string& key);

struct CheckResult {
    InstallState state = InstallState::Unknown;
    std::string package;
    std::string version;
    std::string message;
    bool deviceReady = false;
};

struct DeviceInfo {
    bool ready = false;
    std::string serial;
    std::string model;
    std::string android;
    std::string kernel;
    std::string message;
};

// 主页用的设备详表。
// 一次 adb shell 把所有字段取回来（逐项 getprop 要十几次往返，冷启动两秒起）。
struct DeviceDetail {
    bool ready = false;
    std::string serial;
    std::string model;        // 设备名称
    std::string device;       // 设备代号
    std::string android;      // 安卓版本（含 API）
    std::string sdk;
    std::string buildId;      // 版本信息
    std::string kernel;       // 内核版本
    std::string buildDate;    // 构建日期
    std::string connection;   // USB / 无线
    std::string unlock;       // 解锁状态
    std::string abSlot;       // A/B 分区
    std::string cpuVendor;    // CPU 厂家
    std::string cpuModel;     // CPU 代号
    std::string cpuName;      // CPU 名称
    std::string osPlatform;   // 操作系统
    std::string selinux;      // Enforcing / Permissive
    int batteryLevel = -1;
    std::string batteryState;
    unsigned long long storageTotal = 0;
    unsigned long long storageUsed = 0;
    unsigned long long memoryTotal = 0;
    unsigned long long memoryUsed = 0;
    std::string error;
};

// 解析 assets 真实路径（onefile / exe 旁目录都可能）
std::string resourceRoot();
std::string adbPath();
std::string apkPath(const ManagerInfo& info);

// 下载目录：%LOCALAPPDATA%\SiliconRootTool\apk
std::string downloadDir();
// 内置 APK 是否可用
bool hasLocalApk(const ManagerInfo& info);
// 可用 APK 路径：优先内置，其次此前下载成功的副本
std::string resolveApk(const ManagerInfo& info, bool* isLocal = nullptr);
// 在线下载 APK（GitHub releases 直链 → 失败则查 API 挑资产）。
// progress 回调参数为已下载 / 总字节数，总长未知时为 0。
bool downloadApk(const ManagerInfo& info, std::string& log,
                 const std::function<void(unsigned long long, unsigned long long)>& progress);

// ---- 检查更新（v3.1）----
// 一次「检查更新」的结论。三个版本号都只用来显示，是否更新由 hasUpdate / newer 决定。
struct UpdateCheck {
    std::string key;              // 对应 ManagerInfo::key
    std::string name;
    bool installed = false;       // 手机上装了没有
    bool hasUpdate = false;       // 有更新可装（远端比「已装 + 内置」都新）
    bool ok = false;              // 这次查询本身成功（网络/仓库都通）
    std::string localVersion;     // 内置包版本（ManagerInfo::version）
    std::string installedVersion; // 手机上已装版本（未装时为空）
    std::string latestVersion;    // GitHub 上最新 release 的 tag，已去掉 v 前缀
    std::string latestUrl;        // 最新 release 里匹配 assetPattern 的 APK 直链
    std::string message;          // 给日志用的一句话
};

// 把 v3.3.1 / V3.3.1-32680 / 3.3.1-beta 这类串归一成可比较的数字段。
// 返回空 vector 表示无法解析。
std::vector<int> parseVersion(const std::string& raw);
// a 比 b 新返回 true。任一方解析失败时退化成字符串不等即视为更新。
bool versionNewer(const std::string& a, const std::string& b);

// 查某个管理器的最新 release：拿 tag 名 + 匹配 assetPattern 的 APK 直链。
// 走与 downloadApk 相同的多镜像通道，四条都失败才返回 false。
bool fetchLatestRelease(const ManagerInfo& info, std::string& tag, std::string& apkUrl,
                        std::string& err);

// adb 基础操作
DeviceInfo detectDevice();
// 主页用：一次 adb shell 取回全部设备字段。serial 留空则取第一台已授权设备。
DeviceDetail detectDeviceDetail(const std::string& serial = std::string());
// 所有处于 device 状态（已授权）的序列号
std::vector<std::string> listDeviceSerials();
// 快捷重启：system / fastboot / fastbootd / recovery / edl / sideload / shutdown
bool rebootInto(const std::string& serial, const std::string& target, std::string& log);
// 把设备详表写成 UTF-8 文本报告
bool saveDeviceReport(const DeviceDetail& detail, const std::string& path, std::string& log);
CheckResult checkManager(const ManagerInfo& info, const std::string& serial);
bool installManager(const ManagerInfo& info, const std::string& serial, std::string& log);
// 直接安装指定 APK（更新流程用：装刚下载到缓存的包，避免 resolveApk 又选回内置旧包）
bool installManagerFromFile(const ManagerInfo& info, const std::string& serial,
                            const std::string& path, std::string& log);
bool uninstallManager(const ManagerInfo& info, const std::string& serial, std::string& log);
bool launchManager(const ManagerInfo& info, const std::string& serial, std::string& log);
// 退群：停看门狗 + 强停管理器进程
bool leaveGroup(const std::string& serial, std::string& log);

// 重启 adb 服务：手机若还没授权过本机，会在这时弹出「允许 USB 调试吗」。
bool adbRestartServer(std::string& log);
// 重启手机（提权失败时自动用）
bool adbReboot(const std::string& serial, std::string& log);
// 探测临时 root：adb shell su -c id，命中 uid=0 即视为已 root
struct RootStatus {
    bool active = false;
    std::string detail;   // 供日志展示的一句话（形如 uid=0(root) context=u:r:ksu:s0）
};
RootStatus probeRoot(const std::string& serial);

// 提权工具
bool rootToolPreflight(std::string& log);
std::string rootToolCommand(const std::string& mode, const std::string& serial,
                            const std::string& managerPkg = std::string());
// 结束残留的提权工具实例（Neo10-Root.ps1 / ghostlock / gl-run.sh）。
// 脚本用 logs\driver.lock 的独占句柄做单实例锁：上次的窗口没关干净时，
// 新一次启动会被判定「已经有一个本工具在跑了」并直接退出（退出码 1）。
// 返回结束的进程数，-1 表示查询失败。
int killStaleRootTool(std::string& log);

} // namespace backend
