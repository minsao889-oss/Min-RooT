#pragma once
// 资源根目录解析 + 完整性校验
//
// 两种运行形态（按优先级）：
//   1) 原始形态（开发/自用）：exe 同级 assets/ 明文目录，不做校验
//   2) 锁定形态（发布/分发给他人）：
//        SiliconRootTool.exe + SiliconRootTool.dat（加密资源包）
//        明文 assets/ 不随包分发；缺失时从 .dat 解出到本机 runtime/ 缓存
//
// .dat 的每个文件都是 AES-256-GCM 独立加密（AAD = 相对路径），
// 一旦被改动，解密直接失败——改不了、也看不出明文内容。
#include <string>

namespace backend {

// 返回可用的资源根目录（绝对路径，不带尾部反斜杠）。
std::wstring ensureBundle();

// 退出时清理本进程解出来的临时副本；进程被强杀时由下次启动的 sweepStaleBundles 兜底。
void cleanupBundle();

// 删除 runtime/ 下不属于本进程的 bundle-* 残留
void sweepStaleBundles();

// ---- 解密后的临时资源目录（UTF-8，可能为空字符串）
std::string bundleDir();

// ---- 单文件读取（带内存缓存）。明文形态下就是普通文件读取。
bool readAsset(const std::string& relPath, std::string& out);

// 是否存在（明文目录 or 加密包索引）
bool assetExists(const std::string& relPath);

// 取外部进程可用的磁盘路径：明文形态返回原路径；加密形态先解密落盘再返回。
// 返回空字符串表示取不到。
std::string assetDiskPath(const std::string& relPath);

// ---- 完整性自检（只读，不改动任何文件）
struct IntegrityResult {
    bool locked = false;    // 是否处于加密包形态
    int total = 0;          // 包内文件数
    int checked = 0;        // 本次实际校验数
    int bad = 0;            // 解密/校验失败数
    std::string bundlePath; // .dat 完整路径
    std::string detail;     // 首条失败详情
};
IntegrityResult verifyBundle();

} // namespace backend
