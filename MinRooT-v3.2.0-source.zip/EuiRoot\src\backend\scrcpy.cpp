#include "backend/scrcpy.h"

#include "backend/assets.h"
#include "backend/managers.h"
#include "backend/process.h"
#include "backend/workspace.h"

#include <windows.h>

#include <cstdio>
#include <ctime>
#include <mutex>
#include <filesystem>
#include <string>

namespace backend {
namespace {

std::string joinPath(const std::string& dir, const std::string& name) {
    if (dir.empty()) return name;
    if (dir.back() == '\\' || dir.back() == '/') return dir + name;
    return dir + "\\" + name;
}

// 给命令行参数加引号（路径里可能有空格/中文）
std::string quote(const std::string& value) {
    if (value.find_first_of(" \t\"") == std::string::npos) return value;
    std::string out = "\"";
    for (char c : value) {
        if (c == '"') out += "\\\"";
        else out += c;
    }
    out += "\"";
    return out;
}

std::string ensureDir(const std::string& path) {
    std::error_code ec;
    std::filesystem::create_directories(std::filesystem::u8path(path), ec);
    return path;
}

}  // namespace

std::string scrcpyDir() {
    // 加密形态下由 assets 门面解密落盘后返回真实目录；明文形态等价于资源目录
    const std::string p = assets::pathForExternal("scrcpy/scrcpy.exe");
    if (!p.empty()) {
        const std::string::size_type pos = p.find_last_of("\\/");
        if (pos != std::string::npos) return p.substr(0, pos);
    }
    return joinPath(resourceRoot(), "scrcpy");
}

std::string scrcpyExePath() {
    const std::string p = assets::pathForExternal("scrcpy/scrcpy.exe");
    if (!p.empty()) return p;
    return joinPath(scrcpyDir(), "scrcpy.exe");
}

bool scrcpyAvailable() {
    std::error_code ec;
    if (!assets::exists("scrcpy/scrcpy.exe")) return false;
    // scrcpy.exe 依赖同目录一堆 DLL（avcodec/SDL3 等），必须全部落盘才能跑
    static std::once_flag once;
    std::call_once(once, [] {
        for (const char* dll : {"avcodec-63.dll", "avformat-63.dll", "avutil-61.dll",
                                "SDL3.dll", "AdbWinApi.dll", "AdbWinUsbApi.dll",
                                "libusb-1.0.dll", "swresample-7.dll", "scrcpy-server"}) {
            assets::pathForExternal(std::string("scrcpy/") + dll);
        }
    });
    return std::filesystem::exists(std::filesystem::u8path(scrcpyExePath()), ec);
}

std::string scrcpyVersion() {
    if (!scrcpyAvailable()) return "未找到 scrcpy";
    const ProcessResult r = run(widen(quote(scrcpyExePath()) + " --version"), 8000, true);
    if (!r.started) return "未知";
    // 首行形如：scrcpy 5.0.1 <https://github.com/Genymobile/scrcpy>
    std::string text = r.out;
    const size_t end = text.find('\n');
    if (end != std::string::npos) text = text.substr(0, end);
    while (!text.empty() && (text.back() == '\r' || text.back() == ' ')) text.pop_back();
    return text.empty() ? std::string("未知") : text;
}

std::string recordDir() {
    // 落在 exe 同级的 temp\record（不是 assets 里面），方便用户找
    return ensureDir(joinPath(joinPath(appDir(), "temp"), "record"));
}

std::string makeRecordPath() {
    std::time_t now = std::time(nullptr);
    std::tm local{};
    localtime_s(&local, &now);
    char name[96] = {};
    std::snprintf(name, sizeof(name), "mirror-%04d%02d%02d-%02d%02d%02d.mp4",
                  local.tm_year + 1900, local.tm_mon + 1, local.tm_mday,
                  local.tm_hour, local.tm_min, local.tm_sec);
    return joinPath(recordDir(), name);
}

std::string buildMirrorCommand(const std::string& serial, const MirrorOptions& opt) {
    std::string cmd = quote(scrcpyExePath());
    if (!serial.empty()) cmd += " -s " + quote(serial);
    cmd += " --window-title " + quote("Silicon Mirror" + (serial.empty() ? std::string()
                                                                        : " - " + serial));

    // 分辨率：0 = 原生，交给 scrcpy 不传 --max-size
    if (!opt.maxSize.empty() && opt.maxSize != "0") {
        cmd += " --max-size " + opt.maxSize;
    }
    // 码率
    if (!opt.bitRate.empty() && opt.bitRate != "0") {
        cmd += " -b " + opt.bitRate + "M";
    }
    if (!opt.audio) cmd += " --no-audio";
    if (!opt.mouseControl) cmd += " --no-control";
    if (opt.fullscreen) cmd += " --fullscreen";
    if (opt.record) {
        const std::string path = opt.recordPath.empty() ? makeRecordPath() : opt.recordPath;
        cmd += " --record " + quote(path);
    }
    // 保持屏幕常亮，避免投屏时手机自己息屏
    cmd += " --stay-awake";
    return cmd;
}

namespace {

BOOL CALLBACK enumCloseProc(HWND hwnd, LPARAM param) {
    DWORD pid = 0;
    GetWindowThreadProcessId(hwnd, &pid);
    if (!pid) return TRUE;

    // 只认 scrcpy.exe 的顶层窗口
    HANDLE proc = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
    if (!proc) return TRUE;
    wchar_t exe[MAX_PATH] = {};
    DWORD size = MAX_PATH;
    bool isScrcpy = false;
    if (QueryFullProcessImageNameW(proc, 0, exe, &size)) {
        const std::wstring path(exe);
        const size_t slash = path.find_last_of(L"\\/");
        const std::wstring name = slash == std::wstring::npos ? path : path.substr(slash + 1);
        isScrcpy = (_wcsicmp(name.c_str(), L"scrcpy.exe") == 0);
    }
    CloseHandle(proc);
    if (!isScrcpy) return TRUE;

    if (GetWindowTextLengthW(hwnd) <= 0) return TRUE;  // 跳过隐藏/无标题窗口
    PostMessageW(hwnd, WM_CLOSE, 0, 0);
    int* count = reinterpret_cast<int*>(param);
    if (count) *count += 1;
    return TRUE;
}

}  // namespace

int closeMirrorWindow() {
    int count = 0;
    EnumWindows(&enumCloseProc, reinterpret_cast<LPARAM>(&count));
    return count;
}

} // namespace backend
