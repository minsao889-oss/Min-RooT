@echo off
set "VSB=C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools"
call "%VSB%\VC\Auxiliary\Build\vcvars64.bat" >nul
set "CMAKE=%VSB%\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
"%CMAKE%" --build "C:\srtbuild" --parallel 8
