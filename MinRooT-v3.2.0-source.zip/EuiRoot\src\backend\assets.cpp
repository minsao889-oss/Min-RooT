#include "backend/assets.h"

#include "backend/bundle.h"

#include <windows.h>

#include <filesystem>
#include <fstream>

namespace backend {
namespace assets {
namespace {

bool fileExistsW(const std::wstring& path) {
    const DWORD attr = GetFileAttributesW(path.c_str());
    return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY) == 0;
}

std::wstring widenS(const std::string& s) {
    if (s.empty()) return std::wstring();
    const int len =
        MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), nullptr, 0);
    std::wstring out(static_cast<std::size_t>(len), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), out.data(), len);
    return out;
}

} // namespace

std::string normalize(const std::string& rel) {
    std::string out;
    out.reserve(rel.size());
    for (char c : rel) out.push_back(c == '\\' ? '/' : c);
    // 反复剥掉开头的 "./"、"assets/"
    for (;;) {
        if (out.rfind("./", 0) == 0) {
            out.erase(0, 2);
            continue;
        }
        if (out.rfind("assets/", 0) == 0) {
            out.erase(0, 7);
            continue;
        }
        if (!out.empty() && out.front() == '/') {
            out.erase(0, 1);
            continue;
        }
        break;
    }
    return out;
}

bool read(const std::string& rel, std::string& out) {
    return readAsset(normalize(rel), out);
}

bool exists(const std::string& rel) {
    return assetExists(normalize(rel));
}

std::string pathForExternal(const std::string& rel) {
    return assetDiskPath(normalize(rel));
}

std::string dirOf(const std::string& sub) {
    std::string base = bundleDir();
    const std::string clean = normalize(sub);
    return clean.empty() ? base : (base + "\\" + clean);
}

} // namespace assets
} // namespace backend
