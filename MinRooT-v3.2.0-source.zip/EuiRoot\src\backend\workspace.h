#pragma once
// 多文件运行形态的「工作区」支持：
//   程序目录/  ├─ SiliconRootTool.exe
//              ├─ assets/          (必需：字体、图标、APK、提权工具)
//              ├─ author.ini       (首次运行自动生成，作者信息与赞赏码路径)
//              ├─ logs/            (首次运行自动生成，按次写入 run-*.log)
//              ├─ temp/            (首次运行自动生成，缓存与临时文件)
//              └─ config.ini       (首次运行自动生成，窗口尺寸等)
#include <string>

namespace backend {

// exe 所在目录（不带结尾反斜杠）
std::string appDir();

// logs / temp / temp\cache 自动创建；返回 false 表示目录不可写
bool ensureWorkspace();

// 本次运行对应的日志文件（logs/run-YYYYMMDD-HHMMSS.log），未初始化时返回空
const std::string& sessionLogPath();

// 追加一行到会话日志：日期自动补，行内排版与界面一致
//   <YYYY-MM-DD> <HH:mm:ss>  [级别]  内容
// clock 由调用方（logLine）传入界面同一时刻的 HH:mm:ss，保证两边时间戳对得上。
void logToFile(const std::string& level, const std::string& clock, const std::string& text);

// 简易 INI 读取：文件/节/键不存在时返回 def
std::string readIni(const std::string& file, const std::string& section,
                    const std::string& key, const std::string& def);

// 写 ini 键值（保留其他内容；文件或节不存在时自动创建）
bool writeIni(const std::string& file, const std::string& section,
              const std::string& key, const std::string& value);

// 首次运行生成模板；已存在则不覆盖
void ensureAuthorIni();
void ensureAppIni();

std::string authorIniPath();
std::string appIniPath();

// 工具
bool fileExists(const std::string& path);
void openFolder(const std::string& path);
void openFile(const std::string& path);
bool copyTextToClipboard(const std::string& utf8);

} // namespace backend
