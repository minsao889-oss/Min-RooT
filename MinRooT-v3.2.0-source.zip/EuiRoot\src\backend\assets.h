#pragma once
// 资源（assets）访问的受控入口 —— 界面 / 后端一律走这里，不再拼 appDir()+\\assets。
//
// 效果：
//   · 锁定形态下资源全在加密包 SiliconRootTool.dat 里，磁盘上看不到明文；
//   · 图片、字体等小文件由本模块解密后交给渲染层 / GDI，落盘只发生在
//     adb / scrcpy 这类必须以文件路径喂给外部进程的场景（runtime\\bundle-<pid>）。
#include <string>

namespace backend {
namespace assets {

// 逻辑相对路径（"icon-navbar.png" / "scrcpy/scrcpy.exe" / "Neo10-Root.ps1"）
// 传入带前缀（"assets/..."、"assets\\..."）或已绝对化的路径，内部会归一化。

// 读到内存。失败返回 false。
bool read(const std::string& rel, std::string& out);

// 判断是否存在
bool exists(const std::string& rel);

// 取外部进程可用的磁盘路径。明文形态返回原路径；加密形态解密落盘到 runtime 缓存。
// 取不到返回空字符串。
std::string pathForExternal(const std::string& rel);

// 资源子目录（"roottool" / "scrcpy" / "about"），等价于旧 appDir()+\\assets+sub
std::string dirOf(const std::string& sub);

// 把逻辑相对路径归一化：去掉 "assets/" 前缀、正斜杠转反斜杠
std::string normalize(const std::string& rel);

} // namespace assets
} // namespace backend
