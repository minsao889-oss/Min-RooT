#include "backend/home_tools.h"

#include "backend/process.h"

#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

namespace backend {
namespace {

// 与 managers.cpp 里同名工具保持一致（那边在匿名命名空间，跨 TU 拿不到）
std::string trimCopy(const std::string& in) {
    size_t a = 0;
    size_t b = in.size();
    while (a < b && (in[a] == ' ' || in[a] == '\r' || in[a] == '\n' || in[a] == '\t')) ++a;
    while (b > a && (in[b - 1] == ' ' || in[b - 1] == '\r' || in[b - 1] == '\n' || in[b - 1] == '\t')) --b;
    return in.substr(a, b - a);
}

std::string lowerCopy(const std::string& in) {
    std::string out = in;
    for (char& c : out) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return out;
}

bool contains(const std::string& haystack, const char* needle) {
    return lowerCopy(haystack).find(needle) != std::string::npos;
}

std::string adbCmd(const std::string& serial, const std::string& args, unsigned int timeoutMs = 20000) {
    std::wstring cmd = L"\"" + widen(adbPath()) + L"\" ";
    if (!serial.empty()) cmd += L"-s \"" + widen(serial) + L"\" ";
    cmd += widen(args);
    const ProcessResult r = run(cmd, timeoutMs, true);
    return trimCopy(r.out);
}

// 从任意文本里挑出第一个 IPv4（排除 0.x / 127.x / 255.x 段）
std::string firstIPv4(const std::string& text) {
    for (size_t i = 0; i + 7 <= text.size(); ++i) {
        if (i > 0 && (std::isdigit(static_cast<unsigned char>(text[i - 1])) || text[i - 1] == '.')) continue;
        int parts[4] = {0, 0, 0, 0};
        size_t p = i;
        bool ok = true;
        for (int k = 0; k < 4; ++k) {
            int digits = 0;
            int value = 0;
            while (p < text.size() && std::isdigit(static_cast<unsigned char>(text[p])) && digits < 3) {
                value = value * 10 + (text[p] - '0');
                ++p;
                ++digits;
            }
            if (digits == 0 || value > 255) { ok = false; break; }
            parts[k] = value;
            if (k < 3) {
                if (p >= text.size() || text[p] != '.') { ok = false; break; }
                ++p;
            }
        }
        if (!ok) continue;
        if (parts[0] == 0 || parts[0] == 127 || parts[0] >= 255) continue;
        char buf[24];
        std::snprintf(buf, sizeof(buf), "%d.%d.%d.%d", parts[0], parts[1], parts[2], parts[3]);
        return std::string(buf);
    }
    return std::string();
}

} // namespace

// ------------------------------------------------------------------ 网络预检

bool probeTcpReachable(const std::string& ip, int port, int timeoutMs, std::string& failReason) {
    failReason.clear();
    if (ip.empty() || port <= 0) {
        failReason = "IP 或端口为空";
        return false;
    }

    // WSAStartup 是进程级引用计数，重复调用/重复清理都安全。
    WSADATA wsa{};
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        failReason = "Winsock 初始化失败";
        return false;
    }

    addrinfo hints{};
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    addrinfo* info = nullptr;
    const std::string portText = std::to_string(port);
    if (getaddrinfo(ip.c_str(), portText.c_str(), &hints, &info) != 0 || info == nullptr) {
        WSACleanup();
        failReason = "地址解析失败：" + ip;
        return false;
    }

    bool ok = false;
    std::string why = "连接超时";

    for (addrinfo* each = info; each != nullptr && !ok; each = each->ai_next) {
        SOCKET sock = ::socket(each->ai_family, each->ai_socktype, each->ai_protocol);
        if (sock == INVALID_SOCKET) continue;

        // 非阻塞 connect + select：这样超时精确到毫秒，且不会被系统默认 21 秒 SYN 重传拖住。
        u_long nonBlocking = 1;
        ioctlsocket(sock, FIONBIO, &nonBlocking);

        const int rc = ::connect(sock, each->ai_addr, static_cast<int>(each->ai_addrlen));
        if (rc == 0) {
            ok = true;
        } else if (WSAGetLastError() == WSAEWOULDBLOCK) {
            fd_set writable;
            FD_ZERO(&writable);
            FD_SET(sock, &writable);
            fd_set failed = writable;
            timeval tv{};
            tv.tv_sec = timeoutMs / 1000;
            tv.tv_usec = (timeoutMs % 1000) * 1000;
            const int ready = select(0, nullptr, &writable, &failed, &tv);
            if (ready > 0 && FD_ISSET(sock, &writable) && !FD_ISSET(sock, &failed)) {
                int soError = 0;
                int soLen = sizeof(soError);
                if (getsockopt(sock, SOL_SOCKET, SO_ERROR, reinterpret_cast<char*>(&soError), &soLen) == 0 &&
                    soError == 0) {
                    ok = true;
                } else {
                    why = "端口未监听或被拒（WSA " + std::to_string(soError) + "）";
                }
            } else if (ready == 0) {
                why = "连接超时（" + std::to_string(timeoutMs) + " ms 无响应，多半和手机不在同一网段）";
            } else {
                why = "连接被拒（端口没开）";
            }
        } else {
            const int err = WSAGetLastError();
            why = "连接失败（WSA " + std::to_string(err) + "）";
        }

        closesocket(sock);
    }

    freeaddrinfo(info);
    WSACleanup();

    if (!ok) failReason = why;
    return ok;
}

// ------------------------------------------------------------------ 无线调试

std::string deviceIpAddress(const std::string& serial) {
    if (serial.empty()) return std::string();
    if (serial.find(':') != std::string::npos) return serial.substr(0, serial.find(':'));

    // 1) wlan0（最常见的 Android WiFi 接口名）
    std::string ip = firstIPv4(adbCmd(serial, "shell ip -f inet addr show wlan0"));
    if (!ip.empty()) return ip;

    // 2) 默认路由的 src —— 有些 ROM 接口名是 wlan1 / eth0
    const std::string route = adbCmd(serial, "shell ip route");
    if (!route.empty()) {
        ip = firstIPv4(route);
        if (!ip.empty()) return ip;
    }

    // 3) hostname -I（部分厂商 ROM 提供）
    ip = firstIPv4(adbCmd(serial, "shell hostname -I"));
    if (!ip.empty()) return ip;

    // 4) 最后兜底：全量地址表
    return firstIPv4(adbCmd(serial, "shell ip -f inet addr"));
}

bool enableWirelessDebug(const std::string& serial, int port, const std::string& lanIp,
                         WirelessResult& result) {
    result = WirelessResult();
    if (port <= 0) port = 5555;
    result.port = port;
    if (serial.empty()) {
        result.message = "没有可用设备，先插上 USB 或点「连接设备」";
        return false;
    }

    // 已经是无线连接，直接认账
    if (serial.find(':') != std::string::npos) {
        result.ok = true;
        result.serial = serial;
        result.ip = serial.substr(0, serial.find(':'));
        result.message = "当前已是无线调试连接：" + serial;
        return true;
    }

    const std::string ip = lanIp.empty() ? deviceIpAddress(serial) : trimCopy(lanIp);
    if (ip.empty()) {
        result.message = "读不到手机的局域网 IP（手机没连 WiFi？）";
        return false;
    }
    result.ip = ip;

    // 关键顺序：先在电脑这一侧确认「能连到手机的 5555」这条路走不走得通，再决定要不要 tcpip。
    // 以前是反过来：先 tcpip 再 connect，手机和电脑不在同一网段时（比如电脑在 70.x，
    // 手机在 192.168.x），connect 必然失败，还要白等 6 次 × 20 秒，界面全程卡死。
    std::string probeReason;
    if (!probeTcpReachable(ip, port, 1200, probeReason)) {
        result.message = "电脑连不到手机 " + ip + ":" + std::to_string(port) + " —— " + probeReason +
                         "。请确认电脑和手机连的是同一个 WiFi/网段，或换用 USB 连接。";
        return false;
    }

    // adbd 在 TCP 上重开需要一瞬间，这一步本身就会断回显，给足 8 秒再往下走。
    const std::string tcpip = adbCmd(serial, "tcpip " + std::to_string(port), 8000);
    if (contains(tcpip, "no such device") || contains(tcpip, "device not found")) {
        result.message = "设备在切 tcpip 前掉线了：" + tcpip;
        return false;
    }

    // tcpip 之后 adbd 需要重新监听；等端口真的通了再 connect，避免无效重试。
    bool listening = false;
    for (int attempt = 0; attempt < 12 && !listening; ++attempt) {
        ::Sleep(400);
        listening = probeTcpReachable(ip, port, 800, probeReason);
    }
    if (!listening) {
        result.message = "已下发 tcpip " + std::to_string(port) + "，但 " + ip + ":" + std::to_string(port) +
                         " 迟迟没有监听 —— " + probeReason + "。可在手机「开发者选项」里确认无线调试开关，或检查 AP 隔离。";
        return false;
    }

    // 已经确认端口是开的，这里只需要一次短超时的 connect。
    const std::string target = ip + ":" + std::to_string(port);
    const std::string connectOut = adbCmd(std::string(), "connect " + target, 6000);
    if (!contains(connectOut, "connected to") && !contains(connectOut, "already connected")) {
        result.message = "无线连接失败：" + (connectOut.empty() ? std::string("adb connect 无回显") : connectOut);
        return false;
    }

    // 校验：adb devices 里真的出现 ip:port
    bool listed = false;
    for (int attempt = 0; attempt < 8 && !listed; ++attempt) {
        for (const std::string& each : listDeviceSerials()) {
            if (each == target) { listed = true; break; }
        }
        if (!listed) ::Sleep(300);
    }
    if (!listed) {
        result.message = "adb connect 回了成功但设备没进 adb devices（端口不通/被防火墙拦）";
        return false;
    }

    result.ok = true;
    result.serial = target;
    result.message = "无线调试已就绪：" + target + "（USB 可以拔了）";
    return true;
}

bool disableWirelessDebug(const std::string& serial, std::string& log) {
    if (serial.find(':') == std::string::npos) {
        log = "当前不是无线连接，无需断开";
        return true;
    }
    const std::string out = adbCmd(std::string(), "disconnect " + serial, 6000);
    log = "已断开 " + serial + (out.empty() ? std::string() : ("（" + out + "）"));
    return true;
}

// ------------------------------------------------------------------ A/B 槽位

bool switchSlot(const std::string& serial, bool active, SlotResult& result) {
    result = SlotResult();
    if (serial.empty()) {
        result.message = "没有可用设备";
        return false;
    }

    const std::string suffix = trimCopy(adbCmd(serial, "shell getprop ro.boot.slot_suffix"));
    if (suffix.empty()) {
        result.message = "这台设备不是 A/B 分区（读不到 ro.boot.slot_suffix）";
        return false;
    }
    result.current = suffix;
    result.other = (suffix == "_a") ? "_b" : "_a";
    result.active = (suffix == "_a") ? "A" : "B";

    if (!active) {
        result.message = "当前槽位 " + result.active + "（" + suffix + "），另一槽 " + result.other;
        return true;
    }

    const std::string out = adbCmd(serial, "shell bootctl set-active " + result.other);
    const bool denied = contains(out, "denied") || contains(out, "not found") ||
                        contains(out, "inaccessible") || contains(out, "error");
    result.bootControlOk = !denied;
    result.setActiveOk = !denied;

    if (denied) {
        result.message = "切换失败（bootctl 需要 root）：" + (out.empty() ? std::string("无输出") : out) +
                         " —— 可改用「重启到 Fastboot」后手工 --set-active" + result.other;
        return false;
    }

    result.message = "已把 " + result.other + " 设为下次启动槽位（重启后生效）";
    return true;
}

// ------------------------------------------------------------------ USB3 兼容

bool usb3Compat(const std::string& serial, bool checkOnly, Usb3Result& result) {
    result = Usb3Result();
    if (serial.empty()) {
        result.message = "没有可用设备";
        return false;
    }

    result.current = trimCopy(adbCmd(serial, "shell getprop sys.usb.config"));
    const std::string low = lowerCopy(result.current);
    result.adbUsb2 = low.find("adb") != std::string::npos && low.find("usb2") != std::string::npos;

    if (checkOnly) {
        result.ok = !result.adbUsb2;
        result.message = result.adbUsb2
            ? "检测到 adb 走的是 USB2 组合（sys.usb.config = " + result.current + "）"
            : "adb 未绑定 USB2（sys.usb.config = " +
                  (result.current.empty() ? std::string("空") : result.current) + "）";
        return result.ok;
    }

    if (!result.adbUsb2) {
        result.ok = true;
        result.message = "当前不是 USB2 组合，无需打补丁（" + result.current + "）";
        return true;
    }

    // 不同厂商的 fragment 名不一样，逐个试；成功判据是「回读里没有 usb2」
    const char* candidates[] = {"mtp,adb", "ptp,adb", "mtp,adb,usb3"};
    for (const char* want : candidates) {
        adbCmd(serial, (std::string("shell setprop sys.usb.config ") + want).c_str());
        ::Sleep(1200);
        const std::string now = trimCopy(adbCmd(serial, "shell getprop sys.usb.config"));
        if (!now.empty() && lowerCopy(now).find("usb2") == std::string::npos) {
            result.ok = true;
            result.current = now;
            result.message = "已切到 " + now + "（USB3 组合，拔插一次数据线更稳）";
            return true;
        }
    }

    result.message = "sys.usb.config 被 ROM 锁死（" + result.current +
                     "），需要在工程模式里手动选「USB3.0」，或换支持 USB3 的数据线/接口";
    return false;
}

// ------------------------------------------------------------------ 保活 / 清理

bool keepScreenOn(const std::string& serial, bool on, std::string& log) {
    if (serial.empty()) {
        log = "没有可用设备";
        return false;
    }
    const std::string out = adbCmd(serial, std::string("shell svc power stayon ") + (on ? "true" : "false"));
    if (!out.empty() && contains(out, "error")) {
        const std::string backup = adbCmd(
            serial, std::string("shell settings put global stay_on_while_plugged_in ") + (on ? "7" : "0"));
        log = backup.empty() ? (on ? "已开启充电时保持亮屏" : "已关闭保持亮屏") : ("设置失败：" + out);
        return backup.empty();
    }
    log = on ? "已开启充电时保持亮屏" : "已关闭保持亮屏";
    return true;
}

int cleanTempFiles(const std::string& serial, std::string& log) {
    if (serial.empty()) {
        log = "没有可用设备";
        return 0;
    }
    // 只清本工具自己产的：/sdcard/siliconroot 与 ghostlock / ksud 的日志残留
    const std::string script =
        "n=0; for f in /sdcard/siliconroot/* /data/local/tmp/gl-*.log "
        "/data/local/tmp/.ghostlock_ksu.log; do if [ -e \"$f\" ]; then rm -rf \"$f\"; n=$((n+1)); fi; done; "
        "echo CLEANED:$n";
    const std::string out = adbCmd(serial, "shell \"" + script + "\"", 30000);
    const size_t mark = out.find("CLEANED:");
    if (mark != std::string::npos) {
        const int count = std::atoi(out.c_str() + mark + 8);
        log = "已清理设备端临时文件 " + std::to_string(count) + " 项";
        return count;
    }
    log = out.empty() ? "清理无回显（可能本来就没有临时文件）" : ("清理回显异常：" + out);
    return 0;
}

// ------------------------------------------------------------------ 多设备

std::vector<SerialItem> listDeviceSerialItems() {
    std::vector<SerialItem> out;
    const ProcessResult r = run(L"\"" + widen(adbPath()) + L"\" devices -l", 8000, true);
    if (!r.started) return out;

    size_t pos = 0;
    while (pos < r.out.size()) {
        const size_t eol = r.out.find('\n', pos);
        const std::string line = trimCopy(r.out.substr(pos, eol == std::string::npos ? std::string::npos : eol - pos));
        pos = (eol == std::string::npos) ? r.out.size() : eol + 1;
        if (line.empty() || line.rfind("List of devices", 0) == 0 || line.rfind("*", 0) == 0) continue;

        SerialItem item;
        const size_t tab = line.find_first_of(" \t");
        if (tab == std::string::npos) continue;
        item.serial = line.substr(0, tab);
        const std::string rest = trimCopy(line.substr(tab));
        const size_t sp = rest.find_first_of(" \t");
        item.state = (sp == std::string::npos) ? rest : rest.substr(0, sp);

        // devices -l 的 model:Pixel_7 —— 取 model，下划线换空格
        const size_t m = rest.find("model:");
        if (m != std::string::npos) {
            size_t e = rest.find_first_of(" \t", m);
            item.model = rest.substr(m + 6, e == std::string::npos ? std::string::npos : e - m - 6);
            std::replace(item.model.begin(), item.model.end(), '_', ' ');
        }
        out.push_back(item);
    }
    return out;
}

} // namespace backend
