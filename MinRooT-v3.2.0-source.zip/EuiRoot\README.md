﻿# Min RooT v3.1（多文件版）

> **这一页是 GitHub 首页。** 想直接下载开箱即用的版本 → 点右侧 **Releases** 下载 `SiliconRootTool-v3.4.0.zip`（解压即用，不需要编译）。
>
> - 界面：全部基于 [EUI-NEO](https://github.com/sudoevolve/EUI-NEO)（C++17 / GLFW + OpenGL）自绘，含液态玻璃组件（按钮 / 卡片 / 切换条 / 开关）
> - 仓库里只放源码与文档；`assets` 下的第三方二进制（adb / scrcpy / ksud）与运行期目录不入库，都在 Release 包里
> - 构建：`cmake -S . -B build -G Ninja` 然后 `cmake --build build`（需要 VS2022 + 支持 OpenGL 3.3 的显卡驱动）
> - 许可证：本项目代码 MIT（见 [LICENSE](LICENSE)），`third_party/` 各库保留原有许可证

![home](docs/screenshots/01-home-light.png)



Windows 桌面工具：四个 Root 管理器的选择 / 安装 / 状态检测，通过检测后才允许调用提权工具。
界面完全使用 [EUI-NEO](https://github.com/sudoevolve/EUI-NEO)（C++17 / GLFW + OpenGL）原生组件构建。

**这一版是多文件形态**：`SiliconRootTool.exe` + `assets\`（APK 与提权脚本）+ `author.ini` + `config.ini`，
首次运行自动生成 `logs\` 与 `temp\`。exe 需要和 `assets\` 在同一目录，删掉 assets 会提示资源缺失。

**v3.0 重点**：日志面板新增 **清屏 / 导出 / 收起** 三件套（提权页与管理器页共用），
收起后页面自动重新排版，省下来的高度不会留白。

**v3.1 重点**：管理器页新增 **检查更新** —— 一次点出四个管理器哪些有新版，弹确认框逐条列「现版本 → 上游版本」，确认后自动下载 + 覆盖安装。顺带修掉了自动下载卡死、日志只剩一句「请求 ghproxy.net 失败」的老问题。

> 仅限在本人拥有并授权的设备上使用。

---

## 1. 目录结构

```
SiliconRootTool/            ← 解压后的运行目录（可直接拷贝到任意路径）
├── SiliconRootTool.exe     主程序（2.17 MB，静态链接 MSVC 运行时）
├── author.ini              「关于作者」页的全部内容：昵称/QQ/群/邮箱/主页/赞赏码路径
├── config.ini              窗口尺寸、上次选中管理器、上次停留页面（程序自动写回）
├── assets/
│   ├── apk/                四个管理器 APK（KernelSU / Next / SukiSU / 7kimi SU）
│   ├── roottool/           Neo10-Root 提权工具全套（Neo10-Root.ps1、adb.exe、ksud…）
│   ├── scrcpy/             scrcpy 5.0.1 投屏全套（adb.exe、scrcpy.exe、scrcpy-server）
│   ├── about/              头像与赞赏码占位图（avatar.png / alipay.png / wechat.png）
│   ├── icon.ico            应用图标（多尺寸 ICO，exe 资源 / 任务栏 / 托盘共用）
│   ├── icon.png            应用图标 PNG 256×256（品牌蓝圆角底 + 白 M + 橙菱形）
│   ├── icon.svg            同图标的 SVG（内嵌 PNG，供按矢量引用的场合）
│   ├── icon-navbar.png     左侧导航栏品牌位 96×96（屏幕可见 48×48）
│   ├── icon-about.png      关于作者页头像占位 128×128
│   ├── icon-dark.png       窗口图标：深色主题用（透明底白色 M）
│   ├── icon-light.png      窗口图标：浅色主题用（透明底深色 M）
│   ├── icon-window-dark.ico  深色主题窗口图标（多尺寸 ICO，运行时 WM_SETICON）
│   ├── icon-window-light.ico 浅色主题窗口图标（多尺寸 ICO）
│   └── *.ttf / *.otf       界面中文字体与 Font Awesome 图标字体
├── logs/                   运行日志，每次启动一个 run-YYYYMMDD-HHMMSS.log（自动生成）
└── temp/                   临时目录，含 cache/（自动生成）
```

源码工程：

```
EuiRoot/
├── CMakeLists.txt
├── README.md                      项目说明（11 节）
├── 开发全记录.md                  完整开发记录（需求演进 / 原理 / 踩坑 / 验收）
├── author.ini                      author.ini 模板（构建时拷到输出目录）
├── src/
│   ├── main.cpp                    入口：DslAppConfig、导航四项、弹窗层、页面路由、右下角署名、退出写 config.ini
│   ├── app.h / app.cpp             全局状态、动作实现（监听/检测/安装/卸载/提权/重启/投屏）
│   ├── ui_theme.cpp                深浅双主题令牌、动效、状态色、日志缓冲（同时落盘）、窗口图标
│   ├── ui_widgets.cpp              统一按钮（自绘禁用态样式）
│   ├── pages_tool.cpp              提权页：前置校验 + 运行方式三卡 + 四按钮 + 运行日志 + 参数说明
│   ├── pages_managers.cpp          管理器页：2×2 紧凑卡片 + 详情 + 运行日志
│   ├── pages_about.cpp             关于作者页：作者信息 + 三列支持卡 + 项目信息 + 底部操作
│   ├── pages_mirror.cpp             安卓投屏页：状态卡 + 设置卡 + 四按钮 + 使用说明
│   ├── pages_log.cpp               可复用日志面板 composeLogPanel()
│   └── backend/
│       ├── process.h/.cpp          Win32 子进程封装（CreateProcess + 管道 + 超时 + 流式输出 + 可终止）
│       ├── scrcpy.h/.cpp           scrcpy 定位/版本/命令行拼装/录屏目录/优雅关窗
│       ├── workspace.h/.cpp        运行目录、会话日志、ini 读写、打开文件/目录、剪贴板
│       ├── managers.h/.cpp         四管理器配置表 + adb 检测/安装/卸载/启动 + 重启/root 探测 + 在线下载
│       ├── download.h/.cpp         WinHTTP 下载（含镜像与自建 DNS 解析）
│       └── bundle.h/.cpp           单文件模式的资源解压（多文件版已不再使用，保留供回退）
├── assets/                         与运行目录一致的资源（about / apk / roottool / scrcpy + 字体图标）
├── tools/
│   ├── make_icons.py               从 tools/icon-src/ 两张源图生成上表全部图标（含 SVG / ICO）
│   └── update_managers.py          从 GitHub 官方 Release 更新四个管理器 APK 并回写 managers.cpp
├── third_party/EUI-NEO/            上游框架（Apache-2.0，含 bundled 3rd 依赖，可离线构建）
└── build/                          构建产物
```

---

## 2. 五个页面

| 导航 | 页面内容 |
|---|---|
| **主页** | 设备信息卡（状态/A-B分区/连接类型/CPU 厂商与代号/设备名称与代号/操作系统/SELinux/解锁状态/版本信息/内核版本）→ 电池状态条 → 存储与内存两个环形百分比 → 快捷重启九宫格（系统 / Fastboot / FastbootD / Recovery / 9008(EDL) / 刷新设备 + 「更多重启指令」下拉）→ 快捷工具（无线调试、切换槽位、设备检测、工具自检、多设备开关）→ 底部五条小字链接（保存设备信息 / 打开日志目录 / 全功能使用教程 / 连接指南 / USB3.0补丁） |
| **提权** | 前置校验卡（管理器 / 安装状态 / 已装版本 / **临时 root**）→ **运行方式三选一**（① 开机模式并重启 ② 已经重启过 ③ 不重启直接打）→ 未安装时的琥珀色拦截提示 → 四个等宽按钮（执行提权、重试提权、**检测root**、**重启设备**）→ 左下运行日志（可滚动，标题条带**清屏 / 导出 / 收起**）+ 右下说明 |
| **管理器** | 标题 + 2×2 紧凑卡片（名称 / 简介 / 包名·版本 / 右上状态徽章 / 左侧色条，选中蓝框）→ 左下详情（下载页、安装包、包名、检测方式、当前状态、已装版本、使用顺序、两行按钮）→ 右下运行日志 |
| **安卓投屏** | 状态卡（投屏运行中 / 设备就绪 / 未连接设备 + scrcpy 版本 + 录屏状态）→ 设置卡（分辨率 5 档 / 码率 5 档 / 音频转发 / 鼠标控制 / 录屏保存 / 启动即全屏）→ 四个按钮（启动投屏、停止投屏、录屏目录、scrcpy 目录）→ 使用说明 |
| **关于作者** | 作者卡（头像、昵称、身份、QQ/群/邮箱、签名、主页）→ 支持作者（支付宝赞赏、微信赞赏、其它支持方式三列）→ 项目信息 → 底部四个操作按钮 |

「关于作者」页与主页不放日志，日志只在提权页与管理器页，两处共用同一个 `composeLogPanel()`。

### 日志面板三件套（v3.0）

面板标题条右侧三个小按钮，两个页面的行为完全一致：

| 按钮 | 做什么 | 不做什么 |
|---|---|---|
| 清屏 | 清空内存里的日志行、滚动条归零、重新贴底 | **不删** `logs\run-*.log`；日志已空时按钮置灰，点了只提示「日志已经是空的了」 |
| 导出 | 把本次运行落盘的会话日志复制成 `logs\export-<tick>.log`，并打开 `logs\` 目录 | 不改动原 `run-*.log`，也不重复写 BOM |
| 收起 | 面板缩到 44px 标题条，标题显示「运行日志（已收起 · N 行）」，按钮变「展开」 | 不清日志、不停任务；后台日志照写，展开后自动滚到最新一行 |

**收起后页面会重新排版**：提权页的标题条横跨整行，正文区从横条下方重新开始，
左栏补一张「日志面板已收起」占位卡、右栏说明卡拉长到页面底部，
所以收起省下来的高度不会在页面中间留一块空白。

### 管理器检查更新（v3.1）

管理器页右下角「检查更新」按钮，点一次做三件事：

| 步骤 | 做什么 |
|---|---|
| 检测 | 对四个管理器分别查「手机已装版本」和「GitHub 上游最新 tag」 |
| 弹窗 | 有可更新项时弹确认框，正文逐条列 `名称 现版本 → 上游版本`，可以点「取消」 |
| 更新 | 确认后串行执行「下载最新安装包 → `adb install -r -d` 覆盖安装」，每步都写日志 |

三条要注意：

- **未安装的不算「更新」**：只报「未安装（上游最新 X）」，不进批量更新列表；
- **不再悄悄动**：v3.0 之前只有「安装包缺失」时才去下载，现在有新版会明确问一句；
- **更新期间会断 root**：覆盖安装后临时 root 需要回提权页重新打一次。

上游版本号来自 `GET https://api.github.com/repos/<owner>/<repo>/releases/latest` 的 `tag_name`，
去掉 `v` 前缀与非数字尾巴后再逐段比较，`3.4.2-spoofed` 这种非规范 tag 会退化成字符串比较。

### 安卓投屏（scrcpy）

- 投屏内核用的是官方 **scrcpy 5.0.1**（`assets\scrcpy\`，25 MB，含 `scrcpy.exe`、`scrcpy-server`、SDL3 / FFmpeg 运行库与自带的 `adb.exe`）。
  想升级直接把这个目录换成新版解压结果即可，程序只认 `assets\scrcpy\scrcpy.exe`。
- 命令行由 `backend::buildMirrorCommand()` 拼：

  ```
  <dir>\scrcpy.exe -s <serial> --window-title "Silicon Mirror - <serial>"
                   [--max-size 1920|1280|1080|800]  (原生时不传)
                   [-b 4M|8M|16M|32M|64M]
                   [--no-audio] [--no-control] [--fullscreen]
                   [--record <temp\record\mirror-YYYYmmdd-HHmmss.mp4>]
                   --stay-awake
  ```

- 设置项即时写入 `config.ini` 的 `[mirror]` 段（`size` / `bitrate` / `audio` / `mouse` / `record` / `fullscreen`），重启恢复。
- **停止投屏不是杀进程**：`actionMirrorStop()` 先 `EnumWindows` 找 `scrcpy.exe` 的顶层窗口发 `WM_CLOSE`，
  让 scrcpy 自己退出并 flush 录屏（日志会打出 `Recording complete to mp4 file:`）；
  等 2 秒还没退才 `TerminateProcess`。强杀会让 mp4 的 moov 收尾不完整。
- 投屏进程通过 `backend::runStreaming(..., workDir=assets\scrcpy)` 启动：
  必须给工作目录，否则 scrcpy 找不到同级的 `scrcpy-server`。输出逐行进日志面板（`ERROR`/`WARN` 单独着色）。
- 关闭主窗口时 `onShutdown` 会 `cancelStreaming(mirrorTask)`，不留孤儿 scrcpy。
- 录屏落在 **exe 同级** `temp\record\`（不是 `assets` 里），「录屏目录」按钮直接打开它。


### 任务流程（v2.3）

1. 选管理器 → 安装 → 自动检测。
2. 选**运行方式**（① 开机模式并重启 / ② 已经重启过 / ③ 不重启直接打，默认 ③），
   选择立刻写进 `config.ini` 的 `[state] run_mode`，下次启动恢复。
3. 点 **执行提权** → 按所选模式跑 `Neo10-Root.ps1`（`-Mode Cold|Refire|Interactive`，
   其中 `Interactive` 自动追加 `-NoAutoReboot`，保证不会偷偷重启）。
4. 打完以 `adb shell su -c id` 的**实际结果**判定成功与否，而不是只看脚本退出码：
   - 拿到 `uid=0` → 日志 `[OK] 临时 root 已激活：…`，前置校验卡的「临时 root」变成 `已激活（临时）`；
   - 没拿到 → 日志 `[WARN] 本次未拿到 root（原因），自动重启手机…`，自动 `adb reboot`，等手机回连后可再点一次。
5. **检测root**：只读探测（`su -c id`），不改动设备任何状态。
6. **重启设备**：手动 `adb reboot`（带二次确认），重启后自动等回连并提示「临时 root 已随重启失效」。
7. 原来的「退群」「终止任务」已删除。

### 实时设备监听

- `startDeviceWatcher()`（`src/app.cpp`）在启动时起一个后台线程，**每 1.2 秒**跑一次 `adb devices`：
  插拔 USB、授权弹窗、手机关机/重启都会被自动发现，界面即时更新，**不需要手动刷新**。
- 变化时才写状态与日志，避免刷屏；连着的设备每 6 轮（≈7 秒）顺手探一次 `su -c id`，
  root 失效（比如手机重启过）会立刻反映到「临时 root」那一行。
- 侧栏底部固定显示**当前设备**：绿色圆点 + 「已连接设备」+ 序列号 + `型号 · Android 版本`；
  未连接时灰点 + 「未连接设备」+ 原因。
- 点侧栏最下方 **「连接设备」**（= 旧「检测设备」）会重启 adb 服务并等最多 7 秒回连——
  手机若还没授权，会**弹出「允许 USB 调试吗」**，点允许即可；点设备卡片效果相同。

---

## 3. 管理器配置表

配置集中在 `src/backend/managers.cpp` 的 `managers()` 静态表：

```cpp
struct ManagerInfo {
    std::string key;            // 内部 id：kernelsu / kernelsu_next / sukisu / 7kimisu
    std::string name;           // 显示名
    std::string description;    // 卡片简介
    std::string package;        // Android 包名（检测与卸载依据）
    std::string version;        // 内置 APK 版本
    std::string apkFile;        // assets/apk/ 下的文件名
    std::string installerType;  // APK
    std::string url;            // 官网 / 下载页
    std::string github;         // 仓库地址
    std::string checkCommand;   // 附加检测命令（可空）
    std::string downloadUrl;    // APK 直链（可空，空则走 GitHub Release API）
    std::string assetPattern;   // Release 资产名模糊匹配关键字
    std::vector<std::string> aliases;   // 额外候选包名（历史版本 / 社区改包）
    std::string searchHint;     // 兜底关键词：候选包名都查不到时，遍历全部包名找包含它的包
};
```

| key | 名称 | 包名 | 别名 / 兜底关键词 | 版本 | APK |
|---|---|---|---|---|---|
| `kernelsu` | KernelSU | `me.weishu.kernelsu` | `me.weishu.kernelsu.pr` / `weishu` | v3.3.1 | `KernelSU_v3.3.1.apk` |
| `kernelsu_next` | KernelSU Next | `com.rifsxd.ksunext` | `com.rifsxd.ksunext.debug` / `ksunext` | v3.4.2 | `KernelSU-Next_v3.4.2.apk` |
| `sukisu` | SukiSU | `com.sukisu.ultra` | `com.resukisu.resukisu` / `sukisu` | v4.2.1 | `SukiSU_v4.2.1.apk` |
| `7kimisu` | 7kimi SU | **`com.sevenk.core`** | `com.7kimi.su`、`com.sevenk.manager` / `sevenk` | v2.30 | `7kimisu_v2.30.apk` |

> 包名都是从 APK 里的 `AndroidManifest.xml` 实测出来的，不是猜的。
> 7kimi SU 的实际包名是 `com.sevenk.core`（启动 Activity `com.sevenk.core.ui.MainActivity`），
> 不是 `com.7kimi.su` —— 早期版本按后者查会一直显示「未安装」。

### 检测链（`checkManager()`）

四道依次回退，任一命中即判定已安装：

1. **候选包名**：`adb shell pm list packages <主包名>`，再依次试 `aliases` 里的别名
2. **关键词兜底**：候选全查不到时，拉一次 `pm list packages` 全量列表，找包含 `searchHint`
   的包（应对改包名 / 自定义构建）
3. **版本读取**：`adb shell dumpsys package <命中包名> | grep versionName`
4. **进程探测**：`adb shell ps -A | grep <命中包名>`（辅助判断，进程没跑仍算已安装）

结果映射到 `InstallState`：`Unknown / NotInstalled / Installing / Installed / Failed`，
界面文案「未检测 / 未安装 / 安装中 / 已安装 / 安装失败」，徽章配色灰 / 灰 / 琥珀 / 绿 / 红。
每次检测的结果细节（命中包名 / 未装原因 / 也查过哪些别名）都会写进日志，方便对不上时排查。

### 界面刷新（重要）

EUI-NEO 是「有变化才重绘」的即时模式框架：空闲时不会持续出帧。
所有在**后台线程**里改状态的地方（`logLine()`、`runBlocking()` 的收尾）都必须调用
`core::platform::requestUiUpdate()` 主动把渲染循环叫醒，否则界面会停在点击那一刻的样子 ——
表现为「明明装好了，检测按钮点完还是显示未安装」。
### 安装流程

优先用 `assets/apk/` 里的内置安装包，缺失时自动在线下载到 `%LOCALAPPDATA%\SiliconRootTool\apk\`：

1. `downloadUrl` 直链（若有）；
2. 否则读 `https://api.github.com/repos/<owner>/<repo>/releases/latest`，按 `assetPattern` 挑 `.apk` 资产；
3. 依次尝试直连、`gh-proxy.com`、`ghfast.top`、`ghproxy.net` 四个通道；
4. 下载后校验大小 ≥ 512 KB，防止拿到错误页。

随后 `adb install -r -d "<apk>"`，退出码 0 且输出含 `Success` 视为成功，立刻复检一次并写回版本号。超时 300 秒。

> **更新内置 APK 用 `tools/update_managers.py`，别手改。**
> 它会查 GitHub Release、按 `assetPattern` 挑资产、剔除 `-spoofed`/`debug` 之类的伪包、
> 解 APK 校验包名与版本、原子替换文件并回写 `managers.cpp`。详见 `开发全记录.md` 第 13 节。
> 日常用法：
>
> ```bat
> python tools\update_managers.py --check          :: 只看有没有新版
> python tools\update_managers.py --verify-only    :: 只校验现有 APK 与配置是否一致
> python tools\update_managers.py --apply          :: 下载 + 校验 + 落地 + 回写源码
> ```
>
> `--apply` 之后必须 `cmake --build build --target clean` 再全量重编，再跑 `deliver.py`。

---

## 4. 强制校验逻辑

**未检测到所选管理器安装成功，提权一律禁止。** 三处共同保证：

1. **按钮态**（`pages_tool.cpp` / `pages_managers.cpp`）
   `selectedInstalled()` 为假时，「执行提权 / 重试提权 / 卸载 / 打开管理器」渲染为禁用样式
   （灰底 + 低对比文字 + 不响应点击）。
2. **动作入口**（`app.cpp` 的 `actionElevate()` / `actionLeaveGroup()`）
   第一行再次判断 `selectedInstalled()`，为假则 `Popup::WarnNoManager` 并 `return`，
   弹出「尚未检测到所选管理器安装成功，提权已禁用」对话框。
3. **每次执行前实时复检**
   `actionElevate()` 内部先跑一次 `checkManager()`，避免界面状态过期。

> EUI-NEO 的 `ButtonBuilder::disabled()` 只拦点击事件、不改颜色，
> 因此 `src/ui_widgets.cpp` 的 `ui_button()` 自己换了整套 `ButtonStyle`
> （降透明度底色、淡文字、去边框与阴影），禁用态才有明确视觉反馈。

---

## 5. 提权工具封装

提权工具即 `assets/roottool/` 里的 Neo10-Root v2.1 正式版，通过子进程调用：

```
<pwsh.exe 优先，缺失才退回 powershell.exe> -NoProfile -NoLogo -ExecutionPolicy Bypass
    -File "<assets>\roottool\Neo10-Root.ps1"
    -Mode <Cold|Refire|Interactive|Status> -Profile auto -NoPause [-NoAutoReboot] [-Serial <设备序列号>]
```

**解释器选择**：与官方 `Neo10-Root.bat` 保持一致——先 `SearchPathW("pwsh.exe")`，再找
`%ProgramFiles%\PowerShell\7\pwsh.exe`，都没有才用 `powershell.exe`（Windows PowerShell 5.1）。
5.1 处理中文和长字符串拼接明显更慢，同一个脚本耗时更长，所以不要硬写 `powershell.exe`。

**输出必须实时回显**：`backend::runStreaming` 用自建管道 + `PeekNamedPipe` 循环，边读边按行回调，
每行立即 `logLine("DEBUG", ...)` 刷到界面（`logLine` 里会 `requestUiUpdate()` 触发重绘）。
早期版本用的是「等进程结束再一次性切行」，提权要跑几分钟，界面几分钟毫无动静，用户会以为卡死然后
重复点「执行提权」或直接关窗口，留下孤儿 `powershell.exe` + 设备端 `ghostlock`，
下一次运行就被单实例锁挡住报 `[FAIL] 已经有一个本工具在跑了`。

提权页顶部的「运行方式」三选一与脚本的 1 / 2 / 3 选项一一对应，选择即时写入
`config.ini` 的 `[state] run_mode`（不等退出才写，被强杀也不丢）：

| 界面卡片 | `-Mode` | 额外参数 | 脚本选项 | 说明 |
|---|---|---|---|---|
| ① 开机模式并重启 | `Cold` | — | 1 | 触发完整冷启动流程，成功后设备会重启，成功率最高 |
| ② 已经重启过 | `Refire` | — | 2 | 设备刚重启完，直接重新触发提权 |
| ③ 不重启直接打 | `Interactive` | **`-NoAutoReboot`** | 3 | 当前系统直接尝试，绝不主动重启（默认） |

实际命令行：

| 场景 | 实际命令行 |
|---|---|
| 执行提权 / 重试提权 | `-Mode <所选模式> -Profile auto -NoPause [-NoAutoReboot] [-Serial …] [-ManagerPkg …]` |
| 检测root | `-Mode Status -Profile auto -NoPause [-Serial …] [-ManagerPkg …]` |

⚠️ **`Interactive` 为什么必须带 `-NoAutoReboot`**：脚本的 `switch ($Mode)`（`Neo10-Root.ps1:1244`）只显式处理
`Status` / `Cold` / `Refire` 三个值，`Interactive` 落到 `default` 分支；而 `default` 在 `-NoPause` 下的行为是
「自动按 [1] 开飞行模式并重启」（`:1249-1252`）。也就是说：**不加 `-NoAutoReboot` 的 `-Mode Interactive`
等价于选项 1，会重启手机**。加上之后 `:1268 if ($NoAutoReboot) { $doReboot = $false }`、
`:1320 $rebootThis = ... -and -not $NoAutoReboot` 两道保险把它钉死成「绝不重启」。

那「失败自动重启手机」由谁负责？—— **由本程序负责**，不走脚本：
`actionRunTool()` 打完以 `probeRoot()` 的真实结果判定，没拿到 root 且 `rebootOnFail==true` 时调
`backend::adbReboot(serial, log)` 发 `adb reboot`，日志记
`[WARN] 本次未拿到 root（原因），自动重启手机，重启后可再执行一次`。
这样「脚本自己绝不乱重启」和「打不穿自动重启一次」两件事互不干扰（①②③ 都适用）。

| 界面按钮 | `-Mode` | 说明 |
|---|---|---|
| 执行提权 | 按所选运行方式 | 先触发 GhostLock 再 late-load 管理器自带 ksud；失败自动 `adb reboot` |
| 重试提权 | 按所选运行方式 | 人工再打一发（比如刚重启完） |
| 检测root | `Status` | 仅打印当前 root 状态后退出，不改动设备；随后本程序再跑一次 `su -c id` 校正 |
| 重启设备 | — | 二次确认后 `adb reboot`，最多等 90 秒回连，并提示临时 root 已失效 |

执行细节（`backend::process`）：

- `CreateProcessW` + `CREATE_NO_WINDOW` + 匿名管道，输出按行回传日志面板；
- 默认超时 180 秒，超时 `TerminateProcess`；
- `CP_ACP → CP_UTF8` 转码，保证 PowerShell 中文输出不乱码；
- 退出码写回界面，并提示「设备可能需要重启后再次提权」。

**前置检查**：`adb.exe` 存在、`Neo10-Root.ps1` 存在、`powershell.exe` 可调用，任一缺失即弹说明并终止。

### 残留实例自动清理（`backend::killStaleRootTool`）

`Neo10-Root.ps1:112` 用 `logs\driver.lock` 的**独占文件句柄**做单实例锁（`Neo10-Root.ps1:147 Acquire-DriverLock`，
注释里明确说不能靠 PID 判断，PID 会复用）。上一次点完「执行提权」直接关掉本程序、脚本进程还活着时，
下一次启动会直接打印：

```
[FAIL] 拒绝启动：避免把手机推进重启循环。
[FAIL] 已经有一个本工具在跑了（单实例锁被占用）。
```

并以退出码 1 结束——界面上只看到一个 `退出码 1`，很容易误判成提权失败。

所以每次 `actionRunTool()` 在 `rootToolPreflight()` 通过之后、真正启动脚本之前，会先调用
`backend::killStaleRootTool()`：用 `Get-CimInstance Win32_Process` 找出名字是 `powershell.exe` / `pwsh.exe` /
`cmd.exe` 且命令行里带 `Neo10-Root.ps1` 的进程，逐个 `Stop-Process -Force`，返回结束个数。
进程一退出，独占句柄随之释放，锁自然就没了，不需要手动删 `driver.lock`。

两条防呆：必须排除**当前这个查询进程自己**（`$_.ProcessId -ne $PID`，再加 `-notlike '*Get-CimInstance*'`、
`-notlike '*Stop-Process*'`），否则会把查询进程甚至宿主程序一起杀掉。清理成功时日志会写
`[WARN] 已结束 N 个残留实例（PID ...），单实例锁随之释放`。

---

## 6. 「关于作者」页怎么改

除头像与赞赏码以外，全部内容都在运行目录的 `author.ini` 里，保存后重启程序生效（无需重新编译）：

```ini
[author]
name=茗茗茗茗
role=独立开发者 · Android 折腾爱好者
slogan=做能用、好用、不烦人的工具
avatar=assets/about/avatar.png
qq=1241252612
qq_group=未填写
group_name=Min RooT 交流群
email=未填写
homepage=https://github.com/minsao889-oss/SiliconRootTool
project=https://github.com/minsao889-oss/SiliconRootTool

[donate]
alipay=assets/about/alipay.png
wechat=assets/about/wechat.png
note=如果这个工具帮你省了时间，可以请我喝杯咖啡 · 完全自愿

[app]
version=3.1.0
build=2026-10-20
license=仅供本人拥有并授权的设备使用
```

- 填了 QQ / 群号 / 邮箱才会显示，「未填写」会被自动隐藏；`homepage` 和 `project` 都填 GitHub 仓库地址，两个按钮都会打开同一个链接；
- 赞赏码：`assets/about/alipay.png`（支付宝）与 `wechat.png`（微信）已内置真实收款码，换成自己的截图即可，路径也可改成绝对路径；**点卡片在窗口内放大显示**（手机直接扫），不再调系统看图软件；
- 头像：替换 `assets/about/avatar.png`；
- 作者卡右上角中间那个按钮会自动适配：有群号就「复制 QQ 群号」，没有群号有 QQ 就「复制 QQ 号」，两者都没有则置灰；
- 页面内「编辑 author.ini」「打开赞赏码目录」按钮直接用系统默认程序打开。

---

## 7. 日志与配置

- **日志双写**：界面日志面板（实时）+ `logs\run-YYYYMMDD-HHMMSS.log`（UTF-8 BOM，带时间戳与级别）。
  内存里保留最近 800 条，面板最多渲染 400 行，过长行按像素宽度截断加省略号。
- **清屏 ≠ 删文件**：面板上的「清屏」只截断内存里的行；磁盘那份 `run-*.log` 一行不动，
  想留存就点「导出」另存成 `logs\export-<tick>.log`（同时会打开 `logs\` 目录）。
  两条路径分开是刻意的：后台线程随时可能在写这个文件，界面动作不该去抢同一个 fd。
- **配置持久化**：`config.ini` 关闭窗口时写回
  `[window] width/height/maximized`、`[state] last_manager/last_page/run_mode`，下次启动恢复。
- **主题持久化**：`[ui] theme = dark | light`，左上导航栏下方的「深色 / 浅色」分段切换，
  改完立刻重画并写回 ini，下次启动沿用。
- **路径全部相对 exe 目录**：`appDir()` 由 `GetModuleFileNameW` 推导，不写死任何盘符。

---

## 7.1 深浅双主题

界面上所有颜色都从 `theme()` 返回的令牌里取，切主题只是换一套令牌，不会重建窗口：

| 令牌 | 深色 | 浅色 |
|---|---|---|
| `background` | `#0E1014` | `#F5F7FA` |
| `primary` | `#3871E0` | `#3268D8` |
| `surface` | `#191C22` | `#FFFFFF` |
| `surfaceHover` / `surfaceActive` | `#23272F` / `#2E333D` | `#F0F3F7` / `#E5EAF1` |
| `text` | `#F1F4F9` | `#1B2028` |
| `border` | `#2E323B` | `#D7DDE6` |

配套的语义色也在 `ui_theme.cpp` 里按主题分支：`textMuted()` / `textFaint()` / `cardColor()` /
`mutedCardColor()` / `stateColor()` / `hoverTint()` / `pressedTint()` / `overlayTint()` /
`warnColor()` / `warnCardColor()` / `levelColor()`。

踩坑记录（改配色时最容易漏的）：
- 悬停/按压叠加色在深色主题下是**叠白**（`{1,1,1,0.028}`），浅色主题必须换成**叠黑**
  （`{0,0,0,0.035}`），否则浅色背景上完全看不出反馈。统一走 `hoverTint()` / `pressedTint()`。
- 日志级别色（OK 绿 / WARN 琥珀 / ERROR 红）在浅色背景上要加饱和度压亮度，
  直接用深色主题的那套会糊成一片。
- 窗口底色 `DslAppConfig::clearColor` 只在启动时读一次，所以它直接查 `config.ini` 的
  `[ui] theme`；运行时切换靠 `root.bg` 那层全屏矩形盖住，不影响。
- 赞赏码放大弹窗里的白底**必须固定白色**（`{1,1,1,1}`），二维码需要白色静区，
  跟着主题变深就扫不出来。
- **系统标题栏**用 DWM 单独刷（`applyTitlebarForTheme()`）：Win11 走 `DWMWA_CAPTION_COLOR(35)`
  / `DWMWA_TEXT_COLOR(36)` / `DWMWA_BORDER_COLOR(34)` 精确上色，老系统回落到
  `DWMWA_USE_IMMERSIVE_DARK_MODE`（20，早期为 19）。`dwmapi.dll` 靠 `GetProcAddress` 动态取，
  不增加链接依赖。注意 `setDarkTheme()` **不能**在「值未变」时 early-return ——
  `darkTheme` 默认就是 `true`，早退会让启动时第一次标题栏上色被跳过，表现为「首次切深色没反应」。

---

## 7.2 应用图标

图标由 `tools/make_icons.py` 从 `tools/icon-src/` 的两张 2048×2048 源图生成，一条命令全出：

```bat
python tools\make_icons.py
```

产物与用途：

| 文件 | 尺寸 | 用途 |
|---|---|---|
| `icon.ico` | 16/20/24/32/40/48/64/128/256 | exe 资源图标（任务栏、资源管理器、Alt+Tab） |
| `icon.png` | 256 | 品牌蓝圆角底 + 白 M + 橙菱形的正式图标 |
| `icon.svg` | 256 | 同图 SVG（内嵌 PNG），供按矢量引用的场合 |
| `icon-navbar.png` | 96（显示 48） | 左侧导航栏品牌位 |
| `icon-about.png` | 128 | 关于作者页无头像时的占位 |
| `icon-dark.png` / `icon-light.png` | 256 | 透明底单色 M，深/浅主题各一份 |
| `icon-window-dark.ico` / `-light.ico` | 多尺寸 | 窗口图标，运行时按主题 `WM_SETICON` |

几个必须知道的点：
- **源图右下角有「豆包AI生成」水印**（x 1683..2003, y 1934..2010）。整图 alpha bbox 会被水印
  拉到 2003×2010，直接缩放会得到一张几乎全空的图。脚本里 `WATERMARK_Y = 1880` 起强制清零。
- **exe 资源图标不能用 PNG 当源**：`rc.exe` 只认 ICO。而框架的
  `applyWindowIcon()` 用 `stbi_load` 读 `iconPath`，**stbi 不认 ICO** —— 所以
  `iconPath("assets/icon.ico")` 实际上被静默忽略，窗口图标是空的。本项目在 `onStart` 里
  自己发 `WM_SETICON` 补上，见 `ui_theme.cpp::applyWindowIconForTheme()`。
- **ICO 只写一档的坑**：Pillow 存 ICO 时 `sizes=` 会自己重采样每一档，
  **不能**再配 `append_images=` —— 两者一起用只会写进第一档（实测只剩 16×16）。
- 品牌位想换成位图，用 `components::navbar(...).brandImage("assets/icon-navbar.png")
  .brandImageSize(48.0f)`；不传 `brandImage` 时仍走原来的 Font Awesome 字体图标。

---

## 8. 构建步骤

### 环境要求

- Windows 10/11 x64
- Visual Studio 2022 Build Tools（`Microsoft.VisualStudio.Workload.VCTools` +
  `Microsoft.VisualStudio.Component.Windows11SDK.22621`）
- CMake 3.14+ 与 Ninja（Build Tools 自带）

### 构建

```bat
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat"
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel
```

产物：`build/SiliconRootTool.exe`（约 2.17 MB，`/MT` 静态运行时，无外部依赖），
POST_BUILD 自动把 `assets/` 与 `author.ini` 拷到 `build/`，直接运行 `build/SiliconRootTool.exe` 即可。

> ⚠️ 改过 `src/app.h`（例如给 `AppState` 增删字段）后**必须删掉 `build/` 全量重编**。
> Ninja 增量在头文件改动上曾留下旧 `.obj`，导致结构体布局不一致、界面显示空日志这类诡异现象。

> ⚠️ 编译前先关掉正在跑的 `SiliconRootTool.exe`，并 `Stop-Process adb`——POST_BUILD 要覆盖
> `build/assets/roottool/adb.exe`，被占用时 Ninja 会报 `Error copying directory …` 直接失败。

### 线程与状态锁（v2.3 新增）

EUI-NEO 的 `compose()` 在主线程逐帧读取 `AppState`，而**设备监听 / 提权工具输出 / adb 检测**
都在后台线程写同一份 `AppState`。v2.3 起统一用 `app::stateMutex()`（`std::recursive_mutex`）串行化：

- `compose()`、`composeTool/composeManagers/composeLogPanel`、`composeSidebarDevice` 入口整体持锁；
- 后台写点用 `setDevice()` / `setRootStatus()` 两个加锁 setter，或就地 `std::lock_guard` 包住赋值；
- `logLine()` 内部也走同一把锁（递归锁，可重入）。

否则会出现「杀掉 adb server / 拔线 → 进程直接消失」的 0xc0000005 访问违例
（`composeLogPanel` 读 `s.logs` 时正好被后台 `push_back` 触发 realloc）。

### 打包成 zip

把 `build/` 下这几项打成一个压缩包即可分发：

```
SiliconRootTool.exe
author.ini
assets/
logs/          （可空目录）
temp/          （可空目录）
```

`config.ini` 不必带，首次启动会自动生成。

---

### 性能与稳定性（v2.4 / v2.5 / v2.8 / v3.0 / v3.1）

- **所有跨线程状态读写都走 `stateMutex()` 递归锁**：设备监听线程（1.2 秒轮询）、提权工具流式输出线程、
  adb 检测线程与渲染线程并发访问 `AppState` 时不再有数据竞争；`compose*` 在函数入口整体持锁。
- **改 `src/app.h` 后必须全量重编**（`cmake --build build --target clean` 再 `--build`）：
  `AppState` 加了字段而只做增量编译时，旧 `.obj` 按旧布局读写，表现为启动即 `0xC0000005`。
  已踩过四次，写进本文档。
- **子进程输出全程流式**（`backend::runStreaming`）：提权脚本跑几分钟、投屏持续输出日志，
  界面都不会「静默卡死」；`backend::cancelStreaming(id)` 可按任务号终止。
- **idle 不重绘**：EUI-NEO 是即时模式 + 事件驱动，后台线程改完状态必须 `core::platform::requestUiUpdate()`，
  否则界面停在旧帧（表现为「明明装了却显示未安装」）。
- **投屏停止走 WM_CLOSE 而非强杀**，保证 mp4 收尾；关主窗口会顺带结束投屏进程，不留孤儿。
- 日志面板固定行高 22 px + `scrollView`，上限 400 行参与渲染（缓冲保留 800 行），
  行文本按像素宽度截断加省略号，长 adb / scrcpy 输出不会撑爆布局。
- **无线调试先预检再动手（v2.9 起）**：点「无线调试」时先用 winsock 探测 `手机IP:5555`（1200 ms 超时），
  不通就直接给出中文原因并返回，**不会**先把手机切进 `adb tcpip` 模式。
  早期版本是先 tcpip 再循环 `adb connect`，跨网段时界面会卡两分钟，且手机侧 USB 断了还没有回退通道。
- **不可撤销操作一律二次确认（v2.9 起）**：重启下拉一滑过就选中，旧代码直接执行。
  现在只登记 `pendingRebootTarget`，弹「确认重启到 Bootloader？」，点取消则什么都不发生。
- **日志三件套不再抢文件句柄（v3.0）**：清屏只动内存，导出用独立读写流复制一份，
  后台写 `run-*.log` 的线程不受影响。
- **更新检测不动设备（v3.1）**：检查更新只发两件只读请求（GitHub API + 本机 `pm list packages`），
  不装不卸不改任何东西；确认后才走下载与安装。
- **下载失败会给出全部通道的原因（v3.1）**：四档镜像（直连 / gh-proxy / ghfast / ghproxy.net）各自的
  错误与耗时都会拼进同一条日志，不再只剩最后一档的一句「请求 ghproxy.net 失败」。
- **安装包与设备检查解耦（v3.1）**：设备没连时安装会取消，但**已下载的安装包保留**，
  接上手机直接点「安装所选」即可，不用重下一遍。
## 9. 运行与测试

1. 解压到任意目录，双击 `SiliconRootTool.exe`。**建议以管理员身份运行**
   （日志里会标注「管理员权限：是/否」，adb 驱动与提权步骤需要更高权限）。
2. 手机开启 USB 调试并连接 → **程序会自动发现设备**（每 1.2 秒轮询一次，无需手动刷新）；
   若没反应，点侧栏「连接设备」重启 adb 服务，手机会弹出「允许 USB 调试吗」，点允许即可。
   日志出现 `设备已连接：<序列号> · <型号> · Android <版本>`。
3. 进「管理器」页，四选一 → 「安装所选」→ 自动检测；
   徽章变绿（已安装）后，提权页按钮才解禁。
4. 进「提权」页 → 「执行提权」（直接在当前系统上打，不预先重启）→ 实时日志同时写 `logs\`，
   面板可滚动、新日志自动贴底；失败会自动重启手机。
5. 「检测root」随时可以点：只跑 `adb shell su -c id`，只读不改设备。

### 验收要点

- 未装管理器时：管理器页「卸载 / 打开管理器」变灰，提权页「执行提权 / 重试」变灰，
  只剩「检测root」可点（有设备时），并显示琥珀色拦截提示条；
- 强行调用提权时 `actionElevate()` 会弹「请先安装并检测到管理器」；
- 拔线 / 杀 adb / 手机重启：界面自动切到「未连接设备」，插回来又自动恢复，进程不崩；
- 日志面板：新日志在底部追加、自动贴底；往上滚后不再被新日志打断（`logPin=false`）；
- 日志三件套：清屏后 `logs\run-*.log` 仍在增长；导出生成 `logs\export-*.log` 并打开目录；
  收起后标题条 44 px、点「展开」恢复且自动滚到最新一行；
- 管理器检查更新：点一次出四行结果（未安装 / 可更新 / 已是最新），有更新时弹确认框逐条列版本差；
  点「取消」后无任何下载；删空 `%LOCALAPPDATA%\SiliconRootTool\apk\*` 后逐个装能自动下载就位；
- 主页：点「工具自检」七项全绿；「切换槽位」在无 root 时给出 `bootctl: inaccessible or not found`
  的替代路径提示而不是直接失败；「无线调试」跨网段时 1~2 秒内给出中文原因，界面不卡；
- 断网、无设备、APK 缺失、adb 超时都有对应日志与提示，不会崩溃。

---

## 10. 提权工具说明（Neo10-Root）

目标机型 iQOO Neo10 (PD2425)，内核 `6.1.145-android14-11-maybe-dirty`
（KMI `android14-6.1`），基于 GhostLock (CVE-2026-43499) + KernelSU late-load 临时 root。

**换管理器流程**：卸载旧管理器 → 安装新 APK → **重启手机** → 重新执行提权。
不要用 `ksud unload` 热切换，实测会掉 adb 并重启手机。

管理器包名白名单（`ksud-launcher.sh`）：
`me.weishu.kernelsu`、`me.weishu.kernelsu.pr`、`com.resukisu.resukisu`、
`com.kowx712.supermanager`、`com.sukisu.ultra`。

---

## 11. 许可与致谢

- UI 框架：[EUI-NEO](https://github.com/sudoevolve/EUI-NEO)，Apache-2.0；
- 提权工具：Neo10-Root v2.1 正式版（随包分发，版权归原作者）；
- 图标字体：Font Awesome 7 Free（SIL OFL 1.1）；
- 界面中文字体：荆南郡君体 / 优设标题黑（随包分发）。

本工具只做界面集成、状态校验与命令调用封装，不含任何绕过系统安全机制的逻辑。

## 主页（v2.8 新增 · v2.9 接通后端）

左侧导航第一项。参考 VioletToolBox 的版式，四块区域：

| 区块 | 内容 |
|---|---|
| 左上 · 设备信息 | 两列。左列：设备状态、连接类型、设备序列号、设备名称、设备代号、安卓版本、解锁状态、版本信息、内核版本、构建日期；右列：A/B 分区、CPU 厂家、CPU 代号、CPU 名称、操作系统、SELinux |
| 右上 · 电池状态 | 横向胶囊，填充比例 = 电量百分比，中间显示数字 |
| 右中 · 存储与内存 | 两个环形进度：内部存储、运行内存，环内显示百分比与 `已用/总量` |
| 左下 · 快捷重启 | 六个按钮（系统 / Fastboot / FastbootD / Recovery / 9008(EDL) / 刷新设备）+「更多重启指令」下拉 |
| 右下 · 快捷工具 | 无线调试、切换槽位两个按钮；设备检测 / 工具自检 / 多设备三个开关；设备选择下拉 |

底部五个小字链接：保存设备信息、打开日志目录、全功能使用教程、连接指南、USB3.0补丁。
其中「USB3.0补丁」不再甩外链，点它直接跑一次 USB 传输模式体检。

v2.9 起上面这些按钮**全部接通了真实后端**（`src/backend/home_tools.{h,cpp}`，434 + 87 行）：

| 按钮 / 链接 | 后端函数 | 行为 |
|---|---|---|
| 无线调试 | `enableWirelessDebug(serial, 5555, ip, r)` / `disableWirelessDebug` | 先 `probeTcpReachable` 预检，再 `adb tcpip` + 轮询等端口监听 + `adb connect`；已有无线态则改成断开 |
| 切换槽位 | `switchSlot(serial, commit, r)` | 先只读探当前槽位；无 root 时给「重启到 Fastboot 后手工 `--set-active`」的替代路径，有 root 才真切 |
| USB3.0补丁 | `usb3Compat(serial, false, r)` | 读当前 USB 组合，不是 USB2 组合就回「无需打补丁」 |
| 保存设备信息 | `saveDeviceReport()` | 写 `logs\device-<serial>-<tick>.txt`（UTF-8 BOM）并打开目录 |
| 打开日志目录 | `openFolder(appDir() + "\\logs")` | 直接开资源管理器 |
| 工具自检 | `actionSelfCheck()` | 七项：adb 就绪 / 资源 apk / roottool / scrcpy / 提权脚本 / scrcpy 版本 / 已授权设备数 |
| 常亮屏 | `keepScreenOn(serial, on, log)` | 写 `settings put system screen_off_timeout` |
| 清理临时文件 | `cleanTempFiles(serial, log)` | 只清 `/sdcard/siliconroot/*`、`/data/local/tmp/gl-*.log` 等本工具产物，回显 `CLEANED:<n>` |

### 数据是怎么来的

一次 `adb shell` 跑完一条自带分段标记（`echo @@KEY`）的探测脚本，回传后按段解析，
**不是逐项 getprop**——逐项要十五六次往返，每次 100~300 ms，主页冷启动两秒以上。

`src/backend/managers.cpp`：

- `DeviceDetail detectDeviceDetail(const std::string& serial = "")` —— 采集全表；serial 留空取第一台已授权设备
- `std::vector<std::string> listDeviceSerials()` —— 所有 `state=device` 的序列号，供设备下拉
- `bool rebootInto(serial, target, log)` —— target ∈ `system` / `fastboot` / `fastbootd` / `recovery` / `edl` / `sideload` / `shutdown`
- `bool saveDeviceReport(detail, path, log)` —— UTF-8（带 BOM）纯文本报告

字段派生规则：

- `connection`：序列号含 `:` → 无线（TCP），否则 USB
- `unlock`：先看 `ro.boot.flash.locked`（1 锁 / 0 解锁），没有则看 `ro.boot.verifiedbootstate`（orange|red = 已解锁，green = 已锁定）
- `abSlot`：`ro.boot.slot_suffix` = `_a`/`_b` → 支持 A/B + 当前槽位；否则看 `ro.build.ab_update`；都没有 → A-only
- `memoryUsed`：`MemTotal - MemAvailable`（没有 MemAvailable 时退回 MemFree）
- `storageUsed`：`df /data` 的 `1K-blocks` 与 `Used` 两列 × 1024

### 刷新时机

`startHomeWatcher()` 起一个后台线程，每 4 秒一轮，只在**当前停在主页 + 设备检测开关打开 + 没有别的任务在跑**时才重新采集。
点「刷新设备」「设备下拉换一台」也会立刻触发一次。

### 两个实现坑

1. **环形进度**：EUI-NEO 没有弧图元，`components::progress` 只有直线条。做法是用 48 个小方块顺时针拼弧，
   中间盖一个卡片色圆盘挖空。段数不能超过 128（`opengl_primitives.cpp` 的 `kMaxPolygonEdges`）。
2. **电池百分比被填充条盖住**：`ui.rect` 和 `ui.text` 同层级时按添加顺序绘制，文字在填充条之后加还不够，
   必须显式 `.zIndex(20)`；且深色主题下 primary 色文字落在 primary 色块上会糊，要用白字。
3. **下拉框一滑就执行**：`components::dropdown` 的 `.onChange` 在选项被「滚轮滑过」的瞬间就触发，
   旧代码直接调 `actionRebootInto()`，等于一滑就重启/关机。v2.9 改成只登记 `pendingRebootTarget`，
   弹二次确认，取消则什么都不发生。

### 实现要点（v2.9）

- **无线调试必须先预检**：`probeTcpReachable(ip, port, timeoutMs, failReason)` 用 winsock
  非阻塞 `connect` + `select` 精确超时。电脑与手机不在同一网段时直接给出中文原因并返回，
  不把手机切进 `adb tcpip` 模式（切了就 USB 断、无线又连不上，没有回退通道）。
  依赖 `ws2_32`，`CMakeLists.txt` 的 `target_link_libraries` 里已补。
- **`bootctl` 需要 root**：无 root 时 `switchSlot` 的只读探测能正常返回当前槽位，
  但真正切换会得到 `/system/bin/sh: bootctl: inaccessible or not found`，
  所以失败分支要给替代路径而不是只说「失败」。
- **设备报告用宽字符写**：exe 放在 `E:\下载\…` 这种含中文的路径下时，
  窄字符 `fopen` 会按 ANSI 代码页解释路径而写不进去，必须 `_wfopen(path(backend::widen(p)), L"wb")`。
