"""把 EuiRoot 产物以「多文件」形态交付到 E:\\下载\\（AGENTS.md 强制要求）。

产物：
  E:\\下载\\SiliconRootTool-EUI\\交付\\
      SiliconRootTool\\             ← 可直接运行的目录（exe + assets + ini + logs/temp）
      SiliconRootTool-v3.1-多文件版.zip
      界面预览.png
      README.md
      源码工程\\EuiRoot\\

用法：
    python deliver.py
"""
from __future__ import annotations

import os
import shutil
import stat
import subprocess
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
DEST_ROOT = r"E:\下载\SiliconRootTool-EUI"
DEST = os.path.join(DEST_ROOT, "交付")
APP_DIR = os.path.join(DEST, "SiliconRootTool")
ZIP_NAME = "SiliconRootTool-v3.2-多文件版.zip"

SOURCE_ITEMS = ["CMakeLists.txt", "README.md", "author.ini", "src", "assets"]
JUNK_DIRS = {"__pycache__", "build", "build_res", "build-dbg", "_shots", "_single_test",
             "_dltest", "_dumps", "_stub", ".git"}
# QA 截图（qa_*.png / q2_*.png / 界面预览.png）只在本机用于验证，不进源码工程快照
JUNK_FILE_PREFIXES = ("qa_", "q2_")


def rmtree(path: str) -> None:
    if os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=True)


def _inside(child: str, parent: str) -> bool:
    """child 是否等于或在 parent 目录之下（都按 realpath 比较）。"""
    c = os.path.normcase(os.path.realpath(child))
    p = os.path.normcase(os.path.realpath(parent))
    return c == p or c.startswith(p + os.sep)


def clean() -> None:
    for name in ("_shots", "_single_test", "_dltest"):
        rmtree(os.path.join(HERE, name))
    print("cleaned temp dirs")


def clear_outputs() -> None:
    """只清理本项目自己产出的那几项，**绝不删除 DEST 本身**。

    历史事故：旧版这里写的是 rmtree(DEST)，而 DEST 里装着
    「源码工程\\EuiRoot」。一旦从交付目录里的源码副本直接运行本脚本，
    HERE 就落在 DEST 内部，rmtree(DEST) 会把正在运行的脚本连同整个
    源码工程一起删掉（不可恢复）。改成白名单清理后，无论脚本从哪里
    启动都不会自杀。

    源码工程如果就在 DEST 里（即本脚本正跑在交付副本上），保留不动。
    """
    same_tree = _inside(HERE, DEST)
    targets = [
        APP_DIR,
        os.path.join(DEST, ZIP_NAME),
        os.path.join(DEST, "界面预览.png"),
    ]
    if not same_tree:
        # 只有本脚本不在 DEST 里时，才允许重建源码工程快照
        targets.append(os.path.join(DEST, "源码工程"))
    else:
        print("检测到本脚本位于交付目录内，跳过源码工程重建（避免自删）")

    for path in targets:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
            print("removed dir  %s" % path)
        elif os.path.exists(path):
            os.remove(path)
            print("removed file %s" % path)

    os.makedirs(DEST, exist_ok=True)


def _skip_dir(name: str) -> bool:
    """复制/打包时跳过的目录。

    `JUNK_DIRS` 是构建垃圾；以 `.` 开头的是更新器的工作目录
    （`assets/apk/.backup`、`.staging`），里面是旧版本 APK 和半截下载，
    绝不能进交付包——否则包体积翻几倍，还会把上一个版本一起发出去。
    """
    return name in JUNK_DIRS or name.startswith(".")


def _remove_readonly(path: str) -> None:
    """覆盖前把目标文件的只读属性摘掉。

    踩过：tools/icon-src/ 里的源图带 ReadOnly 标志（做图标时为了避免误改设的），
    交付时被 copy2 原样带到交付目录，下次再跑就 chmod 不了目标 →
    PermissionError: [Errno 13] Permission denied ... icon-black.png。
    Windows 上 os.chmod 只能改只读位，够用。
    """
    try:
        if os.path.exists(path):
            os.chmod(path, stat.S_IWRITE | stat.S_IREAD)
    except OSError:
        pass


def copy_file(src: str, dst: str) -> None:
    _remove_readonly(dst)
    shutil.copy2(src, dst)


def copy_tree(src: str, dst: str) -> None:
    for root, dirs, files in os.walk(src):
        dirs[:] = [d for d in dirs if not _skip_dir(d)]
        rel = os.path.relpath(root, src)
        target = dst if rel == "." else os.path.join(dst, rel)
        os.makedirs(target, exist_ok=True)
        for name in files:
            if name.endswith(".pyc") or name.startswith("."):
                continue
            copy_file(os.path.join(root, name), os.path.join(target, name))


def make_preview() -> str | None:
    """截当前运行的窗口作为界面预览（只截窗口自身，不含桌面/任务栏）。"""
    ps = r"""
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;using System.Runtime.InteropServices;
public struct RECT { public int Left, Top, Right, Bottom; }
public class Dw {
 [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
 [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h,int c);
 [DllImport("user32.dll")] public static extern bool MoveWindow(IntPtr h,int x,int y,int w,int t,bool r);
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
 [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
}
"@
$pr = Get-Process -Name SiliconRootTool -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $pr) { exit 1 }
$h = [IntPtr]$pr.MainWindowHandle
[Dw]::ShowWindow($h, 9) | Out-Null
[Dw]::MoveWindow($h, 0, 0, 1500, 940, $true) | Out-Null
[Dw]::SetForegroundWindow($h) | Out-Null
Start-Sleep -Milliseconds 1500
$r = New-Object RECT
if (-not [Dw]::GetWindowRect($h, [ref]$r)) { exit 1 }
$w = $r.Right - $r.Left
$ht = $r.Bottom - $r.Top
if ($w -le 0 -or $ht -le 0) { exit 1 }
$b = New-Object System.Drawing.Bitmap $w, $ht
$g = [System.Drawing.Graphics]::FromImage($b)
# PrintWindow 直接取窗口内容，不受遮挡影响（后台窗口也不会截到别的程序）
$hdc = $g.GetHdc()
$ok = [Dw]::PrintWindow($h, $hdc, 2)   # 2 = PW_RENDERFULLCONTENT
$g.ReleaseHdc($hdc)
if (-not $ok) {
    # 退化路径：按窗口矩形从屏幕抓
    $g.CopyFromScreen($r.Left, $r.Top, 0, 0, $b.Size)
}
$b.Save($env:SHOT_PATH, [System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose(); $b.Dispose()
"""
    shot = os.path.join(DEST, "界面预览.png")
    env = dict(os.environ, SHOT_PATH=shot)
    proc = subprocess.run(["powershell", "-NoProfile", "-Command", ps], env=env,
                          capture_output=True)
    if proc.returncode == 0 and os.path.exists(shot):
        print("preview: %s" % shot)
        return shot
    print("preview skipped (窗口未运行)")
    return None


def build_run_dir(exe: str) -> None:
    """组装可直接运行的多文件目录。"""
    os.makedirs(APP_DIR, exist_ok=True)
    copy_file(exe, os.path.join(APP_DIR, "SiliconRootTool.exe"))
    copy_tree(os.path.join(HERE, "assets"), os.path.join(APP_DIR, "assets"))
    ini = os.path.join(HERE, "author.ini")
    if os.path.exists(ini):
        copy_file(ini, os.path.join(APP_DIR, "author.ini"))
    # 空目录也要存在于 zip 里，这里先建好
    os.makedirs(os.path.join(APP_DIR, "logs"), exist_ok=True)
    os.makedirs(os.path.join(APP_DIR, "temp"), exist_ok=True)

    readme = os.path.join(APP_DIR, "使用说明.txt")
    text = (
        "Silicon Root Tool v3.1\n"
        "======================\n"
        "\n"
        "运行：双击 SiliconRootTool.exe（建议右键 → 以管理员身份运行）。\n"
        "      exe 必须和 assets 目录放在同一层，删掉 assets 会提示资源缺失。\n"
        "\n"
        "目录：\n"
        "  SiliconRootTool.exe  主程序\n"
        "  author.ini           关于作者页的全部内容（昵称/QQ/群/邮箱/主页/赞赏码路径）\n"
        "  config.ini           窗口尺寸、上次选中的管理器与页面（首次运行自动生成）\n"
        "  assets/apk           四个管理器 APK\n"
        "  assets/roottool      Neo10-Root 提权工具（Neo10-Root.ps1、adb.exe、ksud 等）\n"
        "  assets/about         头像与赞赏码图片，换成自己的收款码即可\n"
        "  logs                 运行日志，每次启动一个 run-*.log（自动生成）\n"
        "  temp                 临时目录（自动生成）\n"
        "\n"
        "v3.1 新增：管理器检查更新\n" + "  点一次列出四个管理器哪些有新版，弹确认框后可一键下载 + 覆盖安装\n" + "  未安装的只报上游版本，不计入更新列表；更新后临时 root 需要重新提权\n" + "\n" + "v3.0 新增：日志面板三件套（提权页 / 管理器页都有）\n"
        "  清屏  只清界面显示，logs 里的 run-*.log 完整保留\n"
        "  导出  另存为 logs\\export-*.log，并自动打开所在目录\n"
        "  收起  面板只留 44px 标题条，点「展开」恢复；收起后空间回流页面\n"
        "\n"
        "使用顺序：\n"
        "  1. 手机开启 USB 调试并连接，点左下「检测设备」\n"
        "  2. 「管理器」页选一个管理器 → 安装所选 → 检测状态\n"
        "  3. 徽章变绿（已安装）后，「提权」页的执行提权与退群才会解禁\n"
        "  4. 换管理器：先卸载旧的 → 装新的 → 重启手机 → 重新提权\n"
        "\n"
        "仅限在本人拥有并授权的设备上使用。\n"
    )
    with open(readme, "w", encoding="utf-8", newline="\r\n") as handle:
        handle.write(text)


def make_zip() -> str:
    """把运行目录打成 zip。顺手把源码工程也包进去。

    跳过 `.` 开头的目录（`.backup`/`.staging`）与 JUNK_DIRS，
    否则旧版本 APK 会被一起发出去，包体积直接翻倍。
    """
    zip_path = os.path.join(DEST, ZIP_NAME)
    if os.path.exists(zip_path):
        os.remove(zip_path)

    src_root = os.path.join(DEST, "源码工程", "EuiRoot")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        # 1) 可直接运行的目录
        base = os.path.dirname(APP_DIR)
        for root, dirs, files in os.walk(APP_DIR):
            dirs[:] = [d for d in dirs if not _skip_dir(d)]
            rel = os.path.relpath(root, base)
            zf.writestr(rel.replace("\\", "/") + "/", b"")
            for name in files:
                if name.startswith("."):
                    continue
                full = os.path.join(root, name)
                zf.write(full, os.path.join(rel, name).replace("\\", "/"))

        # 2) 源码工程（可离线重建，不含 build 与更新器的工作目录）
        if os.path.isdir(src_root):
            for root, dirs, files in os.walk(src_root):
                dirs[:] = [d for d in dirs if not _skip_dir(d)]
                sub = os.path.relpath(root, src_root)
                rel = "源码工程/EuiRoot" if sub == "." else os.path.join("源码工程", "EuiRoot", sub)
                zf.writestr(rel.replace("\\", "/") + "/", b"")
                for name in files:
                    if name.startswith(".") or name.endswith(".pyc"):
                        continue
                    rel_name = os.path.join(rel, name).replace("\\", "/")
                    # 快照里的 assets/apk 是四份管理器安装包（约 60MB），源码重建用不到，
                    # 打进去只让 zip 翻倍——运行时目录那份已经带了。
                    if "assets/apk" in rel_name:
                        continue
                    zf.write(os.path.join(root, name), rel_name)

        # 3) 交付根目录的两份说明文档（快照里那份可能落后，以根目录为准）
        for doc in ("README.md", "开发全记录.md"):
            path = os.path.join(DEST, doc)
            if os.path.exists(path):
                zf.write(path, doc)

    size = os.path.getsize(zip_path)
    print("zip: %s (%.1f MB)" % (zip_path, size / 1048576))
    return zip_path


def main() -> int:
    exe = os.path.join(HERE, "build", "SiliconRootTool.exe")
    if not os.path.exists(exe):
        print("先构建：cmake --build build --config Release")
        return 1

    clean()
    clear_outputs()

    build_run_dir(exe)
    if not _inside(HERE, DEST):
        copy_tree(HERE, os.path.join(DEST, "源码工程", "EuiRoot"))

    readme = os.path.join(HERE, "README.md")
    if os.path.exists(readme):
        copy_file(readme, os.path.join(DEST, "README.md"))

    # 开发全记录.md 也要跟着一起更新，否则交付目录里永远是旧版
    for doc in ("开发全记录.md", "交付说明.md"):
        src_doc = os.path.join(HERE, doc)
        if os.path.exists(src_doc):
            copy_file(src_doc, os.path.join(DEST, doc))

    make_preview()
    make_zip()

    total = 0
    count = 0
    for root, _dirs, files in os.walk(DEST):
        for name in files:
            total += os.path.getsize(os.path.join(root, name))
            count += 1
    print("交付完成：%d 个文件，%.1f MB" % (count, total / 1048576))
    print("路径：%s" % DEST)
    return 0


if __name__ == "__main__":
    sys.exit(main())
