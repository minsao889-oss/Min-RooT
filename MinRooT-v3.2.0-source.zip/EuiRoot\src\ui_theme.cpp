#include "app.h"

#include "backend/assets.h"
#include "backend/process.h"
#include "backend/workspace.h"
#include "core/platform/platform.h"

#include <windows.h>

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <string>
#include <vector>

namespace app {
namespace {

std::string g_pending;

} // namespace

AppState& state() {
    static AppState s;
    return s;
}

std::recursive_mutex& stateMutex() {
    static std::recursive_mutex m;
    return m;
}

std::string g_targetKey;

// 主题令牌：深色是原始配色，浅色按同一层级关系重排。
// state().darkTheme 每一帧都会被读到 —— 这就是切换主题不需要重建窗口的原因：
// compose 是即时模式，改一个 bool，下一帧整棵树按新配色重画。
components::theme::ThemeColorTokens theme() {
    if (state().darkTheme) {
        auto tokens = components::theme::dark();
        // 纯色背景：深色主题使用纯黑，避免渐变/光斑在拖动窗口时留下残影。
        tokens.background = {0.0f, 0.0f, 0.0f, 1.0f};
        tokens.primary = {0.216f, 0.443f, 0.878f, 1.0f};      // #3871E0
        // LIQUID_GLASS_TOKENS：液态玻璃化——卡片/弹层半透明 + 白色高光边 + 大圆角
        tokens.surface = {0.129f, 0.145f, 0.176f, 0.62f};
        tokens.surfaceHover = {0.165f, 0.184f, 0.220f, 0.72f};
        tokens.surfaceActive = {0.200f, 0.224f, 0.267f, 0.80f};
        tokens.text = {0.945f, 0.957f, 0.976f, 1.0f};
        tokens.border = {1.0f, 1.0f, 1.0f, 0.13f};
        tokens.dark = true;
        return tokens;
    }

    auto tokens = components::theme::light();
    // 纯色背景：浅色主题使用纯白，保持整窗只有一种底色。
    tokens.background = {1.0f, 1.0f, 1.0f, 1.0f};             // #FFFFFF
    tokens.primary = {0.196f, 0.412f, 0.847f, 1.0f};          // #3268D8，浅底上略压暗
    // LIQUID_GLASS_TOKENS：液态玻璃化——卡片半透明 + 白色高光边 + 大圆角
    tokens.surface = {1.000f, 1.000f, 1.000f, 0.36f};
    tokens.surfaceHover = {0.976f, 0.984f, 0.996f, 0.50f};
    tokens.surfaceActive = {0.945f, 0.957f, 0.976f, 0.62f};
    tokens.text = {0.106f, 0.125f, 0.157f, 1.0f};             // #1B2028
    tokens.border = {1.000f, 1.000f, 1.000f, 0.92f};          // 白色高光边
    tokens.dark = false;
    return tokens;
}

eui::Transition motion() {
    return eui::Transition::make(0.16f, eui::Ease::OutCubic);
}

eui::Color textPrimary() {
    return theme().text;
}

eui::Color textMuted() {
    if (state().darkTheme) return {0.63f, 0.66f, 0.72f, 1.0f};
    return {0.361f, 0.396f, 0.451f, 1.0f};      // #5C6573
}

eui::Color textFaint() {
    if (state().darkTheme) return {0.44f, 0.47f, 0.53f, 1.0f};
    return {0.545f, 0.576f, 0.627f, 1.0f};      // #8B93A0
}

eui::Color borderColor(float alpha) {
    return components::theme::withOpacity(theme().border, alpha);
}

eui::Color cardColor() {
    return theme().surface;
}

eui::Color mutedCardColor() {
    if (state().darkTheme) return {1.000f, 1.000f, 1.000f, 0.055f};
    return {1.000f, 1.000f, 1.000f, 0.28f};      // LIQUID_GLASS: translucent frosted
}

// 警告语义色：深色主题用亮琥珀，浅色主题压暗到能在白底读出来
eui::Color warnColor() {
    return state().darkTheme ? eui::Color{0.910f, 0.702f, 0.294f, 1.0f}
                             : eui::Color{0.686f, 0.478f, 0.078f, 1.0f};
}

// 警告条底色：深色是暗琥珀，浅色是极浅暖黄
eui::Color warnCardColor() {
    return state().darkTheme ? eui::Color{0.176f, 0.130f, 0.106f, 1.0f}
                             : eui::Color{1.000f, 0.969f, 0.898f, 1.0f};
}

// 面板/卡片悬浮反馈：深色靠提亮，浅色靠压暗，方向必须相反，否则浅色主题里会「悬停发白」
eui::Color hoverTint() {
    return state().darkTheme ? eui::Color{1.0f, 1.0f, 1.0f, 0.028f}
                             : eui::Color{0.0f, 0.0f, 0.0f, 0.035f};
}

eui::Color pressedTint() {
    return state().darkTheme ? eui::Color{1.0f, 1.0f, 1.0f, 0.05f}
                             : eui::Color{0.0f, 0.0f, 0.0f, 0.06f};
}

// 半透明叠层：深色主题叠白，浅色主题叠黑
eui::Color overlayTint(float alpha) {
    return state().darkTheme ? eui::Color{1.0f, 1.0f, 1.0f, alpha}
                             : eui::Color{0.0f, 0.0f, 0.0f, alpha};
}

eui::Color stateColor(backend::InstallState s) {
    switch (s) {
        case backend::InstallState::Installed:    return {0.298f, 0.765f, 0.541f, 1.0f}; // #4CC38A
        case backend::InstallState::Installing:   return {0.910f, 0.702f, 0.294f, 1.0f}; // #E8B34B
        case backend::InstallState::Failed:       return {0.898f, 0.349f, 0.361f, 1.0f}; // #E5595C
        case backend::InstallState::NotInstalled:
            // 未安装是「中灰」语义：浅色主题下必须压暗，否则白底上看不见
            return state().darkTheme ? eui::Color{0.478f, 0.510f, 0.573f, 1.0f}
                                     : eui::Color{0.451f, 0.478f, 0.529f, 1.0f}; // #737987
        default:                                  return {0.400f, 0.427f, 0.482f, 1.0f};
    }
}

eui::Color accentFor(const std::string& key) {
    if (key == "kernelsu") return {0.310f, 0.560f, 0.980f, 1.0f};
    if (key == "kernelsu_next") return {0.420f, 0.510f, 0.960f, 1.0f};
    if (key == "sukisu") return {0.608f, 0.482f, 1.000f, 1.0f};
    return {0.322f, 0.760f, 0.690f, 1.0f};
}

// 主题持久化：config.ini 的 [ui] theme = dark / light。
// 读不到或值非法时保持深色（默认值），不会因为 ini 被手改坏而开不出窗口。
void loadTheme() {
    const std::string ini = backend::appIniPath();
    const std::string value = backend::readIni(ini, "ui", "theme", "dark");
    state().darkTheme = (value != "light");
}
// 窗口/任务栏图标跟着主题走。
//
// 框架的 applyWindowIcon() 只在窗口创建那一刻跑一次（dsl_app_impl.h:290 的
// state.iconApplied 守卫），之后没有公开入口能重设。这里自己发 WM_SETICON：
// 按标题找到本进程的窗口，LoadImageW 直接从 assets 读多尺寸 ICO，
// 大小图标各设一次。
//
// 为什么不用 PNG：LoadImageW 不认 PNG，走 stb/WIC 要多引一堆东西，
// 而 ICO 天生就是 Windows 要的格式，多尺寸内嵌，系统自己挑最合适的一档。
void applyWindowIconForTheme() {
    const std::string rel = state().darkTheme ? "icon-window-dark.ico" : "icon-window-light.ico";
    const std::string file = backend::assets::pathForExternal(rel);
    if (file.empty() || !backend::fileExists(file)) return;   // 图标缺失不该影响主流程，静默跳过
    const std::wstring wide = backend::widen(file);

    HWND hwnd = FindWindowW(L"GLFW30", nullptr);
    if (!hwnd) hwnd = FindWindowW(nullptr, L"Min RooT - 管理器安装与提权");
    if (!hwnd) return;

    // LR_LOADFROMFILE 读指定文件；LR_DEFAULTSIZE 让系统按 SM_CXICON 取最合适档位
    HICON small = static_cast<HICON>(
        LoadImageW(nullptr, wide.c_str(), IMAGE_ICON,
                   GetSystemMetrics(SM_CXSMICON), GetSystemMetrics(SM_CYSMICON),
                   LR_LOADFROMFILE));
    HICON big = static_cast<HICON>(
        LoadImageW(nullptr, wide.c_str(), IMAGE_ICON,
                   GetSystemMetrics(SM_CXICON), GetSystemMetrics(SM_CYICON),
                   LR_LOADFROMFILE));

    if (small) SendMessageW(hwnd, WM_SETICON, ICON_SMALL, reinterpret_cast<LPARAM>(small));
    if (big) SendMessageW(hwnd, WM_SETICON, ICON_BIG, reinterpret_cast<LPARAM>(big));

    // 换完图标让标题栏立刻重绘，否则有时候要等鼠标划过才更新
    SetWindowPos(hwnd, nullptr, 0, 0, 0, 0,
                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED
                     | SWP_DRAWFRAME);
}

// 系统标题栏跟着主题走。
//
// 框架完全不碰窗口边框，交给 GLFW 默认创建 —— 结果就是深色界面顶着一条白标题栏。
// 这里用 DWM 的两个属性刷：
//   DWMWA_USE_IMMERSIVE_DARK_MODE(20)：Win10 1809 起支持（早期是 19，需按 build 号选）
//   DWMWA_CAPTION_COLOR(35) / DWMWA_TEXT_COLOR(36) / DWMWA_BORDER_COLOR(34)：
//       Win11 22000 起支持，能精确指定标题栏底色
// 先试 35/36/34，失败再退回 20；两个都失败就静默返回（老系统上退化成系统默认色，不影响功能）。
//
// 依赖 dwmapi.lib：GetProcAddress 动态取，避免为老 SDK 加链接依赖。
void applyTitlebarForTheme() {
    HWND hwnd = FindWindowW(L"GLFW30", nullptr);
    if (!hwnd) hwnd = FindWindowW(nullptr, L"Min RooT - 管理器安装与提权");
    if (!hwnd) return;

    HMODULE dwm = LoadLibraryW(L"dwmapi.dll");
    if (!dwm) return;
    using DwmSet = HRESULT(WINAPI*)(HWND, DWORD, LPCVOID, DWORD);
    auto set = reinterpret_cast<DwmSet>(
        reinterpret_cast<void*>(GetProcAddress(dwm, "DwmSetWindowAttribute")));
    if (!set) {
        FreeLibrary(dwm);
        return;
    }

    const bool dark = state().darkTheme;
    // 与 theme() 的 background 同色，让标题栏和界面连成一片
    const COLORREF caption = dark ? RGB(14, 16, 20) : RGB(245, 247, 250);
    const COLORREF text = dark ? RGB(241, 244, 249) : RGB(27, 32, 40);
    const COLORREF border = dark ? RGB(46, 50, 59) : RGB(215, 221, 230);

    // Win11 22H2+：精确指定三个颜色（失败不代表不支持，继续试下一个）
    set(hwnd, 35, &caption, sizeof(caption));   // DWMWA_CAPTION_COLOR
    set(hwnd, 36, &text, sizeof(text));         // DWMWA_TEXT_COLOR
    set(hwnd, 34, &border, sizeof(border));     // DWMWA_BORDER_COLOR

    // Win10 1809+ / Win11：只给「暗/亮」一个开关，颜色由系统决定。
    // 属性号在 20H1 前后改过（19 → 20），所以两个都试，谁成功算谁。
    BOOL useDark = dark ? TRUE : FALSE;
    if (FAILED(set(hwnd, 20, &useDark, sizeof(useDark)))) {
        set(hwnd, 19, &useDark, sizeof(useDark));
    }

    FreeLibrary(dwm);

    // 标题栏重绘有时要等鼠标划过才生效，主动催一次
    SetWindowPos(hwnd, nullptr, 0, 0, 0, 0,
                 SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED
                     | SWP_DRAWFRAME);
}

void setDarkTheme(bool dark) {
    // 注意：不能在这里 early-return。启动时 state().darkTheme 的默认值就是 true，
    // 而 applyTitlebarForTheme() 必须在第一次切换之前也跑一遍，否则深色主题下
    // 标题栏会一直是系统白的。early-return 曾导致「首次点深色没反应」。
    state().darkTheme = dark;
    backend::writeIni(backend::appIniPath(), "ui", "theme", dark ? "dark" : "light");
    applyWindowIconForTheme();
    applyTitlebarForTheme();
    // 即时模式：下一帧整棵树按新配色重画。这里只需要叫醒渲染循环，
    // 不需要重建窗口，也不会丢滚动位置/信号量。
    core::platform::requestUiUpdate();
    logLine(LOG_INFO, dark ? "切换主题 · 深色 · 完成" : "切换主题 · 浅色 · 完成");
}

namespace {

// 级别归一：对外只保留 INFO / SUCC / WARN / ERR 四种固定标识。
// 历史调用点还在写 OK / ERROR / STEP / DEBUG，这里一次性收敛，
// 免得同一个语义在日志里出现两套标识、界面上还要为它多写一条配色分支。
const char* normalizeLevel(const std::string& level) {
    if (level == "OK" || level == "SUCC" || level == "SUCCESS") return LOG_SUCC;
    if (level == "ERROR" || level == "ERR" || level == "FAIL") return LOG_ERR;
    if (level == "WARN" || level == "WARNING") return LOG_WARN;
    return LOG_INFO;   // INFO / STEP / DEBUG / 其它一律按普通信息
}

// 单行裁剪：去掉子进程输出里的颜色控制符、行首行尾空白，
// 并把内部连续空白压成一个空格——排版规整靠这一步，不是靠调用点自己收拾。
std::string tidyLogText(const std::string& raw) {
    std::string out;
    out.reserve(raw.size());
    bool pendingSpace = false;
    for (unsigned char ch : raw) {
        if (ch == 0x1B) {           // ESC：跳过整段 ANSI 序列（[ … 终止字母）
            pendingSpace = false;
            continue;
        }
        if (ch == '\t') ch = ' ';
        if (ch == ' ') {
            if (!out.empty()) pendingSpace = true;
            continue;
        }
        if (pendingSpace) {
            out.push_back(' ');
            pendingSpace = false;
        }
        out.push_back(static_cast<char>(ch));
    }
    while (!out.empty() && (out.back() == ' ' || out.back() == '\r')) out.pop_back();
    return out;
}

std::string nowClock() {
    SYSTEMTIME st{};
    GetLocalTime(&st);
    char buf[16] = {0};
    std::snprintf(buf, sizeof(buf), "%02d:%02d:%02d", st.wHour, st.wMinute, st.wSecond);
    return std::string(buf);
}

} // namespace

// 统一日志出口。排版格式（界面与落盘一致）：
//   HH:mm:ss  [级别]  内容
// 内容要求：操作名称 · 关键参数 · 结果。报错另起「原因：」写一句可读原因，
// 不打印堆栈、不打印临时变量。
void logLine(const std::string& level, const std::string& text) {
    // 日志可能同时被后台线程（提权工具输出）和主线程写入，串行化一下，
    // 否则两个线程同时 push_back / erase 会把 vector 搞坏。
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    AppState& s = state();
    const char* lv = normalizeLevel(level);
    const std::string clock = nowClock();
    // 子进程输出（adb）常是多行。日志面板一行放不下，\n 会被当成普通字符渲染成一条超长行，
    // 中文也会被截断成乱码观感。这里按行拆开逐条入队，并同步落盘到 logs\run-*.log。
    std::vector<std::string> lines;
    if (text.find('\n') == std::string::npos && text.find('\r') == std::string::npos) {
        if (!text.empty()) lines.push_back(text);
    } else {
        std::string line;
        for (size_t i = 0; i <= text.size(); ++i) {
            const char ch = (i < text.size()) ? text[i] : '\n';
            if (ch == '\n' || ch == '\r') {
                while (!line.empty() && (line.back() == ' ' || line.back() == '\t')) line.pop_back();
                if (!line.empty()) lines.push_back(line);
                line.clear();
            } else {
                line.push_back(ch);
            }
        }
    }
    for (const std::string& raw : lines) {
        const std::string entry = tidyLogText(raw);
        if (entry.empty()) continue;
        s.logs.push_back({clock, lv, entry});
        backend::logToFile(lv, clock, entry);
    }
    if (s.logs.size() > 800) s.logs.erase(s.logs.begin(), s.logs.begin() + 200);
    // 新日志到达时把滚动条贴到底部（用户手动往上翻过就不再打扰）
    if (s.logPin) s.logScroll.set(1.0e6f);
    // 日志可能由后台线程写入：主动唤醒渲染循环，否则空闲时不会重绘，界面看起来「没反应」
    core::platform::requestUiUpdate();
}

// ---- 日志的视图操作（清屏 / 导出 / 收起）------------------------------------
// 设计取舍：清屏只截断内存里的 s.logs，不碰 logs\run-*.log。
// 后台线程（提权工具、adb 轮询）随时可能正在写盘，把文件截断会和它抢 fd；
// 而且「清屏」是视图动作，把磁盘记录一起抹掉等于丢证据。所以两个动作分开：
//   clearLog()      → 只看界面清爽，磁盘记录完整保留
//   actionExportLog()→ 从磁盘把这次运行的完整记录捞出来另存一份
void clearLog() {
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    AppState& s = state();
    if (s.logs.empty()) {
        logLine(LOG_INFO, "清空日志 · 跳过 · 原因：界面里没有日志行");
        return;
    }
    const std::size_t removed = s.logs.size();
    s.logs.clear();
    // 清屏后重新开启「贴底」，否则滚动条停在旧位置、新日志会看不见
    s.logPin = true;
    for (eui::Signal<float>* sig : s.logScrollTargets) {
        if (sig) sig->set(0.0f);
    }
    core::platform::requestUiUpdate();
    logLine(LOG_INFO, "清空日志 · 移除 " + std::to_string(removed) + " 行 · 完成"
                       "（磁盘 run-*.log 未动，可点「导出」另存）");
}

void actionExportLog() {
    // 先看这次运行有没有落盘文件，没有就直接告诉用户去哪儿找
    const std::string session = backend::sessionLogPath();
    if (session.empty() || !backend::fileExists(session)) {
        logLine(LOG_WARN, "导出日志 · 跳过 · 原因：本次会话还没有生成 run-*.log（先跑一次任务）");
        return;
    }

    // 目标：logs\export-<时间戳>.log，内容 = 本次运行落盘的完整记录
    const std::string dir = backend::appDir() + "\\logs";
    auto stamp = std::chrono::system_clock::now().time_since_epoch().count();
    char name[64];
    std::snprintf(name, sizeof(name), "\\export-%lld.log", static_cast<long long>(stamp));
    const std::string target = dir + name;

    // 用宽字符流，exe 放在中文目录下时窄字符路径会写不进去（v2.9 踩过同一个坑）
    std::ifstream in(std::filesystem::path(backend::widen(session)), std::ios::binary);
    if (!in) {
        logLine(LOG_ERR, "导出日志 · " + session + " · 失败 · 原因：文件打不开（可能已被移动或占用）");
        return;
    }
    std::ofstream out(std::filesystem::path(backend::widen(target)),
                      std::ios::binary | std::ios::trunc);
    if (!out) {
        logLine(LOG_ERR, "导出日志 · " + target + " · 失败 · 原因：目标文件无法写入（检查 logs 目录权限）");
        return;
    }
    // 会话日志自身已带 UTF-8 BOM，这里不要重复写
    out << in.rdbuf();
    const bool ok = out.good();
    out.close();
    in.close();

    if (!ok) {
        logLine(LOG_ERR, "导出日志 · " + target + " · 失败 · 原因：写入中断（磁盘空间或权限不足）");
        return;
    }
    logLine(LOG_SUCC, "导出日志 · " + target + " · 完成");
    backend::openFolder(dir);
}

void toggleLogCollapsed() {
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    AppState& s = state();
    s.logCollapsed = !s.logCollapsed;
    if (!s.logCollapsed) {
        // 展开后立刻贴底：收起期间攒下的新日志要能一眼看到
        s.logPin = true;
        for (eui::Signal<float>* sig : s.logScrollTargets) {
            if (sig) sig->set(1.0e6f);
        }
    }
    core::platform::requestUiUpdate();
    logLine(LOG_INFO, s.logCollapsed ? "收起日志面板 · 完成" : "展开日志面板 · 完成");
}

// 日志放大/还原：放大态下各页面把日志面板画到与内容区等高（见 logExpanded()），
// 标题条上的「还原」把它关掉，布局立刻回到原样。
void setLogExpanded(bool on) {
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        AppState& s = state();
        if (s.logExpanded == on) return;
        s.logExpanded = on;
        if (on) s.logCollapsed = false;   // 放大与收起互斥，否则只剩一条标题条
        s.logPin = true;
        for (eui::Signal<float>* sig : s.logScrollTargets) {
            if (sig) sig->set(1.0e6f);
        }
    }
    core::platform::requestUiUpdate();
    logLine(LOG_INFO, on ? "放大日志面板 · 完成 · 再点「还原」恢复布局"
                         : "还原日志面板 · 完成");
}

void toggleLogExpanded() { setLogExpanded(!logExpanded()); }

bool logExpanded() {
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    return state().logExpanded;
}

void registerLogScroll(eui::Signal<float>& signal) {
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    std::vector<eui::Signal<float>*>& list = state().logScrollTargets;
    if (std::find(list.begin(), list.end(), &signal) == list.end()) list.push_back(&signal);
}

void unregisterLogScroll(eui::Signal<float>& signal) {
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    std::vector<eui::Signal<float>*>& list = state().logScrollTargets;
    list.erase(std::remove(list.begin(), list.end(), &signal), list.end());
}

int selectedIndex() {
    AppState& s = state();
    const auto& list = backend::managers();
    for (size_t i = 0; i < list.size(); ++i) {
        if (list[i].key == s.selected) return static_cast<int>(i);
    }
    return 0;
}

const backend::ManagerInfo& selectedManager() {
    return backend::managers()[static_cast<size_t>(selectedIndex())];
}

int indexOfManager(const std::string& key) {
    const auto& list = backend::managers();
    for (size_t i = 0; i < list.size(); ++i) {
        if (list[i].key == key) return static_cast<int>(i);
    }
    return -1;
}

std::string selectedName() {
    return selectedManager().name;
}

backend::InstallState selectedState() {
    AppState& s = state();
    const int idx = selectedIndex();
    if (idx < 0 || idx >= static_cast<int>(s.states.size())) return backend::InstallState::Unknown;
    return s.states[static_cast<size_t>(idx)];
}

bool selectedInstalled() {
    return selectedState() == backend::InstallState::Installed;
}

} // namespace app
