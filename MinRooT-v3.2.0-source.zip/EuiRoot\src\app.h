#pragma once
// 全局业务状态 + 主题工具 + 各页面 compose 声明。
#include "eui_neo.h"

#include "backend/managers.h"

#include <functional>
#include <mutex>
#include <string>
#include <vector>

namespace app {

// 左侧导航页
// 主页放在最前（序号 0），原有四页整体顺延一位。
// config.ini 的 state/last_page 存的是这个整数，插页必须整体顺延。
enum class Page { Home = 0, Tool = 1, Managers = 2, Mirror = 3, About = 4 };

// 弹窗（同一时刻只允许一个）
// ZoomAlipay / ZoomWechat：赞赏码在应用内放大显示（扫码用），不再调用系统看图软件。
enum class Popup {
    None,
    WarnNoManager,
    ConfirmUninstall,
    ConfirmReboot,
    ZoomAlipay,
    ZoomWechat,
    ConfirmUpdate     // 「检查更新」查到可更新的项后弹出来的确认框
};

// 日志级别（固定四种，界面只认这四个标识）
//   INFO 普通信息（白）  SUCC 操作成功（绿）  WARN 警告提示（黄）  ERR 错误失败（红）
// 对外接口仍然接受旧写法（OK / ERROR / STEP / DEBUG），由 logLine() 内部归一：
//   OK → SUCC、ERROR → ERR、STEP/DEBUG → INFO。调用点可以逐步改，不会漏着色。
#define LOG_INFO "INFO"
#define LOG_SUCC "SUCC"
#define LOG_WARN "WARN"
#define LOG_ERR  "ERR"

// 日志行
struct LogLine {
    std::string time;    // HH:mm:ss（写入时取本地时间，界面与落盘共用）
    std::string level;   // INFO / SUCC / WARN / ERR
    std::string text;    // 内容：操作名称 · 关键参数 · 结果
};

struct AppState {
    Page page = Page::Tool;
    Popup popup = Popup::None;

    // 界面主题：true = 深色（默认），false = 浅色。
    // 切换入口在左侧导航栏下方，选择结果写进 config.ini 的 [ui] theme。
    bool darkTheme = true;

    std::string selected = "kernelsu";
    std::vector<backend::InstallState> states;
    std::vector<std::string> versions;   // 与 states 对齐：各管理器已装版本

    backend::DeviceInfo device;
    backend::CheckResult lastCheck;

    bool busy = false;
    bool admin = false;
    std::string busyText;

    std::string pendingRootOutput;

    // 提权工具运行状态
    bool toolRunning = false;
    int toolExit = -1;
    std::string toolMode = "Refire";

    // 临时 root 实时状态（由设备监听线程周期性刷新）
    bool rootActive = false;
    std::string rootDetail;
    // 运行方式（对应 Neo10-Root.ps1 的 1/2/3）：Cold=开机模式并重启、Refire=已经重启过、
    // Interactive=不重启直接打。默认 Interactive，即「点一下就打，不预先重启」。
    std::string runMode = "Interactive";
    // 每个运行方式的中文名 + 一句说明，界面与日志共用
    static const char* runModeLabel(const std::string& mode);
    static const char* runModeHint(const std::string& mode);
    // 设备监听线程是否已启动
    bool deviceWatchStarted = false;
    // 主页设备详表的采样线程是否已启动
    bool homeWatchStarted = false;

    // ---- 主页（Home）----
    // 设备详表由主页采样线程周期刷新，页面只读这份快照渲染。
    backend::DeviceDetail detail;
    bool homeBusy = false;        // 正在采集（界面显示「正在读取…」）
    std::string homeNote;         // 上次刷新的时间 / 错误原因
    std::string homeSelectSerial; // 多设备时选中的序列号
    bool homeMultiDevice = false; // 快捷工具「多设备」
    bool homeDeviceCheck = true;  // 快捷工具「设备检测」
    bool homeToolCheck = false;   // 快捷工具「工具自检」
    bool homeKeepScreen = false;  // 快捷工具「保持亮屏」
    std::string homeWirelessIp;   // 无线调试用：手填 IP（空 = 自动从设备读）
    int homeWirelessPort = 5555;
    std::string homeAbSlot;       // 上次读到的槽位（_a/_b），界面直接显示
    bool homeWireless = false;    // 当前连的是不是无线调试
    // 待确认的重启动作。下拉里选「关机 / 重启到 Bootloader」这类不可撤销操作时，
    // 先写在这里让界面弹确认框，点「确认」才真正下发。空串表示没有待确认项。
    std::string pendingRebootTarget;
    std::string pendingRebootLabel;   // 「重启到 Bootloader」这类给人看的中文名

    // ---- 管理器更新检测（v3.1）----
    // 一次「检查更新」的结果快照，与 backend::managers() 同序同长。
    // 界面右侧「更新」卡片只读这份，不自己发网络请求。
    std::vector<backend::UpdateCheck> updates;
    bool updateChecking = false;       // 正在查（按钮显示「正在检查…」并禁用）
    bool updateCheckedOnce = false;    // 至少查过一次（决定空态文案）
    std::string updateNote;            // 「最近一次检查：HH:MM:SS · 3 项可更新」这类摘要

    // ---- 安卓投屏（scrcpy）----
    std::string mirrorSize = "1080";    // 0 = 原生
    std::string mirrorBitRate = "16";   // Mbps
    bool mirrorAudio = true;
    bool mirrorMouse = true;
    bool mirrorRecord = false;
    bool mirrorFullscreen = false;
    bool mirrorRunning = false;
    unsigned long long mirrorTask = 0;
    std::string mirrorRecordPath;       // 本次录屏落盘路径（启动时生成）
    std::string mirrorVersion;          // scrcpy --version 首行

    std::vector<LogLine> logs;
    // 日志自动跟随到底部：用户手动往上滚之后置 false，重新执行任务时再置 true
    bool logPin = true;
    // ---- 日志面板的三个视图操作（v3.0）----
    // 清屏只断开视图：s.logs 里的历史被截掉，但 logs\run-*.log 一直往后追加，导出总能拿到完整记录。
    bool logCollapsed = false;                          // 「收起」：面板只留 44px 标题条
    bool logExpanded = false;                           // 「放大」：日志堆叠到页面顶部并占满一屏
    std::vector<eui::Signal<float>*> logScrollTargets;  // 所有在用的日志面板滚动信号（收/展时要一起回底）
    eui::Signal<int> pageSignal{0};
    eui::Signal<int> managerSignal{0};
    eui::Signal<float> logScroll{0.0f};
    eui::Signal<float> managerScroll{0.0f};

    // 最近一帧的窗口内容尺寸，关闭时写回 config.ini
    float lastW = 0.0f;
    float lastH = 0.0f;

    AppState() {
        states.assign(backend::managers().size(), backend::InstallState::Unknown);
        versions.assign(backend::managers().size(), std::string());
        updates.assign(backend::managers().size(), backend::UpdateCheck());
    }
};

AppState& state();

// 后台线程（设备监听 / 提权工具输出 / adb 检测）会改 AppState，渲染线程同时在读，
// 因此所有读写都走这把递归锁：compose* 在函数入口整体持锁，写入点单独持锁。
std::recursive_mutex& stateMutex();

// 主题
components::theme::ThemeColorTokens theme();
eui::Transition motion();
eui::Color textPrimary();
eui::Color textMuted();
eui::Color textFaint();
eui::Color borderColor(float alpha = 1.0f);
eui::Color cardColor();
eui::Color mutedCardColor();
eui::Color hoverTint();      // 悬浮叠层（深色叠白 / 浅色叠黑）
eui::Color pressedTint();    // 按下叠层
eui::Color overlayTint(float alpha);  // 通用半透明叠层
eui::Color warnColor();      // 警告语义色（琥珀）
eui::Color warnCardColor();  // 警告条底色
eui::Color stateColor(backend::InstallState state);
eui::Color accentFor(const std::string& key);

// ---- 液态玻璃外观（AndroidLiquidGlass 2.0.0-alpha03）----
// 统一的玻璃参数工厂：theme().dark 决定内阴影/高光强度，所有控件共用同一套口径。
// 传进来的 radius 小于 0 时表示「跟随元素自身 radius」。
eui::GlassStyle glassSurface(float radius = -1.0f, float blur = 12.0f, float lensAmount = 10.0f);
// 按钮玻璃：普通 / 主要 两种，颜色与 theme() 对齐
eui::GlassStyle glassButton(bool primary, bool enabled);
// 轨道玻璃（Toggle 的底槽、单选胶囊的底）
eui::GlassStyle glassTrack(bool active, float radius = -1.0f);
// 旋钮玻璃（Toggle 的滑块）
eui::GlassStyle glassKnob();
void loadTheme();                       // 启动时从 config.ini 读回 [ui] theme
void setDarkTheme(bool dark);           // 切换主题并写盘 + 请求重绘
void applyWindowIconForTheme();         // 按当前主题换窗口/任务栏图标（WM_SETICON）
void applyTitlebarForTheme();           // 按当前主题把系统标题栏刷成深/浅（DWM）

// 日志
void logLine(const std::string& level, const std::string& text);
// 清空界面里的日志（磁盘上的 logs\run-*.log 保持完整，导出仍能拿到全部历史）
void clearLog();
// 把当前界面日志导出成 logs\export-*.log（带 BOM，记事本直接可读）
void actionExportLog();
// 收起 / 展开日志面板
void toggleLogCollapsed();
// 放大到整屏 / 还原（放大态与收起态互斥）
void setLogExpanded(bool on);
void toggleLogExpanded();
bool logExpanded();
// 日志面板滚动信号的登记与注销（composeLogPanel 每帧自动维护）
void registerLogScroll(eui::Signal<float>& signal);
void unregisterLogScroll(eui::Signal<float>& signal);

// 页面
void composeHome(eui::Ui& ui, float x, float y, float width, float height);
void composeTool(eui::Ui& ui, float x, float y, float width, float height);
void composeManagers(eui::Ui& ui, float x, float y, float width, float height);
void composeMirror(eui::Ui& ui, float x, float y, float width, float height);
void composeAbout(eui::Ui& ui, float x, float y, float width, float height);
void composeOverlays(eui::Ui& ui, const eui::Screen& screen);

// 可复用的日志面板（提权页右下角与独立的日志视图共用）
void composeLogPanel(eui::Ui& ui, const std::string& id, float x, float y,
                     float width, float height, int maxLines);

// 动作
void actionRefreshDevice();
void actionConnectDevice();   // 「连接设备」按钮：重启 adb 服务以触发手机授权弹窗
void actionCheckRoot();       // 「检测root」按钮：立刻探测临时 root
void actionRebootDevice();    // 「重启设备」按钮：adb reboot 并等回连
void setRunMode(const std::string& mode);   // 切换运行方式（写内存 + config.ini）
void startDeviceWatcher();    // 启动实时设备监听线程（启动时调一次）
void startHomeWatcher();      // 启动主页设备详表采样线程（启动时调一次）
void refreshHomeDetail();     // 立刻重采一次主页设备详表
void actionRebootInto(const std::string& target);  // 快捷重启
void actionSaveDeviceInfo();  // 主页底部「保存设备信息」
void actionOpenLogDir();      // 主页底部「打开日志目录」
void actionToggleWireless();  // 快捷工具「无线调试」：USB → tcpip/connect 双向切换
void actionSwitchSlot();      // 快捷工具「切换槽位」：bootctl set-active 另一槽
void actionUsb3Compat();      // 快捷工具「USB3.0补丁」：先体检，是 usb2 组合才改
void actionKeepScreen(bool on);   // 快捷工具「保持亮屏」
void actionCleanTemp();       // 快捷工具「清理临时文件」
void actionSelfCheck();       // 快捷工具「工具自检」：逐项体检 adb / 资源 / scrcpy
void actionDetectAll();
void actionInstall();
void actionUninstall();
void actionLaunch();
void actionElevate();
void actionOpenUrl(const std::string& url);
void actionOpenApkDir();
void actionRunTool(const std::string& mode, bool rebootOnFail = false);

// 管理器更新（v3.1）
// 点「检查更新」：并发查四个仓库的最新 release，与「内置版本 + 手机上已装版本」比对，
// 结果写进 state().updates，然后弹确认框列出需要更新的项。
void actionCheckUpdates();
// 确认框里点「全部更新」/ 单项更新：先 downloadApk 拉最新包，再 adb install -r -d。
void actionApplyUpdates(const std::vector<std::string>& keys);
// 需要更新的项（按 manager 顺序）。确认框和「更新」卡片共用同一份判定。
std::vector<std::string> pendingUpdateKeys();

// 安卓投屏（scrcpy）
void actionMirrorStart();      // 启动投屏
void actionMirrorStop();       // 停止投屏
void actionOpenRecordDir();    // 打开录屏目录
void actionOpenScrcpyDir();    // 打开 scrcpy 目录
void setMirrorSize(const std::string& size);   // 分辨率（"0" = 原生）
void setMirrorBitRate(const std::string& rate); // 码率（Mbps 数值）
void toggleMirrorOption(const std::string& key); // audio / mouse / record / fullscreen
void loadMirrorSettings();     // 启动时从 config.ini 读回投屏设置

// 统一按钮（内置禁用态样式：EUI-NEO 的 disabled() 只拦点击不改颜色）
components::ButtonStyle ui_button_style(bool primary, bool enabled);
void ui_button(eui::Ui& ui, const std::string& id, const std::string& text,
               unsigned int icon, float x, float y, float w, float h,
               bool primary, bool enabled, std::function<void()> onClick);
// 毛玻璃层：按钮表面叠一层半透明冷白底 + 内描边（无顶部高光），
// 让按钮/开关在保留原背景色的同时读起来像磨砂玻璃。
void ui_frost_overlay(eui::Ui& ui, const std::string& id, float x, float y, float w, float h,
                      float radius, bool primary, bool enabled);
// 细分隔线：1px 中性线 + 柔光 + 左侧短主题色标记，参考 PyQt-SiliconUI 的组标题。
void ui_divider(eui::Ui& ui, const std::string& id, float x, float y, float w,
                bool accent = true);
// 页面标题左侧的竖向色条。
void ui_title_accent(eui::Ui& ui, const std::string& id, float x, float y, float h);

// 通用小工具
std::string selectedName();
const backend::ManagerInfo& selectedManager();
int selectedIndex();
int indexOfManager(const std::string& key);   // 找不到返回 -1
backend::InstallState selectedState();
bool selectedInstalled();

} // namespace app
