#pragma once
// scrcpy 投屏封装：定位程序目录下的 assets\scrcpy，拼命令行，管理录屏目录。
// 实际进程启动/停止走 backend::runStreaming / cancelStreaming（见 app.cpp）。
#include <string>

namespace backend {

// 投屏参数
struct MirrorOptions {
    std::string maxSize = "1080";   // 0 = 原生分辨率
    std::string bitRate = "16";     // Mbps 数值，拼成 16M
    bool audio = true;              // 音频转发（关掉加 --no-audio）
    bool mouseControl = true;       // 鼠标控制手机（关掉加 --no-control）
    bool record = false;            // 录屏到文件
    bool fullscreen = false;        // 启动即全屏
    std::string recordPath;         // 为空时自动生成到 temp\record
};

// assets\scrcpy 目录（exe 同级）
std::string scrcpyDir();
std::string scrcpyExePath();
bool scrcpyAvailable();
// 读 scrcpy 版本号（同步执行 --version，失败返回 "未知"）
std::string scrcpyVersion();

// 录屏目录（程序目录\temp\record，自动创建）
std::string recordDir();
// 生成一个新的录屏文件路径（按时间戳）
std::string makeRecordPath();

// 拼 scrcpy 命令行（UTF-8 返回，内部会做引号处理）
std::string buildMirrorCommand(const std::string& serial, const MirrorOptions& opt);

// 给投屏窗口发 WM_CLOSE（让 scrcpy 自己正常退出、把录屏 mp4 收尾）。
// 返回找到并通知成功的窗口数；0 表示没找到窗口（可能已在退出）。
int closeMirrorWindow();

} // namespace backend
