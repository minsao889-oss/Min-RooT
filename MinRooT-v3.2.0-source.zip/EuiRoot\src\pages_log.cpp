#include "app.h"

#include <algorithm>

namespace app {
namespace {

// 按估算宽度截断（CJK 记一个字号宽，ASCII 记 0.55 个字号宽），超出补省略号
std::string fitText(const std::string& text, float maxWidth, float fontSize) {
    if (text.empty()) return text;
    float used = 0.0f;
    std::size_t index = 0;
    std::size_t cut = std::string::npos;
    while (index < text.size()) {
        const unsigned char lead = static_cast<unsigned char>(text[index]);
        std::size_t step = 1;
        if ((lead & 0x80u) == 0x00u) step = 1;
        else if ((lead & 0xE0u) == 0xC0u) step = 2;
        else if ((lead & 0xF0u) == 0xE0u) step = 3;
        else if ((lead & 0xF8u) == 0xF0u) step = 4;
        const bool wide = step > 1;
        const float advance = wide ? fontSize : fontSize * 0.55f;
        if (used + advance > maxWidth) {
            cut = index;
            break;
        }
        used += advance;
        index += step;
    }
    if (cut == std::string::npos) return text;
    return text.substr(0, cut) + "…";
}

// 日志级别色：四种固定语义，标签与正文同色。
//   INFO 白 / SUCC 绿 / WARN 黄 / ERR 红
// 浅色主题下同一语义要压暗，否则 #4CC38A / #E8B34B 这种亮绿亮黄在白底上几乎读不出来；
// INFO 在白底上也要收成深灰，纯白会直接消失。
eui::Color levelColor(const std::string& level) {
    const bool dark = state().darkTheme;
    if (level == LOG_SUCC) return dark ? eui::Color{0.298f, 0.765f, 0.541f, 1.0f}
                                       : eui::Color{0.106f, 0.549f, 0.361f, 1.0f};
    if (level == LOG_WARN) return dark ? eui::Color{0.949f, 0.757f, 0.322f, 1.0f}
                                       : eui::Color{0.686f, 0.478f, 0.078f, 1.0f};
    if (level == LOG_ERR) return dark ? eui::Color{0.949f, 0.400f, 0.400f, 1.0f}
                                      : eui::Color{0.792f, 0.196f, 0.216f, 1.0f};
    // INFO / 未知级别：深色下近白，浅色下近黑
    return dark ? eui::Color{0.925f, 0.937f, 0.961f, 1.0f}
                : eui::Color{0.129f, 0.149f, 0.184f, 1.0f};
}

// 时间戳列的宽度：SS 等宽字体下 8 个字符 = "HH:mm:ss"
constexpr float kStampW = 58.0f;
constexpr float kLevelW = 44.0f;

constexpr float kRowH = 22.0f;
// 收起态只留标题条：40(标题) + 1(分隔线) + 3
constexpr float kCollapsedH = 44.0f;

// 标题右侧的三个视图操作（清屏 / 导出 / 收起）。用自绘小描边块而不是
// components::button：这里要压到 22px 高，标准按钮的内边距会把标题条撑开。
// enabled=false 时保持可点，但走的是提示分支（例如日志已经空了还点「清屏」），
// 这样用户不会觉得按钮坏了——点了没反应的按钮比灰色的按钮更让人困惑。
void logAction(eui::Ui& ui, const std::string& id, const std::string& text,
               eui::Color accent, bool active, float x, float y, float w,
               std::function<void()> onClick, bool enabled = true,
               std::string disabledTip = std::string()) {
    components::panel(ui, id + ".hit", theme())
        .position(x, y).size(w, 20.0f)
        .radius(6.0f)
        .color(active ? accent : eui::Color{0.0f, 0.0f, 0.0f, 0.0f})
        .border(1.0f, enabled ? (active ? accent : borderColor(0.85f)) : borderColor(0.45f))
        .interactive(true)
        .hoverColor(active ? eui::Color{0.0f, 0.0f, 0.0f, 0.0f} : hoverTint())
        .pressedColor(pressedTint())
        .onClick(enabled ? std::move(onClick)
                         : std::function<void()>([disabledTip] {
                               if (!disabledTip.empty()) logLine(LOG_INFO, disabledTip);
                           }))
        .build();
    ui.text(id + ".txt")
        .position(x, y + 1.0f).size(w, 18.0f)
        .text(text).fontSize(11.5f).lineHeight(18.0f)
        .horizontalAlign(eui::HorizontalAlign::Center)
        .color(!enabled ? textFaint()
                        : (active ? eui::Color{1.0f, 1.0f, 1.0f, 1.0f} : textMuted()))
        .build();
}

} // namespace

// 日志面板：自上而下追加（最新的在最后一行），面板自带滚动条，可上下拖动翻看。
// 标题条右侧三个操作：清屏（只清视图）/ 导出（logs\export-*.log）/ 收起（只留 44px 标题条）。
// maxLines<=0 表示不限行数。
void composeLogPanel(eui::Ui& ui, const std::string& id, float x, float y,
                     float width, float height, int maxLines) {
    AppState& s = state();
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    // 收起态只要 44px 高，必须在「放不下就整体不画」的判断之前处理，
    // 否则 height<80 会把整个标题条吞掉，用户也就点不到「展开」了。
    if (width < 120.0f) return;
    if (!s.logCollapsed && height < 80.0f) return;

    // 收起态：只画标题条 + 三个操作按钮，把剩下的空间还给页面
    if (s.logCollapsed) {
        components::panel(ui, id + ".card", theme())
            .position(x, y).size(width, kCollapsedH)
            .radius(14.0f)
            .color(state().darkTheme ? eui::Color{0.043f, 0.051f, 0.066f, 1.0f}
                                     : eui::Color{0.976f, 0.980f, 0.988f, 1.0f})
            .border(1.0f, borderColor(0.6f))
            .build();
        ui.text(id + ".title")
            .position(x + 18.0f, y + 12.0f).size(200.0f, 20.0f)
            .text("运行日志（已收起 · " + std::to_string(s.logs.size()) + " 行）")
            .fontSize(13.0f).lineHeight(19.0f).fontWeight(740)
            .color(textPrimary()).build();
        if (width > 320.0f) {
            logAction(ui, id + ".act.expand", "展开", theme().primary, true,
                      x + width - 74.0f, y + 12.0f, 56.0f, [] { toggleLogCollapsed(); },
                      true, "展开日志面板（仍只占页面下半部分）");
        }
        if (width > 400.0f) {
            logAction(ui, id + ".act.big", "放大", theme().primary, false,
                      x + width - 136.0f, y + 12.0f, 56.0f, [] { setLogExpanded(true); },
                      true, "日志放大到整屏，再点「还原」恢复原布局");
        }
        return;
    }

    components::panel(ui, id + ".card", theme())
        .position(x, y).size(width, height)
        .radius(14.0f)
        .color(state().darkTheme ? eui::Color{0.043f, 0.051f, 0.066f, 1.0f}
                                 : eui::Color{0.976f, 0.980f, 0.988f, 1.0f})
        .border(1.0f, borderColor(0.6f))
        .build();

    ui.text(id + ".title")
        .position(x + 18.0f, y + 13.0f).size(200.0f, 20.0f)
        .text("运行日志").fontSize(13.0f).lineHeight(19.0f).fontWeight(740)
        .color(textPrimary()).build();

    // 标题条右侧：清屏 / 导出 / 放大(还原) / 收起。宽度不够就整组不画，避免压到标题上
    const float actY = y + 12.0f;
    const float actW = 52.0f;
    const float actGap = 6.0f;
    const float actRight = x + width - 14.0f;
    const bool showActions = width > 500.0f;
    const int actCount = 4;
    const float actLeft = actRight - actW * static_cast<float>(actCount) -
                          actGap * static_cast<float>(actCount - 1);
    if (showActions) {
        // 没有日志时「清屏」没有意义，置灰并让点击只给一句提示（见 logAction 的 enabled 分支）
        const bool hasLog = !s.logs.empty();
        logAction(ui, id + ".act.clear", "清屏", theme().primary, false,
                  actLeft, actY, actW, [] { clearLog(); },
                  hasLog, "已有 " + std::to_string(s.logs.size()) + " 行");
        logAction(ui, id + ".act.export", "导出", theme().primary, false,
                  actLeft + actW + actGap, actY, actW, [] { actionExportLog(); },
                  true, "另存为 logs\\export-*.log");
        const bool big = logExpanded();
        logAction(ui, id + ".act.big", big ? "还原" : "放大", theme().primary,
                  big, actLeft + (actW + actGap) * 2.0f, actY, actW,
                  [] { toggleLogExpanded(); },
                  true, "日志放大到整屏，再点「还原」恢复原布局");
        logAction(ui, id + ".act.collapse", "收起", theme().primary, false,
                  actRight - actW, actY, actW, [] { toggleLogCollapsed(); },
                  true, "只留标题条，把空间还给页面");
    }
    if (width > 360.0f) {
        // 提示文字往左让出四个按钮的位置；放不下就不画（按钮优先）
        const float hintW = showActions ? 200.0f : 280.0f;
        const float hintX = showActions ? actLeft - hintW - 12.0f
                                        : x + width - 298.0f;
        if (hintX > x + 180.0f) {
            ui.text(id + ".hint")
                .position(hintX, y + 13.0f).size(hintW, 20.0f)
                .text("实时输出 · 可滚动查看 · 同时写入 logs\\ 目录")
                .fontSize(12.0f).lineHeight(18.0f)
                .horizontalAlign(eui::HorizontalAlign::Right)
                .color(textFaint()).build();
        }
    }

    components::panel(ui, id + ".sep", theme())
        .position(x + 1.0f, y + 40.0f).size(width - 2.0f, 1.0f)
        .radius(0.5f).color(borderColor(0.55f)).build();

    const float bodyTop = y + 46.0f;
    const float bodyH = std::max(24.0f, height - 52.0f);

    const int total = static_cast<int>(s.logs.size());
    // maxLines<=0 表示「不限行数」：日志面板收到最大时把攒下的历史全画出来
    const int readCount = (maxLines <= 0) ? total : maxLines;
    const int limit = std::max(1, readCount);
    const int start = std::max(0, total - limit);
    const int count = total - start;
    const float contentH = std::max(bodyH, static_cast<float>(count) * kRowH + 10.0f);
    // 左右各留 10px，再让出「时间戳 + 级别标签」两列，剩余宽度给正文
    const float textW = std::max(40.0f, width - 8.0f - 112.0f);
    AppState* sp = &s;
    // 收/展时要把所有日志面板一起拉到底，所以把滚动信号登记到 state
    registerLogScroll(s.logScroll);

    components::scrollView(ui, id + ".sv")
        .position(x + 4.0f, bodyTop)
        .size(width - 8.0f, bodyH)
        .theme(theme())
        .step(kRowH * 2.0f)
        .scrollbarWidth(8.0f)
        .scrollbarGap(6.0f)
        .offset(s.logScroll.get())
        .onChange([sp](float value) {
            sp->logScroll.set(value);
            // 用户手动滚动后就不再强行贴底，避免「滚动条自己弹回去」
            sp->logPin = false;
        })
        .transition(motion())
        .content([&](eui::Ui& cu, float cw, float) {
            cu.stack(id + ".canvas")
                .size(cw, contentH)
                .clip()
                .content([&] {
                    if (count == 0) {
                        cu.text(id + ".empty")
                            .position(14.0f, 8.0f).size(textW, 20.0f)
                            .text("暂无日志").fontSize(13.0f).lineHeight(18.0f)
                            .color(textFaint()).build();
                        return;
                    }
                    // 每行三列固定排版：HH:mm:ss | [级别] | 内容
                    // 三列宽度写死，级别标识长度统一（INFO/SUCC/WARN/ERR 都是 4 字符），
                    // 所以正文左边缘永远对齐——不用再靠补空格去凑列宽。
                    for (int i = 0; i < count; ++i) {
                        const LogLine& line = s.logs[static_cast<size_t>(start + i)];
                        const float ly = 4.0f + static_cast<float>(i) * kRowH;
                        const std::string row = std::to_string(i);
                        const eui::Color tone = levelColor(line.level);

                        cu.text(id + ".time." + row)
                            .position(10.0f, ly).size(kStampW, 20.0f)
                            .text(line.time)
                            .fontSize(12.0f).lineHeight(18.0f)
                            .color(textFaint()).build();
                        cu.text(id + ".tag." + row)
                            .position(10.0f + kStampW + 4.0f, ly).size(kLevelW, 20.0f)
                            .text("[" + line.level + "]")
                            .fontSize(12.0f).lineHeight(18.0f)
                            .color(tone).build();
                        cu.text(id + ".txt." + row)
                            .position(10.0f + kStampW + 4.0f + kLevelW + 6.0f, ly).size(textW, 20.0f)
                            .text(fitText(line.text, textW, 13.0f))
                            .fontSize(13.0f).lineHeight(18.0f)
                            .color(tone)
                            .build();
                    }
                })
                .build();
        })
        .build();
}

} // namespace app
