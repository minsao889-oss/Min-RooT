#include "app.h"

#include <algorithm>
#include <cstdio>
#include "ui_toggle.h"

namespace app {
namespace {

using backend::InstallState;

void card(eui::Ui& ui, const std::string& id, float x, float y, float w, float h,
          eui::Color color, float radius, float borderAlpha) {
    liquid::glassCard(ui, id, x, y, w, h, radius, color);
}

// 单张管理器卡片（紧凑版：高度由外部按窗口尺寸计算）
void managerCard(eui::Ui& ui, size_t index, const backend::ManagerInfo& info,
                 float x, float y, float w, float h) {
    AppState& s = state();
    const bool isSelected = (s.selected == info.key);
    const InstallState st = s.states[index];
    const eui::Color accent = accentFor(info.key);

    // 选中态：深色主题提亮、浅色主题压暗（用主题色 of surface 混合，两边都不脏）
    const eui::Color bg = isSelected
        ? (theme().dark ? eui::Color{0.129f, 0.145f, 0.180f, 1.0f}
                        : eui::Color{0.929f, 0.945f, 0.976f, 1.0f})
        : cardColor();
    const float radius = 14.0f;

    ui.stack("mgr.card." + info.key)
        .position(x, y).size(w, h)
        .content([&] {
            // 选中描边（外圈）
            components::panel(ui, "mgr.card.border." + info.key, theme())
                .size(w, h)
                .radius(radius + 2.0f)
                .color(isSelected ? components::theme::withOpacity(accent, 0.85f)
                                  : components::theme::withOpacity(borderColor(1.0f), 0.55f))
                .build();
            // 主体
            components::panel(ui, "mgr.card.bg." + info.key, theme())
                .position(1.5f, 1.5f).size(w - 3.0f, h - 3.0f)
                .radius(radius)
                .color(bg)
                .build();

            // 左侧色条
            components::panel(ui, "mgr.card.bar." + info.key, theme())
                .position(7.0f, 14.0f).size(3.0f, std::max(20.0f, h - 28.0f))
                .radius(1.5f)
                .color(isSelected ? accent : components::theme::withOpacity(accent, 0.40f))
                .build();

            // 名称
            ui.text("mgr.name." + info.key)
                .position(20.0f, 14.0f).size(w - 118.0f, 24.0f)
                .text(info.name).fontSize(17.0f).lineHeight(23.0f).fontWeight(770)
                .color(textPrimary()).build();

            // 状态徽章
            const eui::Color sc = stateColor(st);
            const float badgeW = 76.0f;
            const float badgeX = w - badgeW - 16.0f;
            components::panel(ui, "mgr.badge.bg." + info.key, theme())
                .position(badgeX, 15.0f).size(badgeW, 23.0f)
                .radius(11.5f)
                .color(components::theme::withOpacity(sc, 0.16f))
                .border(1.0f, components::theme::withOpacity(sc, 0.50f))
                .build();
            components::panel(ui, "mgr.badge.dot." + info.key, theme())
                .position(badgeX + 10.0f, 23.5f).size(6.0f, 6.0f)
                .radius(3.0f).color(sc).build();
            ui.text("mgr.badge.txt." + info.key)
                .position(badgeX + 22.0f, 18.0f).size(badgeW - 28.0f, 18.0f)
                .text(backend::stateLabel(st)).fontSize(11.5f).lineHeight(17.0f)
                .color(sc).build();

            // 描述
            const float descH = std::max(18.0f, h - 52.0f - 38.0f);
            ui.text("mgr.desc." + info.key)
                .position(20.0f, 46.0f).size(w - 40.0f, descH)
                .text(info.description).fontSize(13.0f).lineHeight(19.0f)
                .wrap(true).color(textMuted()).build();

            // 包名 · 版本
            ui_divider(ui, "mgr.card.rule." + info.key, 20.0f, h - 40.0f,
                       std::max(1.0f, w - 40.0f), true);
            ui.text("mgr.meta." + info.key)
                .position(20.0f, h - 28.0f).size(w - 40.0f, 16.0f)
                .text(info.package + "   ·   " + info.version).fontSize(11.5f)
                .lineHeight(16.0f).color(textFaint()).build();

            // 点击热区（放最上层）
            components::panel(ui, "mgr.card.hit." + info.key, theme())
                .size(w, h)
                .radius(radius + 2.0f)
                .color({0.0f, 0.0f, 0.0f, 0.0f})
                .interactive(true)
                .hoverColor(hoverTint())
                .pressedColor(pressedTint())
                .onClick([key = info.key, idx = index] {
                    AppState& inner = state();
                    inner.selected = key;
                    inner.managerSignal.set(static_cast<int>(idx));
                    logLine(LOG_INFO, "选择管理器 · " + backend::managers()[idx].name);
                })
                .build();
        })
        .build();
}

void infoRow(eui::Ui& ui, const std::string& id, const std::string& title,
             const std::string& value, float x, float y, float w, eui::Color color,
             float titleW = 84.0f) {
    ui.text(id + ".t")
        .position(x, y).size(titleW, 20.0f)
        .text(title).fontSize(13.0f).lineHeight(19.0f).color(textFaint()).build();
    ui.text(id + ".v")
        .position(x + titleW + 6.0f, y).size(w - titleW - 6.0f, 20.0f)
        .text(value).fontSize(13.0f).lineHeight(19.0f).color(color).build();
}

} // namespace

void composeManagers(eui::Ui& ui, float x, float y, float width, float height) {
    AppState& s = state();
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    const float left = x + 34.0f;
    const float w = width - 68.0f;
    const float bottom = y + height - 44.0f;   // 给 footer 留位

    ui.text("mg.title")
        .position(left, y + 24.0f).size(w, 32.0f)
        .text("选择 Root 管理器").fontSize(24.0f).lineHeight(30.0f).fontWeight(800)
        .color(textPrimary()).build();
    ui.text("mg.sub")
        .position(left, y + 60.0f).size(w, 22.0f)
        .text("四选一 · 安装后需通过状态检测才可提权")
        .fontSize(14.0f).lineHeight(20.0f).color(textMuted()).build();

    // ---------------- 放大态：只画日志，从副标题下方铺到 footer
    if (s.logExpanded) {
        const float bigTop = y + 88.0f;
        composeLogPanel(ui, "mg.log", left, bigTop, w,
                        std::max(160.0f, bottom - bigTop), 0);
        return;
    }

    // 网格 / 详情 / 日志三段自适应：卡片保持紧凑，多余空间给日志
    const float gridTop = y + 96.0f;
    const float gap = 16.0f;
    const float contentH = std::max(320.0f, bottom - gridTop);
    const float cardH = std::clamp(contentH * 0.185f, 116.0f, 152.0f);
    const float gridH = cardH * 2.0f + gap;
    const float blockTop = gridTop + gridH + gap;
    const float blockH = std::max(150.0f, bottom - blockTop);
    const float cardW = (w - gap) * 0.5f;

    const auto& list = backend::managers();
    for (size_t i = 0; i < list.size(); ++i) {
        const int col = static_cast<int>(i % 2);
        const int row = static_cast<int>(i / 2);
        const float cx = left + static_cast<float>(col) * (cardW + gap);
        const float cy = gridTop + static_cast<float>(row) * (cardH + gap);
        managerCard(ui, i, list[i], cx, cy, cardW, cardH);
    }

    // 底部左右分栏：左＝详情，右＝运行日志
    const float logGap = 16.0f;
    const float detailW = std::max(430.0f, (w - logGap) * 0.50f);
    const float logW = w - detailW - logGap;
    const float detailH = blockH;

    const auto& info = selectedManager();
    card(ui, "mg.detail.card", left, blockTop, detailW, detailH, mutedCardColor(), 16.0f, 0.6f);

    ui.text("mg.detail.name")
        .position(left + 22.0f, blockTop + 14.0f).size(detailW - 44.0f, 24.0f)
        .text(info.name + "    " + info.version).fontSize(16.0f).lineHeight(22.0f)
        .fontWeight(740).color(textPrimary()).build();

    const float rowW = detailW - 44.0f;
    ui_divider(ui, "mg.detail.rule", left + 22.0f, blockTop + 41.0f, rowW, true);
    infoRow(ui, "mg.row.url", "下载页", info.url, left + 22.0f, blockTop + 44.0f, rowW,
            components::theme::withOpacity(theme().primary, 1.0f), 64.0f);
    infoRow(ui, "mg.row.apk", "安装包", info.apkFile + "   ·   " + info.installerType,
            left + 22.0f, blockTop + 68.0f, rowW, textMuted(), 64.0f);
    infoRow(ui, "mg.row.pkg", "包名", info.package, left + 22.0f, blockTop + 92.0f, rowW,
            textMuted(), 64.0f);
    infoRow(ui, "mg.row.chk", "检测方式", "adb shell pm list packages + dumpsys versionName",
            left + 22.0f, blockTop + 116.0f, rowW, textMuted(), 64.0f);
    const int selIdx = selectedIndex();
    const backend::InstallState selState = selectedState();
    // 先算「有没有可更新项」，后面按钮和状态行都要用
    const std::vector<std::string> updKeys = pendingUpdateKeys();
    const bool anyUpdate = !updKeys.empty();

    infoRow(ui, "mg.row.state", "当前状态", backend::stateLabel(selState),
            left + 22.0f, blockTop + 140.0f, rowW, stateColor(selState), 64.0f);
    const std::string installedVer = (selIdx >= 0 && selIdx < static_cast<int>(s.versions.size()))
        ? s.versions[static_cast<size_t>(selIdx)] : std::string();
    infoRow(ui, "mg.row.ver", "已装版本",
            installedVer.empty() ? "—" : installedVer,
            left + 22.0f, blockTop + 164.0f, rowW, textMuted(), 64.0f);

    // 第五行：上游最新版本 + 是否需要更新。查过之后才显示，没查过留空。
    {
        const bool hasResult = selIdx >= 0 && selIdx < static_cast<int>(s.updates.size()) &&
                               s.updates[static_cast<size_t>(selIdx)].ok;
        std::string latestText = "—";
        eui::Color latestColor = textFaint();
        if (hasResult) {
            const backend::UpdateCheck& uc = s.updates[static_cast<size_t>(selIdx)];
            latestText = uc.latestVersion.empty() ? "—" : uc.latestVersion;
            if (uc.hasUpdate) {
                latestText += "   ·   可更新";
                latestColor = theme().primary;
            } else if (uc.installed) {
                latestText += "   ·   已是最新";
                latestColor = textMuted();
            } else {
                latestText += "   ·   未安装";
                latestColor = textMuted();
            }
        }
        infoRow(ui, "mg.row.latest", "上游最新", latestText,
                left + 22.0f, blockTop + 188.0f, rowW, latestColor, 64.0f);
    }

    // 按钮两行：上排次级操作，下排主操作（右对齐）
    const bool installed = selectedInstalled();
    const float primaryY = blockTop + detailH - 52.0f;
    const float secondaryY = primaryY - 44.0f;

    // 「检查更新」的结果摘要：贴在按钮组上方，一句话说清「查了没有 / 几项要更新」
    if (!s.updateNote.empty() && secondaryY - 26.0f > blockTop + 210.0f) {
        ui.text("mg.upd.note")
            .position(left + 22.0f, secondaryY - 26.0f).size(rowW, 18.0f)
            .text(s.updateNote).fontSize(12.0f).lineHeight(17.0f)
            .color(anyUpdate ? theme().primary : textFaint()).build();
    }

    // 中间提示区（空间够才画）。日志收起时把这部分高度放开，避免右侧空着、
    // 左侧卡片下半截也跟着留白——提示区吃掉的就是日志让出来的那块。
    // 同时跟着放开的还有下面几行「补充说明」，否则空出来的高度还是白的。
    const float tipTop = blockTop + 218.0f;
    const float tipMax = s.logCollapsed ? std::max(92.0f, detailH - 340.0f) : 92.0f;
    float tipBottom = tipTop;
    if (secondaryY - tipTop > 52.0f) {
        const float tipH = std::max(52.0f, std::min(tipMax, secondaryY - tipTop - 10.0f));
        tipBottom = tipTop + tipH;
        components::panel(ui, "mg.detail.tip.card", theme())
            .position(left + 22.0f, tipTop).size(rowW, tipH)
            .radius(10.0f)
            .color(overlayTint(0.022f))
            .border(1.0f, borderColor(0.45f))
            .build();
        ui.text("mg.detail.tip.title")
            .position(left + 36.0f, tipTop + 12.0f).size(rowW - 28.0f, 18.0f)
            .text("使用顺序").fontSize(12.0f).lineHeight(17.0f).fontWeight(700)
            .color(textFaint()).build();
        // 正文按可用高度决定要塞几条：收起态空间多，就把平时放不下的补充说明一起摊开，
        // 而不是让卡片空着。
        std::string tipBody = "1. 选卡片 → 2. 安装 → 3. 检测 → 4. 提权页";
        if (tipH > 80.0f) {
            tipBody += "\n换管理器前先卸载旧管理器。";
        }
        if (tipH > 150.0f) {
            tipBody +=
                "\n\n"
                "· 安装包随程序加密分发，点「安装包目录」可查看已释放的文件；\n"
                "· 「检测状态」走 pm list packages + dumpsys versionName，只读不改设备；\n"
                "· 卸载走 pm uninstall，卸载后临时 root 会失效，需要重新执行提权；\n"
                "· 装完先点「打开管理器」授权一次，再回「提权」页执行。";
        }
        ui.text("mg.detail.tip.body")
            .position(left + 36.0f, tipTop + 32.0f).size(rowW - 28.0f, tipH - 40.0f)
            .text(tipBody)
            .fontSize(12.5f).lineHeight(19.0f).wrap(true)
            .color(textMuted()).build();
    }

    // 按钮排布改成「按可用宽度等分」，彻底不再用固定坐标拼：
    // 详情卡宽度随窗口变化（detailW 最小 430），任何写死的 left+376 / detailW-148
    // 在窄窗口下都会互相压。这里用 btnGap 均分，行内所有格子一定不重叠。
    const float padX = 22.0f;
    const float btnH = 34.0f;
    const float btnGap = 8.0f;

    // 上排：打开下载页 / 安装包目录 / 卸载 / 打开管理器（四等分）
    {
        const float rowW2 = detailW - padX * 2.0f;
        const float bw = (rowW2 - btnGap * 3.0f) / 4.0f;
        ui_button(ui, "mg.btn.url", "打开下载页", 0xF08E,
                  left + padX, secondaryY, bw, btnH, false, true,
                  [url = info.url] { actionOpenUrl(url); });
        ui_button(ui, "mg.btn.apkdir", "安装包目录", 0xF07B,
                  left + padX + (bw + btnGap), secondaryY, bw, btnH, false, true,
                  [] { actionOpenApkDir(); });
        ui_button(ui, "mg.btn.uninstall", "卸载", 0xF2ED,
                  left + padX + (bw + btnGap) * 2.0f, secondaryY, bw, btnH, false,
                  !(!installed || s.busy), [] { actionUninstall(); });
        ui_button(ui, "mg.btn.launch", "打开管理器", 0xF2D2,
                  left + padX + (bw + btnGap) * 3.0f, secondaryY, bw, btnH, false,
                  !(!installed || s.busy), [] { actionLaunch(); });
    }

    // 下排：检测状态 / 安装所选 / 检查更新（右对齐三格，五五分之外剩余空间给「检查更新」）
    {
        const float insW = 106.0f;
        const float detW2 = 118.0f;
        const float rightEdge = left + detailW - padX;
        const float priY = primaryY;
        ui_button(ui, "mg.btn.install", "安装所选", 0xF019,
                  rightEdge - insW, priY, insW, btnH, true, !s.busy,
                  [] { actionInstall(); });
        ui_button(ui, "mg.btn.detect", "检测状态", 0xF021,
                  rightEdge - insW - btnGap - detW2, priY, detW2, btnH, false, !s.busy,
                  [] { actionDetectAll(); });
        const float updRight = rightEdge - insW - btnGap - detW2 - btnGap;
        const float updW2 = std::max(96.0f, std::min(140.0f, updRight - (left + padX)));
        ui_button(ui, "mg.btn.updcheck",
                  s.updateChecking ? "正在检查…" : (anyUpdate ? "检查更新 · 有新版" : "检查更新"),
                  0xF0E4, updRight - updW2, priY, updW2, btnH,
                  anyUpdate, !s.busy && !s.updateChecking,
                  [] { actionCheckUpdates(); });
    }

    // 右侧运行日志（收起时只留 44px 标题条，与提权页表现一致）
    const float logX = left + detailW + logGap;
    // 日志收起后，省下的高度把详细的「使用顺序」提示区撑满（原来只给 92px 上限，
    // 收起时中间会留一大块空卡）。布局上限跟着 detailH 走，但不超过日志那块的高度。
    const int maxLines = s.logCollapsed
                             ? 0
                             : static_cast<int>(std::max(3.0f, (detailH - 64.0f) / 22.0f));
    composeLogPanel(ui, "mg.log", logX, blockTop, logW,
                    s.logCollapsed ? 44.0f : detailH, maxLines);
}

} // namespace app
