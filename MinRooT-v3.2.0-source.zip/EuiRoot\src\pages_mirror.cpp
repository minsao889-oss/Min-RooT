#include "app.h"

#include "backend/workspace.h"
#include "ui_toggle.h"

#include <algorithm>
#include <string>

namespace app {
namespace {

using namespace eui;

// 小圆角面板
void panel(eui::Ui& ui, const std::string& id, float x, float y, float w, float h,
           eui::Color color, float radius = 14.0f) {
    liquid::glassCard(ui, id, x, y, w, h, radius, color);
}

// 一行小标签
void rowLabel(eui::Ui& ui, const std::string& id, const std::string& text,
              float x, float y, float w) {
    ui.text(id)
        .position(x, y)
        .size(w, 20.0f)
        .text(text)
        .fontSize(13.0f)
        .lineHeight(19.0f)
        .color(textMuted())
        .build();
}

// 可选小胶囊（单选）
void chip(eui::Ui& ui, const std::string& id, const std::string& text,
          float x, float y, float w, float h, bool active, std::function<void()> onClick) {
    // 液态玻璃胶囊：选中态把强调色压进 surfaceColor，未选中态是中性玻璃
    ui.rect(id + ".bg")
        .position(x, y).size(w, h)
        .radius(9.0f)
        .glass(glassTrack(active, 9.0f))
        .color(components::theme::withAlpha(theme().primary, 0.0f))
        .transition(motion())
        .build();
    if (active) {
        components::panel(ui, id + ".line", theme())
            .position(x, y).size(w, h)
            .color(components::theme::withAlpha(theme().primary, 0.0f))
            .border(1.4f, theme().primary)
            .radius(9.0f)
            .build();
    }
    ui.text(id + ".t")
        .position(x, y)
        .size(w, h)
        .text(text)
        .fontSize(13.0f)
        .lineHeight(18.0f)
        .fontWeight(active ? 720 : 600)
        .color(active ? theme().text : textMuted())
        .horizontalAlign(HorizontalAlign::Center)
        .verticalAlign(VerticalAlign::Center)
        .build();
    components::panel(ui, id + ".hit", theme())
        .position(x, y).size(w, h)
        .color(components::theme::withAlpha(theme().text, 0.0f))
        .radius(9.0f)
        .interactive(true)
        .hoverColor(components::theme::withAlpha(theme().text, 0.04f))
        .pressedColor(components::theme::withAlpha(theme().text, 0.08f))
        .onClick(std::move(onClick))
        .build();
}

// 开关行（左侧标题 + 右侧 ON/OFF 胶囊）
void toggleRow(eui::Ui& ui, const std::string& id, const std::string& title,
               const std::string& hint, float x, float y, float w,
               bool value, std::function<void()> onToggle) {
    ui.text(id + ".title")
        .position(x, y).size(w * 0.55f, 22.0f)
        .text(title).fontSize(13.5f).lineHeight(20.0f).fontWeight(660)
        .color(theme().text).build();
    ui.text(id + ".hint")
        .position(x + w * 0.55f, y + 1.0f).size(w * 0.28f, 20.0f)
        .text(hint).fontSize(12.0f).lineHeight(18.0f).color(textFaint()).build();

    // 液态玻璃胶囊开关：与主页 toggleSwitch 共用 ui_toggle.h 里的弹簧实现
    // （旧版本这里重复实现了一份，只有 .transition(motion()) 的补间）
    const float cw = liquid::kTrackW;
    const float ch = liquid::kTrackH;
    liquid::toggle(ui, id + ".sw", x + w - cw, y - 3.0f, value, std::move(onToggle),
                   components::theme::withAlpha(theme().text, 0.05f),
                   components::theme::withAlpha(theme().text, 0.10f),
                   /*panelHit=*/true);
}

}  // namespace

void composeMirror(eui::Ui& ui, float x, float y, float width, float height) {
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    AppState& s = state();

    const float pad = 32.0f;
    const float left = x + pad;
    const float contentW = width - pad * 2.0f;

    // ---- 标题 ----
    ui.text("mr.title")
        .position(left, y + 24.0f).size(contentW, 34.0f)
        .text("安卓投屏").fontSize(31.0f).lineHeight(38.0f).fontWeight(800)
        .color(theme().text).build();
    ui.text("mr.sub")
        .position(left, y + 62.0f).size(contentW, 22.0f)
        .text("基于 scrcpy 的实时投屏 · 鼠标可直接操作手机 · 支持录屏与音频转发")
        .fontSize(14.0f).lineHeight(20.0f).color(textMuted()).build();

    // ---------------- 放大态：只画日志，从副标题下方铺到页面底部
    if (s.logExpanded) {
        const float bigTop = y + 88.0f;
        composeLogPanel(ui, "mr.log", left, bigTop, contentW,
                        std::max(160.0f, (y + height - 44.0f) - bigTop), 0);
        return;
    }

    float cursor = y + 100.0f;

    // ---- 状态卡 ----
    const float statusH = 92.0f;
    panel(ui, "mr.status", left, cursor, contentW, statusH, theme().surface, 16.0f);
    {
        const bool ok = s.mirrorRunning;
        const bool ready = s.device.ready;
        eui::Color dot = ok ? stateColor(backend::InstallState::Installed)
                            : (ready ? stateColor(backend::InstallState::Installing)
                                     : stateColor(backend::InstallState::NotInstalled));
        panel(ui, "mr.status.dot", left + 22.0f, cursor + 24.0f, 9.0f, 9.0f, dot, 5.0f);
        ui.text("mr.status.state")
            .position(left + 40.0f, cursor + 19.0f).size(220.0f, 22.0f)
            .text(ok ? "投屏运行中" : (ready ? "设备就绪，可以投屏" : "未连接设备"))
            .fontSize(14.5f).lineHeight(20.0f).fontWeight(700)
            .color(ok ? dot : theme().text).build();

        const std::string devText = ready
            ? s.device.serial + "   ·   " + s.device.model + "   ·   Android " + s.device.android
            : std::string("点左下角「连接设备」重启 adb 服务并授权 USB 调试");
        ui.text("mr.status.dev")
            .position(left + 40.0f, cursor + 45.0f).size(contentW - 380.0f, 20.0f)
            .text(devText).fontSize(12.5f).lineHeight(18.0f).color(textMuted()).build();

        const std::string ver = s.mirrorVersion.empty() ? std::string("scrcpy 未检测") : s.mirrorVersion;
        ui.text("mr.status.ver")
            .position(left + contentW - 340.0f, cursor + 22.0f).size(316.0f, 20.0f)
            .text(ver).fontSize(12.5f).lineHeight(18.0f)
            .color(textFaint())
            .horizontalAlign(HorizontalAlign::Right).build();
        ui.text("mr.status.rec")
            .position(left + contentW - 340.0f, cursor + 45.0f).size(316.0f, 20.0f)
            .text(s.mirrorRecord ? "录屏已开启 → temp\\record" : "录屏未开启")
            .fontSize(12.0f).lineHeight(18.0f).color(textFaint())
            .horizontalAlign(HorizontalAlign::Right).build();
    }
    cursor += statusH + 16.0f;

    // ---- 设置卡 ----
    const float setH = 208.0f;
    panel(ui, "mr.set", left, cursor, contentW, setH, theme().surface, 16.0f);
    {
        const float inX = left + 22.0f;
        const float inW = contentW - 44.0f;

        // 分辨率
        rowLabel(ui, "mr.size.label", "分辨率", inX, cursor + 18.0f, 90.0f);
        const char* sizes[] = {"原生", "1920", "1280", "1080", "800"};
        const char* sizeVal[] = {"0", "1920", "1280", "1080", "800"};
        const float chipW = std::min(96.0f, (inW - 90.0f - 8.0f * 4.0f) / 5.0f);
        for (int i = 0; i < 5; ++i) {
            const std::string key = sizeVal[i];
            const float cx = inX + 90.0f + i * (chipW + 8.0f);
            chip(ui, "mr.size." + key, sizes[i], cx, cursor + 12.0f, chipW, 30.0f,
                 s.mirrorSize == key, [key] { setMirrorSize(key); });
        }

        // 码率
        rowLabel(ui, "mr.br.label", "码率", inX, cursor + 62.0f, 90.0f);
        const char* rates[] = {"4M", "8M", "16M", "32M", "64M"};
        const char* rateVal[] = {"4", "8", "16", "32", "64"};
        for (int i = 0; i < 5; ++i) {
            const std::string key = rateVal[i];
            const float cx = inX + 90.0f + i * (chipW + 8.0f);
            chip(ui, "mr.br." + key, rates[i], cx, cursor + 56.0f, chipW, 30.0f,
                 s.mirrorBitRate == key, [key] { setMirrorBitRate(key); });
        }

        // 开关四行（两列）
        const float colW = (inW - 24.0f) * 0.5f;
        toggleRow(ui, "mr.audio", "音频转发", "把手机声音转到电脑",
                  inX, cursor + 104.0f, colW, s.mirrorAudio, [] { toggleMirrorOption("audio"); });
        toggleRow(ui, "mr.mouse", "鼠标控制", "点窗口即可操作手机",
                  inX + colW + 24.0f, cursor + 104.0f, colW, s.mirrorMouse,
                  [] { toggleMirrorOption("mouse"); });
        toggleRow(ui, "mr.record", "录屏保存", "自动存到 temp\\record",
                  inX, cursor + 146.0f, colW, s.mirrorRecord, [] { toggleMirrorOption("record"); });
        toggleRow(ui, "mr.full", "启动即全屏", "省得再按 Ctrl+F",
                  inX + colW + 24.0f, cursor + 146.0f, colW, s.mirrorFullscreen,
                  [] { toggleMirrorOption("fullscreen"); });
    }
    cursor += setH + 16.0f;

    // ---- 按钮行 ----
    const float btnH = 52.0f;
    const float gap = 12.0f;
    const float btnW = (contentW - gap * 3.0f) / 4.0f;
    const bool canStart = s.device.ready && !s.mirrorRunning;
    ui_button(ui, "mr.btn.start", s.mirrorRunning ? "投屏中…" : "启动投屏", 0xF26C,
              left, cursor, btnW, btnH, true, canStart, [] { actionMirrorStart(); });
    ui_button(ui, "mr.btn.stop", "停止投屏", 0xF04D,
              left + (btnW + gap), cursor, btnW, btnH, false, s.mirrorRunning,
              [] { actionMirrorStop(); });
    ui_button(ui, "mr.btn.rec", "录屏目录", 0xF07B,
              left + (btnW + gap) * 2.0f, cursor, btnW, btnH, false, true,
              [] { actionOpenRecordDir(); });
    ui_button(ui, "mr.btn.dir", "scrcpy 目录", 0xF07C,
              left + (btnW + gap) * 3.0f, cursor, btnW, btnH, false, true,
              [] { actionOpenScrcpyDir(); });
    cursor += btnH + 16.0f;

    // ---- 说明卡 ----
    const float noteH = std::max(120.0f, y + height - 56.0f - cursor);
    panel(ui, "mr.note", left, cursor, contentW, noteH, theme().surface, 16.0f);
    {
        const float tx = left + 22.0f;
        const float tw = contentW - 44.0f;
        ui.text("mr.note.t")
            .position(tx, cursor + 16.0f).size(tw, 20.0f)
            .text("使用说明").fontSize(13.0f).lineHeight(19.0f).fontWeight(740)
            .color(theme().text).build();

        const char* lines[] = {
            "1. 投屏窗口内鼠标左键 = 触摸点按，滚轮 = 上下滑动，键盘可直接输入中文。",
            "2. 窗口里按 Ctrl+F 切全屏，Ctrl+Shift+F 全屏且锁定鼠标，Esc 退出全屏。",
            "3. 关掉投屏窗口或点「停止投屏」即结束；录屏会边投边写 mp4，停止后自动收尾。",
            "4. 声音走 scrcpy 的音频转发（Android 11+ 才有声音）；没声音先确认系统输出设备。",
            "5. 连接不稳时把分辨率降到 1280、码率降到 8M，能明显减少卡顿。",
            "6. scrcpy 版本与文件已随程序加密打包分发，运行时自动释放，无需手动放目录。",
        };
        const float lineY = cursor + 42.0f;
        for (int i = 0; i < 6; ++i) {
            ui.text("mr.note." + std::to_string(i))
                .position(tx, lineY + i * 22.0f).size(tw, 20.0f)
                .text(lines[i]).fontSize(12.5f).lineHeight(19.0f).color(textMuted()).build();
        }
    }
}

} // namespace app
