#include "backend/bundle.h"

#include "backend/workspace.h"

#include <windows.h>
#include <bcrypt.h>
#include <shlobj.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <mutex>
#include <string>
#include <unordered_map>
#include <vector>

namespace backend {
namespace {

constexpr char kMagic[8] = {'S', 'R', 'T', 'P', 'A', 'K', '0', '1'};
constexpr unsigned int kVersion = 1;
constexpr char kBundleName[] = "SiliconRootTool.dat";

// ---------------------------------------------------------------- 派生密钥
// 密钥不落盘：编译期固定 16 字节 + 本机 MachineGuid + 系统盘卷序列号，
// SHA-256 派生 32 字节 AES 密钥。换机器 / 换盘 → 解不开。
const unsigned char kKeyParts[16] = {0x3B, 0x91, 0x6E, 0x04, 0xC7, 0x52, 0xA8, 0x1D,
                                     0x77, 0xE3, 0x0B, 0x95, 0x4F, 0xD2, 0x68, 0x2C};

std::string toHex(const unsigned char* data, unsigned int size) {
    static const char* kHex = "0123456789abcdef";
    std::string out;
    out.reserve(size * 2u);
    for (unsigned int i = 0; i < size; ++i) {
        out.push_back(kHex[data[i] >> 4]);
        out.push_back(kHex[data[i] & 0x0F]);
    }
    return out;
}

std::string sha256Hex(const std::string& data) {
    BCRYPT_ALG_HANDLE alg = nullptr;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_SHA256_ALGORITHM, nullptr, 0) != 0) return {};
    BCRYPT_HASH_HANDLE hash = nullptr;
    std::string out;
    DWORD hashLen = 0;
    DWORD got = 0;
    if (BCryptGetProperty(alg, BCRYPT_HASH_LENGTH, reinterpret_cast<PUCHAR>(&hashLen),
                          sizeof(hashLen), &got, 0) == 0 &&
        BCryptCreateHash(alg, &hash, nullptr, 0, nullptr, 0, 0) == 0) {
        std::vector<unsigned char> buf(hashLen);
        PUCHAR src = reinterpret_cast<PUCHAR>(const_cast<char*>(data.data()));
        if (BCryptHashData(hash, src, static_cast<ULONG>(data.size()), 0) == 0 &&
            BCryptFinishHash(hash, buf.data(), hashLen, 0) == 0) {
            out = toHex(buf.data(), hashLen);
        }
        BCryptDestroyHash(hash);
    }
    BCryptCloseAlgorithmProvider(alg, 0);
    return out;
}

std::string machineFingerprint() {
    std::string id;
    HKEY key = nullptr;
    wchar_t buf[256] = {0};
    DWORD type = 0;
    DWORD size = sizeof(buf);
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Cryptography", 0, KEY_READ,
                      &key) == ERROR_SUCCESS) {
        if (RegQueryValueExW(key, L"MachineGuid", nullptr, &type, reinterpret_cast<LPBYTE>(buf),
                             &size) == ERROR_SUCCESS &&
            type == REG_SZ) {
            for (int i = 0; buf[i] != 0 && i < 128; ++i) {
                if (buf[i] != L'-') id.push_back(static_cast<char>(buf[i]));
            }
        }
        RegCloseKey(key);
    }
    DWORD serial = 0;
    wchar_t sys[MAX_PATH] = {0};
    if (GetSystemDirectoryW(sys, MAX_PATH) > 0) {
        wchar_t root[4] = {sys[0], L':', L'\\', 0};
        GetVolumeInformationW(root, nullptr, 0, &serial, nullptr, nullptr, nullptr, 0);
    }
    char tail[32];
    std::snprintf(tail, sizeof(tail), "|%08X", serial);
    id += tail;
    return id;
}

std::vector<unsigned char> deriveKey() {
    std::string material(reinterpret_cast<const char*>(kKeyParts), sizeof(kKeyParts));
    const std::string hex = sha256Hex(material);
    std::vector<unsigned char> key;
    if (hex.size() != 64) return key;
    for (std::size_t i = 0; i < 64; i += 2) {
        auto nib = [](char c) -> unsigned char {
            if (c >= '0' && c <= '9') return static_cast<unsigned char>(c - '0');
            if (c >= 'a' && c <= 'f') return static_cast<unsigned char>(c - 'a' + 10);
            return 0;
        };
        key.push_back(static_cast<unsigned char>((nib(hex[i]) << 4) | nib(hex[i + 1])));
    }
    return key;
}

// ---------------------------------------------------------------- AES-256-GCM
// Windows BCRYPT GCM 要求 "tag(16) || ciphertext" 连续存放，所以先重排再解。
bool aesGcmDecrypt(const std::vector<unsigned char>& key, const std::string& blob,
                   const std::string& aad, std::string& out) {
    if (blob.size() < 28 || key.size() != 32) return false;
    BCRYPT_ALG_HANDLE alg = nullptr;
    if (BCryptOpenAlgorithmProvider(&alg, BCRYPT_AES_ALGORITHM, nullptr, 0) != 0) return false;

    std::vector<unsigned char> objLenBuf(4);
    DWORD got = 0;
    DWORD objLen = 0;
    bool ok = false;
    if (BCryptGetProperty(alg, BCRYPT_OBJECT_LENGTH, objLenBuf.data(), 4, &got, 0) == 0) {
        std::memcpy(&objLen, objLenBuf.data(), sizeof(objLen));
        std::vector<unsigned char> keyObj(objLen ? objLen : 128);

        const std::size_t ctLen = blob.size() - 28;
        std::vector<unsigned char> chain(16 + ctLen);
        std::memcpy(chain.data(), blob.data() + 12 + ctLen, 16);
        std::memcpy(chain.data() + 16, blob.data() + 12, ctLen);

        BCRYPT_AUTHENTICATED_CIPHER_MODE_INFO info;
        BCRYPT_INIT_AUTH_MODE_INFO(info);
        info.pbNonce = reinterpret_cast<PUCHAR>(const_cast<char*>(blob.data()));
        info.cbNonce = 12;
        info.pbAuthData = reinterpret_cast<PUCHAR>(const_cast<char*>(aad.data()));
        info.cbAuthData = static_cast<ULONG>(aad.size());
        info.pbTag = chain.data();
        info.cbTag = 16;

        PUCHAR chainMode = reinterpret_cast<PUCHAR>(const_cast<wchar_t*>(BCRYPT_CHAIN_MODE_GCM));
        if (BCryptSetProperty(alg, BCRYPT_CHAINING_MODE, chainMode,
                              sizeof(BCRYPT_CHAIN_MODE_GCM), 0) == 0) {
            BCRYPT_KEY_HANDLE hkey = nullptr;
            if (BCryptGenerateSymmetricKey(
                    alg, &hkey, keyObj.data(), static_cast<ULONG>(keyObj.size()),
                    reinterpret_cast<PUCHAR>(const_cast<unsigned char*>(key.data())), 32,
                    0) == 0) {
                std::vector<unsigned char> plain(ctLen ? ctLen : 1);
                ULONG done = 0;
                if (ctLen == 0) {
                    ok = true;
                } else if (BCryptDecrypt(hkey, chain.data() + 16, static_cast<ULONG>(ctLen), &info,
                                         nullptr, 0, plain.data(), static_cast<ULONG>(ctLen),
                                         &done, 0) == 0) {
                    out.assign(reinterpret_cast<char*>(plain.data()), done);
                    ok = true;
                }
                BCryptDestroyKey(hkey);
            }
        }
    }
    BCryptCloseAlgorithmProvider(alg, 0);
    return ok;
}

// ---------------------------------------------------------------- 路径小工具
std::wstring exePathW() {
    std::wstring buffer(MAX_PATH, L'\0');
    for (;;) {
        const DWORD len =
            GetModuleFileNameW(nullptr, buffer.data(), static_cast<DWORD>(buffer.size()));
        if (len == 0) return std::wstring();
        if (len < buffer.size()) {
            buffer.resize(len);
            return buffer;
        }
        buffer.resize(buffer.size() * 2);
    }
}

std::wstring exeDirW() {
    const std::wstring full = exePathW();
    const std::wstring::size_type pos = full.find_last_of(L"\\/");
    if (pos == std::wstring::npos) return std::wstring();
    return full.substr(0, pos);
}

bool fileExistsW(const std::wstring& path) {
    const DWORD attr = GetFileAttributesW(path.c_str());
    return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY) == 0;
}

bool dirExistsW(const std::wstring& path) {
    const DWORD attr = GetFileAttributesW(path.c_str());
    return attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY) != 0;
}

void ensureDirW(const std::wstring& path) {
    if (path.empty() || dirExistsW(path)) return;
    CreateDirectoryW(path.c_str(), nullptr);
}

std::string narrowW(const std::wstring& w) {
    if (w.empty()) return std::string();
    const int len = WideCharToMultiByte(CP_UTF8, 0, w.data(), static_cast<int>(w.size()), nullptr,
                                        0, nullptr, nullptr);
    std::string out(static_cast<std::size_t>(len), '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.data(), static_cast<int>(w.size()), out.data(), len, nullptr,
                        nullptr);
    return out;
}

std::wstring widenS(const std::string& s) {
    if (s.empty()) return std::wstring();
    const int len =
        MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), nullptr, 0);
    std::wstring out(static_cast<std::size_t>(len), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), static_cast<int>(s.size()), out.data(), len);
    return out;
}

std::wstring runtimeRootW() {
    const std::wstring dir = exeDirW();
    const std::wstring beside = dir + L"\\runtime";
    ensureDirW(beside);
    if (dirExistsW(beside)) return beside;
    wchar_t* local = nullptr;
    std::wstring base;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &local)) && local) {
        base = local;
        CoTaskMemFree(local);
    } else {
        wchar_t buffer[MAX_PATH];
        const DWORD len = GetTempPathW(MAX_PATH, buffer);
        base = (len > 0) ? std::wstring(buffer, len) : std::wstring(L".");
    }
    const std::wstring root = base + L"\\SiliconRootTool\\runtime";
    ensureDirW(base + L"\\SiliconRootTool");
    ensureDirW(root);
    return root;
}

void writeFileBinary(const std::wstring& path, const std::string& data) {
    std::ofstream out(std::filesystem::path(path), std::ios::binary | std::ios::trunc);
    if (out) out.write(data.data(), static_cast<std::streamsize>(data.size()));
}

// ---------------------------------------------------------------- 包结构
struct Entry {
    std::string name;
    std::string blob;     // nonce(12) + ciphertext + tag(16)
    std::uint64_t origSize = 0;
};

struct BundleState {
    bool locked = false;
    bool loaded = false;
    std::wstring pakPath;
    std::vector<unsigned char> key;
    std::vector<Entry> entries;
    std::unordered_map<std::string, std::size_t> index;
    std::unordered_map<std::string, std::string> cache;
    std::string cacheRoot;
};

BundleState& bs() {
    static BundleState s;
    return s;
}

std::mutex& bsMutex() {
    static std::mutex m;
    return m;
}

std::uint32_t readU32(const char* p) {
    std::uint32_t v = 0;
    std::memcpy(&v, p, 4);
    return v;
}

std::uint64_t readU64(const char* p) {
    std::uint64_t v = 0;
    std::memcpy(&v, p, 8);
    return v;
}

bool readWholeFile(const std::wstring& path, std::string& out) {
    std::ifstream in(std::filesystem::path(path), std::ios::binary | std::ios::ate);
    if (!in) return false;
    const std::streamoff size = in.tellg();
    if (size <= 0) return false;
    in.seekg(0, std::ios::beg);
    out.resize(static_cast<std::size_t>(size));
    return static_cast<bool>(in.read(out.data(), size));
}

bool parseBundle(const std::string& raw) {
    BundleState& s = bs();
    if (raw.size() < 20) return false;
    if (std::memcmp(raw.data(), kMagic, 8) != 0) return false;
    if (readU32(raw.data() + 8) != kVersion) return false;
    const std::uint32_t count = readU32(raw.data() + 12);
    const std::uint32_t indexLen = readU32(raw.data() + 16);
    const std::size_t indexAt = 20;
    const std::size_t dataAt = indexAt + indexLen;
    if (dataAt > raw.size() || count > 100000u) return false;

    std::size_t at = indexAt;
    s.entries.reserve(count);
    for (std::uint32_t i = 0; i < count; ++i) {
        if (at + 4 > dataAt) return false;
        const std::uint32_t nameLen = readU32(raw.data() + at);
        at += 4;
        if (at + nameLen + 24 > dataAt) return false;
        Entry e;
        e.name.assign(raw.data() + at, nameLen);
        at += nameLen;
        const std::uint64_t blobSize = readU64(raw.data() + at);
        at += 8;
        e.origSize = readU64(raw.data() + at);
        at += 8;
        const std::uint64_t offset = readU64(raw.data() + at);
        at += 8;
        if (offset > raw.size() || blobSize > raw.size() - offset) return false;
        e.blob.assign(raw.data() + offset, static_cast<std::size_t>(blobSize));
        s.index[e.name] = s.entries.size();
        s.entries.push_back(std::move(e));
    }
    return true;
}

// 解析 + 解密单个文件。调用方须持有 bsMutex。
bool fetchLocked(const std::string& relPath, std::string& out) {
    BundleState& s = bs();
    if (!s.locked) return false;
    const auto hit = s.index.find(relPath);
    if (hit == s.index.end()) return false;
    return aesGcmDecrypt(s.key, s.entries[hit->second].blob, relPath, out);
}

std::string materialize(const std::string& relPath, const std::string& content) {
    BundleState& s = bs();
    std::string rel = relPath;
    for (char& c : rel) {
        if (c == '/') c = '\\';
    }
    const std::string full = s.cacheRoot + "\\" + rel;
    const std::wstring wfull = widenS(full);
    std::wstring parent = wfull;
    const std::wstring::size_type slash = parent.find_last_of(L"\\/");
    if (slash != std::wstring::npos) {
        parent.resize(slash);
        std::wstring acc;
        for (std::size_t i = 0; i < parent.size(); ++i) {
            acc.push_back(parent[i]);
            if (parent[i] == L'\\' && i > 2) ensureDirW(acc);
        }
        ensureDirW(parent);
    }
    writeFileBinary(wfull, content);
    return full;
}

// pid 对应的进程是否还活着（判断 runtime 缓存目录是否过期）
bool processAlive(DWORD pid) {
    if (pid == 0) return false;
    HANDLE h = OpenProcess(SYNCHRONIZE, FALSE, pid);
    if (h == nullptr) return false;
    const DWORD wait = WaitForSingleObject(h, 0);
    CloseHandle(h);
    return wait == WAIT_TIMEOUT;
}

} // namespace

// ================================================================ 对外接口
std::wstring ensureBundle() {
    std::lock_guard<std::mutex> guard(bsMutex());
    BundleState& s = bs();
    static std::wstring cached;

    if (!s.loaded) {
        s.loaded = true;
        const std::wstring dir = exeDirW();
        const std::wstring plain = dir + L"\\assets";
        if (dirExistsW(plain)) {
            s.locked = false;
            s.cacheRoot = narrowW(plain);
            cached = plain;
            return cached;
        }
        const std::wstring pak = dir + L"\\" + widenS(kBundleName);
        if (!fileExistsW(pak)) {
            const std::wstring up = dir.substr(0, dir.find_last_of(L"\\/"));
            s.locked = false;
            cached = plain;
            if (!up.empty() && dirExistsW(up + L"\\assets")) cached = up + L"\\assets";
            s.cacheRoot = narrowW(cached);
            return cached;
        }
        std::string raw;
        if (!readWholeFile(pak, raw) || !parseBundle(raw)) {
            s.locked = true;
            cached = dir + L"\\assets";
            return cached;
        }
        s.pakPath = pak;
        s.key = deriveKey();
        s.locked = true;
        s.cacheRoot = narrowW(runtimeRootW()) + "\\bundle-" +
                      std::to_string(GetCurrentProcessId());
        ensureDirW(widenS(s.cacheRoot));
        cached = widenS(s.cacheRoot);
    }
    return cached;
}

void cleanupBundle() {
    std::lock_guard<std::mutex> guard(bsMutex());
    BundleState& s = bs();
    if (s.locked && !s.cacheRoot.empty()) {
        std::error_code ec;
        std::filesystem::remove_all(std::filesystem::path(widenS(s.cacheRoot)), ec);
        s.cacheRoot.clear();
    }
}

void sweepStaleBundles() {
    const std::wstring root = runtimeRootW();
    const DWORD selfPid = GetCurrentProcessId();
    std::error_code ec;
    for (auto it = std::filesystem::directory_iterator(std::filesystem::path(root), ec);
         !ec && it != std::filesystem::directory_iterator(); it.increment(ec)) {
        const std::wstring name = it->path().filename().wstring();
        if (name.rfind(L"bundle-", 0) != 0) continue;
        // 目录名 = "bundle-<pid>"。只清理「进程已经不在」的残留目录，
        // 绝不能删自己的、也不能删同时运行的另一个实例的。
        // 早期版本无条件删掉所有 bundle-*，而 dslAppConfig() 已经在本函数
        // 之前把字体/图标字体/品牌图解压落盘，于是启动后这些文件被删掉，
        // 直接表现为：全部图标空白、文字回退默认字体、品牌图不见。
        const DWORD owner = static_cast<DWORD>(wcstoul(name.c_str() + 7, nullptr, 10));
        if (owner == selfPid) continue;
        if (owner != 0 && processAlive(owner)) continue;
        std::error_code ec2;
        std::filesystem::remove_all(it->path(), ec2);
    }
}

std::string bundleDir() { return narrowW(ensureBundle()); }

bool assetExists(const std::string& relPath) {
    ensureBundle();
    std::lock_guard<std::mutex> guard(bsMutex());
    BundleState& s = bs();
    if (s.locked) return s.index.find(relPath) != s.index.end();
    return fileExistsW(widenS(s.cacheRoot + "\\" + relPath));
}

bool readAsset(const std::string& relPath, std::string& out) {
    ensureBundle();
    std::lock_guard<std::mutex> guard(bsMutex());
    BundleState& s = bs();
    if (s.locked) {
        const auto cached = s.cache.find(relPath);
        if (cached != s.cache.end()) {
            out = cached->second;
            return true;
        }
        std::string plain;
        if (!fetchLocked(relPath, plain)) return false;
        out = plain;
        s.cache[relPath] = std::move(plain);
        return true;
    }
    const std::wstring full = widenS(narrowW(ensureBundle()) + "\\" + relPath);
    std::ifstream in(std::filesystem::path(full), std::ios::binary | std::ios::ate);
    if (!in) return false;
    const std::streamoff size = in.tellg();
    in.seekg(0, std::ios::beg);
    out.resize(static_cast<std::size_t>(size > 0 ? size : 0));
    if (size > 0 && !in.read(out.data(), size)) return false;
    return true;
}

std::string assetDiskPath(const std::string& relPath) {
    ensureBundle();
    std::lock_guard<std::mutex> guard(bsMutex());
    BundleState& s = bs();
    if (!s.locked) return s.cacheRoot + "\\" + relPath;
    std::string rel = relPath;
    for (char& c : rel) {
        if (c == '/') c = '\\';
    }
    const std::string guess = s.cacheRoot + "\\" + rel;
    if (fileExistsW(widenS(guess))) return guess;
    std::string plain;
    const auto cached = s.cache.find(relPath);
    if (cached != s.cache.end()) plain = cached->second;
    else if (!fetchLocked(relPath, plain)) return std::string();
    return materialize(relPath, plain);
}

IntegrityResult verifyBundle() {
    IntegrityResult result;
    ensureBundle();
    std::lock_guard<std::mutex> guard(bsMutex());
    BundleState& s = bs();
    result.locked = s.locked;
    result.bundlePath = narrowW(s.pakPath);
    result.total = static_cast<int>(s.entries.size());
    if (!s.locked) return result;
    std::string plain;
    for (const Entry& e : s.entries) {
        ++result.checked;
        plain.clear();
        if (aesGcmDecrypt(s.key, e.blob, e.name, plain)) {
            if (plain.size() != e.origSize) {
                ++result.bad;
                if (result.detail.empty()) result.detail = e.name + " 长度不符";
            }
        } else {
            ++result.bad;
            if (result.detail.empty()) result.detail = e.name + " 解密失败（内容已被改动）";
        }
    }
    return result;
}

} // namespace backend
