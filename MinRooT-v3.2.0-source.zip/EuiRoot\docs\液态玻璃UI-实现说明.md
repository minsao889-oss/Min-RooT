# 液态玻璃开关（LiquidToggle）集成说明

> 目标工程：`E:\下载\SiliconRootTool-EUI\交付\SiliconRootTool`（C++17 / EUI-NEO / GLFW + OpenGL）
> 源码工程：`E:\下载\SiliconRootTool-EUI\交付\源码工程\EuiRoot`
> 完成时间：2026-10-23

---

## 一、结论先说（3 条）

1. **开关已经换掉了**：原来是「灰色模糊团 + 淡轮廓」（见 `集成截图/06-旧版原开关外观(对比).png`），现在是 **开=绿色胶囊 + 白色圆点（在右）、关=浅灰胶囊 + 白色圆点（在左）**，并且带 **欠阻尼弹簧、按下 1.5× 放大、速度拉伸、拖拽、点击切换**（见 `01`、`02`、`05` 号截图）。
2. **全 UI 也做了玻璃化**：卡片/弹层从纯白改成「半透明白 + 白色高光边 + 加大圆角」，深浅色主题都生效（见 `03`、`04` 号截图）。
3. **有一个必须说明的技术限制**：EUI-NEO 自带的 `renderGlass()` 分层玻璃（Backdrop/Surface/Highlight/InnerShadow 四层）在**本工程的这批小矩形上不出像素**（命令、uniform、着色器分支全部正确，但屏幕上没有变化）。所以开关和卡片的「玻璃观感」是用 **半透明填充 + 白色高光边 + 投影** 实现的；真正的高斯模糊/SDF 折射需要先修框架的玻璃管线（第五节给了定位）。

---

## 二、改了哪几个文件

| # | 文件 | 行号 | 改了什么 |
|---|------|------|----------|
| 1 | `交付\源码工程\EuiRoot\src\ui_toggle.h` | 新增文件（约 330 行，header-only） | 新开关组件：`namespace app::liquid`，5 条弹簧 + `toggle()` 绘制/交互 |
| 2 | `交付\源码工程\EuiRoot\src\pages_home.cpp` | 161-164 | 首页原来的 `toggleSwitch(...)` 实现换成调用 `liquid::toggle(...)`（调用点 499 未动） |
| 3 | `交付\源码工程\EuiRoot\src\pages_mirror.cpp` | 80-99 | `toggleRow(...)` 尾部换成 `liquid::toggle(..., panelHit=true)`；调用点 200/202/205/207 未动 |
| 4 | `交付\源码工程\EuiRoot\src\ui_theme.cpp` | 46-52、60-66 | 新增 `LIQUID_GLASS_TOKENS`：卡片/弹层半透明、白色高光边（深浅色各一套） |
| 5 | `交付\SiliconRootTool\SiliconRootTool.exe` | — | 用新源码重建后覆盖（旧版备份为 `SiliconRootTool.exe.old`），当前 2,352,640 B |
| 6 | `交付\SiliconRootTool\LiquidToggle.qml`、`LiquidToggle_qt5.qml`、`shaders\toggle_{sat,blur,lens}.frag(.qsb)` | — | Qt/QML 版四件套里的开关（供你以后做 Qt 版/移植参考），C++ 运行时**不会**加载它们 |

未改动：`src\app.h`、`CMakeLists.txt`、`third_party\EUI-NEO\**`（框架代码一行没动）、其它页面、`assets\**`。
备份：`E:\下载\SiliconRootTool-EUI\_integ_notes\_backup_before_spring\`（`pages_home.cpp.orig`、`pages_mirror.cpp.orig`、`ui_toggle_v1_original_material.h`、`ui_theme.cpp` 原始内容可由 git/备份还原）。

---

## 三、开关是怎么做的（`src\ui_toggle.h`）

### 3.1 几何（照搬 AndroidLiquidGlass 的 LiquidToggle）

| 项 | 值 |
|---|---|
| 轨道 | 64 × 28 dp，圆角 14 |
| 旋钮 | 40 × 24 dp，圆角 12 |
| 内边距 / 行程 | 2 dp / 20 dp |
| 按下放大 | 1.5×（绕中心，`.scale(sx, sy)` + `.transformOrigin(0.5, 0.5)`） |
| 速度拉伸 | `v = speed / 50`，`sx *= 1 - clamp(v*0.75, ±0.2)`，`sy *= 1 - clamp(v*0.25, ±0.2)` |

### 3.2 物理（半隐式欧拉 + 720Hz 子步，没有 `Behavior`/线性 lerp）

| 弹簧 | k（ω²） | ζ（阻尼比） | drag = 2ζ√k |
|---|---|---|---|
| value（位移） | 1000 | 1.0 | 63.25 |
| press（按下） | 300 | 0.5 | 17.32 |
| scaleX | 250 | 0.6 | 18.97 |
| scaleY | 250 | 0.7 | 22.14 |
| speed（速度项） | 300 | 0.5 | 17.32 |

积分参数：`dt = clamp(dt, 0, 0.064)`、`substeps = clamp(round(dt*720), 1, 64)`、`h = dt/substeps`；
每子步 `accel = -ω²·(value-target) - drag·velocity`，`velocity += accel·h`，`value += velocity·h`；
收敛判定 `|value-target| <= 0.001 && |velocity| <= 0.001*62.5` → 吸附并停帧。

松手状态机（`release()` 等价）：先等位移收敛到 `|value-target| < 0.025`，再把 press/scale 弹簧目标归零——所以「先落位、再回弹」。

### 3.3 配色

| 主题 | 开（accent） | 关（neutral） | 旋钮 |
|---|---|---|---|
| 浅色 | `#34C759` @0.88 | 灰 `#C7C7C9` | 白 @0.97，按下淡到 @0.79 |
| 深色 | `#30D158` @0.86 | 灰 `#787880` @0.36 | 白 @0.97 / @0.79 |

轨道颜色按 `value` 在 accent/neutral 之间插值，所以切换过程不会跳色。

### 3.4 为什么最终用「普通填充」而不是 `glass()`

实测过程（可复现）：把轨道/旋钮改成 `glass(glassTrack(...))` / `glass(glassKnob())` 后——

- 打开探针日志（`#define LIQUID_TOGGLE_PROBE 1`，现为 0）确认 compose 侧参数正确：
  `STYLE mr.audio.sw r=14.00 blur=8.00 lens=10.00/16.00 ab=1.00 surf=0.204,0.780,0.349,0.880 dark=0`
- 在 `opengl_primitives.cpp` 的 `drawRoundedRect` 里打命令日志，确认 4 个图层的 draw call 都发出、uniform 都正确：
  `layer=1 rect=728.0,309.0 64.0x28.0 fillA=0.880 surfA=0.880 surfRGBA=0.20,0.78,0.35 blur=0.00 bdReady=1 verts=6`
- 但屏幕上**没有任何像素变化**：最简玻璃（blur/lens/chroma 全 0 + 不透明洋红 surface）→ 不可见；把 surface 改走普通填充 → 立刻可见。
- 决定性对照：`.glass(eui::GlassStyle{})`（玻璃关闭、只留 `.color()`）→ 绿色胶囊 + 白旋钮出现（1515 个绿色像素）。

结论：`renderGlass()` 这条路径在本工程的这批小矩形上不产生输出，普通填充路径完全正常。开关是「小尺寸、要精确控制颜色」的控件，用普通填充是当前框架下唯一能保证观感的做法。

---

## 四、怎么重新构建 / 部署

```bat
:: 1) 关掉正在跑的程序（否则链接会报 LNK1104）
taskkill /IM SiliconRootTool.exe /F

:: 2) 改了 ui_toggle.h 这种头文件，必须删掉这两个 obj 强制重编
 del C:\srtbuild\CMakeFiles\SiliconRootTool.dir\src\pages_home.cpp.obj
 del C:\srtbuild\CMakeFiles\SiliconRootTool.dir\src\pages_mirror.cpp.obj

:: 3) 构建（真构建目录是 C:\srtbuild，不是源码树里的 build_out）
cd /d "E:\下载\SiliconRootTool-EUI\交付\源码工程\EuiRoot"
_cmake_build.bat

:: 4) 部署
copy /Y C:\srtbuild\SiliconRootTool.exe "E:\下载\SiliconRootTool-EUI\交付\SiliconRootTool\SiliconRootTool.exe"
```

`config.ini` 里两个调试用键：`[ui] theme=light|dark`、`[state] last_page=0..4`（0=主页、1=授权、2=管理器、3=安卓投屏、4=关于作者）。

---

## 五、还差的最后一步：让「真玻璃」渲染出来（框架级）

如果想让开关/卡片出现真正的高斯模糊 + SDF 边缘折射 + RGB 色散，需要修 EUI-NEO 的玻璃管线。已定位到的位置：

| 文件 | 行号 | 作用 |
|---|---|---|
| `third_party\EUI-NEO\core\render\primitive.cpp` | 144-208 | `Impl::renderGlass()`：外阴影 → `prepareBackdropBlur` → Backdrop/Surface/Highlight/InnerShadow 四层 |
| `third_party\EUI-NEO\core\render\primitive.cpp` | 52-99 | `drawLayer()`：把层参数写进 `command`（`glassLayer`/`glass`/`glassBackdropReady`） |
| `third_party\EUI-NEO\core\render\opengl\opengl_primitives.cpp` | 347-430 | 片元着色器：`uGlassLayer==2` 时用 `uGlassSurfaceColor`，`composedRgb = mix(glassRgb, layerFill.rgb, layerFill.a*0.85)` |
| `third_party\EUI-NEO\core\render\opengl\opengl_primitives.cpp` | 1090-1151 | 上传 `uGlassLayer`/`uGlassParams0..4`/`uGlassSurfaceColor` |
| `third_party\EUI-NEO\core\render\render_types.h` | 136-180 | `struct GlassStyle`；`RoundedRectGlassLayer{None=0,Backdrop=1,Surface=2,Highlight=3,InnerShadow=4}` |

最可疑的是 `prepareBackdropBlur`（背景模糊源）——四层里 Backdrop 层的结果是「模糊团」，说明模糊源本身拿到的就是空白/未准备。下一步应在 `prepareBackdropBlur` 里检查 `glassBackdropReady` 为 0 的分支（命令日志里 layer=2/3/4 的 `bdReady=0`），确认 FBO/纹理绑定与 `windowSize` 是否对得上。

---

## 六、截图清单（`交付\集成截图\`）

| 文件 | 内容 |
|---|---|
| `01-新版-开关静止态-浅色(绿胶囊+白圆点).png` | 改完后的开态外观（放大 4×） |
| `02-新版-按压-过冲-落位三态.png` | 按住 → 1.5× 放大；松手 → 过冲；落位 → 开/关 |
| `03-主页-浅色-液态玻璃化.png` | 整页：卡片半透明 + 白高光边 + 三个绿色开关 |
| `04-主页-深色-液态玻璃化.png` | 深色主题同一页 |
| `05-安卓投屏页-四个开关.png` | 四个开关（开/关混排） |
| `06-旧版原开关外观(对比).png` | 改之前的灰玻璃团（对比用） |

复现截图：`powershell -NoProfile -ExecutionPolicy Bypass -File "E:\下载\SiliconRootTool-EUI\_integ_notes\shoot_page.ps1" -Out out.png -NavX 129 -NavY 430`
（该框架不响应 `PostMessage` 合成鼠标消息，脚本用 `SetCursorPos` + `mouse_event` 真输入。）

---

## 七、用户还需要手动做什么

1. **没有必须做的事**——`交付\SiliconRootTool\SiliconRootTool.exe` 已经是最新构建，直接双击就能看到新开关和玻璃化 UI。
2. 如果想回退：把 `SiliconRootTool.exe.old` 改回 `SiliconRootTool.exe` 即回到旧外观。
3. 如果要自己再改源码：记住第四节「先删两个 .obj」这个坑，否则改了 `ui_toggle.h` 不会生效。
4. 如果要在其它尺寸/DPI 下微调：改 `ui_toggle.h` 顶部的 `kTrackW/kTrackH/kKnobW/kKnobH/kPad/kTravel/kPressScale` 常量即可，绘制与命中区都会跟着变。

---

## 8. 第二轮：全 UI 液态玻璃化（2026-10-23）

### 8.1 这一轮干了什么

| 用户要求 | 实现方式 | 涉及文件 |
| --- | --- | --- |
| 左侧导航栏 5 项变玻璃按钮，选中/未选中可区分 | 导航项改成胶囊：选中=主色渐变胶囊+白高光边+软投影，未选中=半透明白玻璃胶囊 | `third_party/EUI-NEO/components/navbar.h`（`navItem` / `footerButton`） |
| 所有独立按钮（顶部/授权页/关于作者页/管理器页/投屏页共 30+ 个） | **一处改全项目生效**：`ui_button_style()` 统一换成胶囊玻璃样式，`ui_button()` 加 `style.radius = h*0.5` | `src/ui_widgets.cpp` |
| 「运行方式」三选项换成带弹簧滑动的 LiquidTabBar | 新增 `liquid::tabbar()`：玻璃轨道 + 胶囊高亮块，高亮块位置由 `Spring(300, 0.62)` 半隐式欧拉积分驱动；按压时高亮块纵向压扁 6% | `src/ui_toggle.h`（新增 `TabBarState` / `tabbar`）、`src/pages_tool.cpp` |
| 清理灰色无字圆球 | 圆球真身是 `.glass()` 分层玻璃在本框架下只产出灰糊团（命令/uniform 都对，屏幕无像素）。删掉 `ui_button` 上的 `.glass(glassButton(...))` 后全部消失 | `src/ui_widgets.cpp` |

### 8.2 关键实现细节

- **按钮（LiquidButton 语义）**：胶囊半径 `h/2`；主按钮＝主色面 + 白色 1px 高光边 + 16px 柔投影（`shadow={true,{0,5},16,0,黑 0.16/0.32}`）；次按钮＝白玻璃面（浅色 `{1,1,1,0.92}` / 深色 `{1,1,1,0.10}`）+ 白高光边 + 12px 柔投影；按压 `pressScale = 0.972`（框架内建的按压缩放，不是线性补间）。
- **TabBar 弹簧**：`slide` 弹簧 k=300、ζ=0.62（过冲可见的回弹），`press` 弹簧 k=300、ζ=0.5；`drag = 2ζ√k`，`substeps = clamp(round(dt*720),1,64)`，收敛阈值 `|Δ|≤0.001 && |v|≤0.0625`——与开关的 5 条弹簧同一套 `Spring::advance()`，**没有 Behavior、没有线性 Lerp**。
- **渲染顺序**：本工程的玻璃不是 ShaderEffect 后处理，而是引擎自带的 blit 式玻璃（`opengl_primitives.cpp`），受限于「分层玻璃对小矩形不出图」（实测见第 9 章），这一轮统一采用「半透明面 + 白高光边 + 柔投影 + 胶囊」的等义表达，保证屏幕上真的看得见。

### 8.3 验证（截图在 `交付\集成截图\09~13*.png`）

- 主页：`09-主页-玻璃按钮与开关.png`（刷新设备/设备检测/快捷重启 6 个按钮全胶囊，开关绿胶囊白圆点）
- 授权页：`10-授权页-运行方式TabBar弹簧高亮.png`（运行方式变为一体式玻璃轨道 + 蓝色胶囊高亮，三段文字居中）
- 管理器页：`11-管理器页-按钮全部玻璃胶囊.png`（打开下载页/安装包目录/卸载/打开管理器/检查更新/检测状态/安装内核）
- 关于作者页：`12-关于作者页-按钮玻璃胶囊.png`（打开作者主页/复制QQ群号/打开赞赏码目录/重新读取配置）
- 投屏页：`13-投屏页-按钮与开关.png`（启动投屏/停止投屏/录屏目录/scrcpy目录 + 4 个开关）
- 全项目**再无灰色无字圆球**。

### 8.4 构建产物

`C:\srtbuild\SiliconRootTool.exe` → 2,357,248 B（2026-10-23 01:20），已覆盖 `交付\SiliconRootTool\SiliconRootTool.exe`；旧版保留 `SiliconRootTool.exe.old`。


---

## 9. 第三轮：按钮弹簧按压 + 卡片磨砂（2026-10-23 上午）

### 9.1 按钮按压缩放（真弹簧，非缓动）

| 项目 | 取值 | 出处 |
|---|---|---|
| 弹簧刚度 k | 300 | AndroidLiquidGlass `InteractiveHighlight.kt` 的 `pressProgressAnimationSpec = spring(0.5f, 300f, 0.001f)` |
| 阻尼比 ζ | 0.5 | 同上（欠阻尼，会轻微过冲） |
| 缩放峰值 | 1.05 | 用户要求；实际绘制 = 1.0 + 0.05 × 弹簧值 |
| 积分方式 | 半隐式欧拉 + 720Hz 子步（`Spring::advance`） | 与开关/滑块共用同一套代码 |
| 收敛条件 | `|Δ| ≤ 0.001 && |vel| ≤ 0.0625` | 收敛后不再挂 `onFrame`，框架可休眠 |
| 缩放中心 | 视觉中心（用 `.translate()` 反向补偿，因为框架 `.scale()` 原点在左上角） | 实测：按住时左边缘 -6px、右边缘 +6px |

- 改动文件：`src/ui_toggle.h` 新增 `kButtonPressGrow`、`ButtonPressState`、`buttonPressSettled()`；`src/ui_widgets.cpp` 的 `ui_button()` 重写（`components::button(...).scale(pressScale).translate(...)` + 一层透明 `onPress/onRelease` 命中区驱动弹簧 + `hit.onClick()` 派发点击）。
- 框架自带的 `pressScale`（0.972，走 160ms 缓动）已被关掉（`style.pressScale = 1.0f`），保证动画只有弹簧一条路径。
- 实测（`_integ_notes/press_rest.png` vs `press_hold.png`，逐像素量边缘）：静止 251px 宽 → 按住 263px（1.048×），松手后 253px → 251px（过冲回归），数字与 ζ=0.5 的欠阻尼特征一致。
- 全项目覆盖：所有页面调用 `ui_button()` 的按钮（主页 2、授权页 4、管理器页 7、投屏页 4、关于作者页 4）自动获得该效果，无需逐页改。

### 9.2 卡片磨砂（半透明白玻璃）

- 改 `src/ui_theme.cpp` 的主题令牌（`LIQUID_GLASS_TOKENS`）：
  - 浅色：`surface` 0.88 → **0.36**、`surfaceHover` 0.94 → 0.50、`surfaceActive` 1.0 → 0.62
  - 深色：`surface` 0.78 → **0.62**、`surfaceHover` 0.88 → 0.72、`surfaceActive` 0.94 → 0.80
- 效果：卡片后面的动态视频能透出来（用户要求的 `rgba(255,255,255,0.2)` 磨砂感），白色高光边保留（浅色 `border` 白 0.92 / 深色 0.13）。
- 为什么不是真·模糊：EUI-NEO 的 `renderGlass()` 分层玻璃在本项目这批矩形上不产生任何像素（第二轮已用 A/B + GL 命令日志证实），所以改用「半透明填充 + 白边 + 柔光投影」表达玻璃；背景视频本身是 560×300 的帧，显示时被拉伸，天然带一点柔化。

### 9.3 构建与验证

- 构建：`cd 交付\源码工程\EuiRoot && cmd /c _cmake_build.bat` → `[100%] Built target SiliconRootTool`，EXIT=0
- 产物：`C:\srtbuild\SiliconRootTool.exe` → 覆盖 `交付\SiliconRootTool\SiliconRootTool.exe`
- 截图：`交付\集成截图\14..20*.png`（按压缩放对照、主页/授权页/关于作者页/投屏页）
- 依赖：**零新增依赖**（纯 C++，不需要 Qt/Python 运行时）


---

## 10. 第四轮：运行方式 TabBar 支持按压缩放 + 拖动

### 10.1 改了什么

| 项目 | 之前 | 现在 |
|---|---|---|
| 按压反馈 | 只有高亮块纵向压扁 6% | 高亮块绕自身中心**放大到 1.05**（与全部按钮同一套弹簧 k=300 / ζ=0.5） |
| 能否拖动 | 不能，只能点某一段 | **按住可左右拖动**，高亮块跟着手指走，松手吸附到最近段并触发 `onSelect` |
| 按下瞬间 | 高亮块不动（还停在上一次选中处） | 高亮块**立刻用弹簧跑到手指所在段**，拖动/点击都从这一步开始 |
| 命中层 | 每段一个透明 rect（3 个） | 整条一个透明 rect，内部按 `(event.x - bounds.x) / (bounds.width / w)` 换算段索引 |

- 文件：`src/ui_toggle.h` 的 `struct TabBarState`（新增 `dragging/dragSeeded/dragTotal0/pressBase/pixelScale/pressIndex`）与 `liquid::tabbar()`。
- 拖动量：`dp = (DragEvent.totalX - dragTotal0) / pixelScale`，首帧只对齐基线（避开按下瞬间指针跳变），超过 3dp 才判定为拖动。
- 拖动时 `slide.target = clamp(pressBase + dp / segW, 0, n-1)`，松手 `lround` 吸附。
- 文字颜色跟随 `lround(slide.value)` 动态变化，所以拖动过程中标签会跟着手指变白。

### 10.2 实测（真实鼠标事件，逐像素量）

| 状态 | 高亮块 bbox | 说明 |
|---|---|---|
| 静止（选中③） | x=986..1320，335×46 | 基准 |
| 按住①（不松手 450ms） | x=464..814，**351×48** | 跑到① + 放大 **1.048×** |
| 按住并向右拖 740px | x=976..1327，352×48 | 跟着手指回到③ |
| 松手后 | x=986..1320，335×46 | 吸附③、尺寸回弹 |
| 单击②（不拖） | x=641..974，334×46 | 点击路径正常 |

证据：`_integ_notes/tab_rest.png`、`tab_hold.png`、`tab_drag.png`、`tab_settled.png`、`tab_final.png`、`tab_states_montage.png`；验收脚本 `_integ_notes/tabbar_test.ps1`（参数 `-TabX -TabY -DragPx`，`-DragPx 0` 即纯点击测试）。


---

## 11. 第六轮：点哪弹哪 + 卡片磨砂 + 背景高斯模糊

### 11.1 你提的三个问题

| # | 你的反馈 | 真因 | 修法 |
|---|---------|------|------|
| 1 | 「有时候点击的时候还是选择不过去」 | 命中判定用了 `lround()`：**每段的右半边会四舍五入到下一段**，看起来像"点了没反应/选错" | 改成 `floor()`（段 i 的区间是 `[i*segW, (i+1)*segW)`），并 clamp 到 0..n-1 |
| 2 | 「真正一个区域，点击直接弹过去」 | 之前要等松手才提交选择 | `onPress` 里直接 `onSelect(pressIndex)`（按下即选中），松手只在"拖动落点与按下段不同"时再提交一次 |
| 3 | 「别的卡片没有高斯模糊」「背景也高斯模糊」 | EUI-NEO 的分层玻璃（`renderGlass`）在小矩形上不出像素（第 9 章已验证），不能靠它做逐卡片模糊 | **背景帧离线高斯模糊**：120 帧全部 `GaussianBlur(2.6)` 重新生成，卡片保持半透明白 + 白高光边 → 透出来的就是磨砂玻璃 |

### 11.2 具体改动

**A. `源码工程/EuiRoot/src/ui_toggle.h`（`liquid::tabbar`）**

```cpp
// 段索引：段 i 覆盖 [i*segW, (i+1)*segW)，必须 floor，不能 round
const float localDp = static_cast<float>(event.x - bounds.x) / fx.pixelScale;
int hitIndex = static_cast<int>(std::floor((localDp - pad) / segW));
if (hitIndex < 0) hitIndex = 0;
if (hitIndex > n - 1) hitIndex = n - 1;
fx.pressIndex = hitIndex;
...
if (onSelect) onSelect(fx.pressIndex);        // 按下即选中（点击立刻弹过去）
```

松手时：`const bool changed = (idx != fx.pressIndex); ... if (onSelect && changed) onSelect(idx);` —— 拖动落点变了才补一次提交，避免重复写配置。

**B. 背景帧（`交付/SiliconRootTool/assets/app-bg-frames/`）**

| 项 | 值 |
|---|---|
| 帧数 / 帧率 / 尺寸 | 120 帧 / 15 fps / 560×300 |
| 模糊 | PIL `ImageFilter.GaussianBlur(radius=2.6)`（560 宽下 ≈ 屏幕 6–7px 观感） |
| 原始清晰帧备份 | `assets/app-bg-frames-sharp/`（想还原直接拷回来） |
| 体积 | 8.9 MB → 3.5 MB |
| 播放逻辑 | 未改（`src/main.cpp` 的 `WallpaperPlayback.onFrame`，15fps 与 90fps 渲染解耦） |

**C. 卡片磨砂**

浅色主题卡片面 `rgba(255,255,255,0.36)`、深色 `rgba(255,255,255,0.62)`，1px 白色高光边（浅色 0.92 / 深色 0.13）。因为背景已经整体模糊，卡片里透出的天然就是模糊画面 —— 等于"每张卡片都自带高斯模糊"，且**零额外 GPU 开销**。

### 11.3 验收数据（真实鼠标：SetCursorPos + mouse_event）

点击三段，读取 `config.ini` 的 `[state] run_mode`：

| 点击位置 | 指示块像素范围 | 写入的 run_mode | 结论 |
|---|---|---|---|
| 段① | x=295..629 | `Cold` | ✅ |
| 段② | x=641..974 | `Refire` | ✅ |
| 段③ | x=986..1320 | `Interactive` | ✅ |
| 段①按住 → 拖到段③ → 松手 | 落在 x=986..1320 | `Interactive` | ✅ 拖动仍正常 |

（修复前：点段② 会写成 `Interactive`，即四舍五入跑到段③ —— 正是"选择不过去"的真身。）

### 11.4 构建 / 部署

```powershell
Get-Process SiliconRootTool -ErrorAction SilentlyContinue | Stop-Process -Force
$obj = "C:\srtbuild\CMakeFiles\SiliconRootTool.dir\src"
foreach ($f in "pages_home.cpp.obj","pages_mirror.cpp.obj","pages_tool.cpp.obj","ui_widgets.cpp.obj","main.cpp.obj") {
    Remove-Item (Join-Path $obj $f) -Force -ErrorAction SilentlyContinue
}
cd "E:\下载\SiliconRootTool-EUI\交付\源码工程\EuiRoot"
cmd /c _cmake_build.bat                     # [100%] Built target SiliconRootTool
Copy-Item C:\srtbuild\SiliconRootTool.exe "E:\下载\SiliconRootTool-EUI\交付\SiliconRootTool\SiliconRootTool.exe" -Force
```

产物：`交付/SiliconRootTool/SiliconRootTool.exe` ，**2,366,976 B @2026-10-23 12:26:58**。

### 11.5 截图（`交付/集成截图/`）

| 文件 | 内容 |
|---|---|
| `25-主页-背景高斯模糊.png` | 主页：背景糊 + 卡片磨砂 + 胶囊按钮 |
| `26-授权页-背景模糊+卡片磨砂.png` | 授权页：运行方式 TabBar |
| `27-投屏页.png` | 投屏页：4 开关 + 胶囊按钮 + 磨砂卡片 |
| `28-管理器页.png` / `29-关于作者页.png` | 其余两页 |
| `30-运行方式-点哪弹哪-三段各点一次.png` | 依次点 ①②③ 的指示块位置（点哪弹哪） |

## 12. 第七轮：按钮玻璃 / 按压缩放 / 底栏弹簧（2026-10-23 13:30）

### 12.1 这轮改了什么

| 位置 | 文件 | 改动 |
| --- | --- | --- |
| 顶部/各页按钮 | `src/ui_widgets.cpp` | `ui_button_glass(press,drag)`：折射强度随按压/拖动变强（lens 14→26/36dp），表面按压缩透明，45° 高光按拖动变亮；`ui_button()` 记录按压/拖动/拉伸三条弹簧 |
| 按钮弹簧 | `src/ui_toggle.h` | `ButtonPressState` 扩成 4 条弹簧：`scale`(300,0.5)、`tx/ty`(300,0.62)、`stretch`(300,0.6)；`buttonPressSettled()` 四者都收敛才停帧 |
| 按钮拖动 | `src/ui_widgets.cpp` | 跟手位移 `min(w,h)*tanh(0.05*dp/min(w,h))`（LiquidButton 原式），拖动距离给额外放大，松手全部弹簧归零回弹 |
| 运行方式底栏 | `src/ui_toggle.h` | 轨道 = 半透明白玻璃 + 白高光边；胶囊 = 主题蓝 + 白边 + 投影（随按压加深）；`grow = 1 + 0.14*press`、标签同步放大 10% |
| 底栏命中 | `src/ui_toggle.h` | 整条一个命中区：按下立刻 `onSelect(pressIndex)`（点哪跳哪）；拖动超过 3dp 才进拖动模式，松手吸附落点 |
| 开关 | `src/ui_toggle.h` | 恢复绿胶囊 + 白圆点实色面（之前给它加的 glass 会让面消失，见 12.2），保留 5 条弹簧与 1.5× 按压缩放 |
| 内容区 | `src/main.cpp` | 新增 `page.canvas` 磨砂画布（浅色白 0.50 / 深色 0.62），动态背景上文字终于够对比 |
| 背景 | `assets/app-bg-frames` | 120 帧全部高斯模糊（清晰原图在 `app-bg-frames-sharp`） |

### 12.2 一个必须写下来的框架事实

EUI-NEO 的 `renderGlass`（`core/render/primitive.cpp:144`）对**包在 `ui.stack(...)` 里的小控件不出像素**：
我用 A/B 验证过——把开关的 `trackGlass.surfaceColor` 设成不透明洋红 `{1,0,1,1}`、旋钮设成不透明青色，重新编译后屏幕上**依然什么都没有**；
同一次构建里把 `.glass(...)` 去掉、只留 `.color(...)`，绿胶囊和白圆点立刻正常。
所以：**卡片 / 导航 / 按钮**（不在 stack 里、尺寸大）走真 `.glass()`；**开关 / 底栏指示块**（在 stack 里）改用「半透明填充 + 白色高光边 + 投影」的组合来表达玻璃质感。
这条结论对后续维护很重要：以后再给控件加 `.glass()`，先确认它不在 stack 容器内。

### 12.3 实测数据（真鼠标 SetCursorPos + mouse_event，逐像素量 bbox）

| 对象 | 状态 | 实测 |
| --- | --- | --- |
| 运行方式胶囊 | 静止（选中①） | x=295..629，**335×46** |
| 运行方式胶囊 | 按住② 500ms | x=615..995，**381×52**（1.14 倍，跟着手指跳到②） |
| 运行方式胶囊 | 松手 1.6s 后 | x=641..974，**334×46**（吸附②、回弹） |
| 运行方式胶囊 | 从①拖到③ | x=959..1340，**382×52**（跟手） |
| 运行方式胶囊 | 拖动松手后 | x=986..1320，**335×46**（吸到③） |
| 执行授权按钮 | 静止 | y=468..515，高 **48** |
| 执行授权按钮 | 按住 550ms | y=466..517，高 **52**（1.083 倍，左右各扩 10px 居中） |
| 执行授权按钮 | 松手瞬间 | **49**（弹簧过冲后回落） |
| 执行授权按钮 | 松手 1.5s | **48**（完全回稳） |

证据截图：`_integ_notes/Q_tool.png`、`Q_mirror.png`、`Q_home.png`、`T_rest/hold/rel/drag/after.png`、`B_rest/hold/over/after.png`；
已复制到 `交付/集成截图/31..36*.png`。

### 12.4 构建与部署

```bat
cd /d "E:\下载\SiliconRootTool-EUI\交付\源码工程\EuiRoot"
cmd /c _cmake_build.bat
copy /y C:\srtbuild\SiliconRootTool.exe "E:\下载\SiliconRootTool-EUI\交付\SiliconRootTool\SiliconRootTool.exe"
```

产物：`交付\SiliconRootTool\SiliconRootTool.exe`，2,371,072 B，2026-10-23 13:25。

---

## 13. 第二轮返工：背景改为「程序化设计」+ 卡片/按钮补上高光与边框

### 13.1 背景：不再使用任何图片/视频素材

用户要求（2026-10-23 14:00）：*「还有那个背景不用图片了，还是用默认的 或者你按这个项目的 UI 样子自己设计。」*

- 删除 `交付\SiliconRootTool\assets\app-bg-frames\`（120 张 JPEG 帧）、`assets\app-bg-frames-sharp\`（清晰原图备份）、`assets\video-bg.mp4`（69 MB）。
- `src\main.cpp` 里的帧序列壁纸代码整段移除，换成**纯代码绘制**的背景（零素材、零纹理显存）：

| 元素 | id | 做法 |
|---|---|---|
| 底色 | `root.bg.base` | 全屏竖向渐变：浅色 `#F4F7FD → #DD E5F3`、深色 `#0A0C10 → #131721` |
| 柔光斑 A | `root.bg.glowA` | 12 层同心半透明圆，蓝 `#5B8CFF`，左上角 |
| 柔光斑 B | `root.bg.glowB` | 12 层同心圆，紫 `#9B7BFF`，右下角 |
| 柔光斑 C | `root.bg.glowC` | 10 层同心圆，薄荷 `#4CD8BA`，底部中间 |

新增辅助函数 `static void glowBlob(eui::Ui&, const std::string& id, float cx, float cy, float radius, const eui::Color&, int rings)`：
逐层画半径递减的圆、单层 alpha 很低，叠加后形成无锯齿的柔和光晕（框架没有 blur，用叠加近似）。

同时删掉第 12 章加的 `page.canvas` 磨砂画布（背景变干净后不再需要，避免内容区出现接缝）。

### 13.2 卡片：手绘玻璃（`liquid::glassCard()`）

`src\ui_toggle.h` 里新增/重写：

```cpp
inline void glassCard(eui::Ui& ui, const std::string& id, float x, float y, float w, float h,
                      float radius, const eui::Color& tint);
```

分 4 层绘制（**不再调用框架 `.glass()`**：实测它会吞掉 `.border()`，且各图层在小尺寸元素上不出像素）：

1. **主体** `id` —— 竖向渐变 + 2px 白边 + 22px 柔投影
   - 浅色：顶 `白 α≈0.78`、底 `白 α≈0.54`，边 `纯白 1.0`
   - 深色：顶 `{0.086,0.102,0.137} α0.82`、底 `{0.051,0.063,0.090} α0.90`，边 `白 0.18`
2. **内层倒角环** `id + ".bevel"` —— 内缩 3.5px、1px 边框（浅色白 0.60 / 深色白 0.10）＝ 玻璃边缘受光的第二道高光
3. **顶部反光** `id + ".sheen"` —— 上 42% 高度（最多 110px）的白色渐隐（浅色 0.34 → 0，深色 0.05 → 0）
4. 深色主题单独一套参数，避免"深色界面上一片亮白 + 弱对比文字看不清"

调用点（3 个页面的 `card()` 全部改成它）：
- `src\pages_home.cpp:50`
- `src\pages_tool.cpp:12`
- `src\pages_managers.cpp:12`

### 13.3 按钮：让边框真正画出来

- `src\ui_widgets.cpp` 的 `ui_button()` 里**删掉 `.glass(ui_button_glass(...))` 调用**。
  原因：框架渲染玻璃层时边框被跳过 → 用户看到的"灰色模糊、没边框没高光"。
- 改由 `ButtonStyle.border` 画边：次色按钮 `1.6px 纯白`、主色按钮 `1.6px 白 α0.62`；主色填充改半透明 `α0.90`，玻璃底透出来一点。
- 按压缩放仍是自研弹簧（`src\ui_widgets.cpp:212-236`、`221`：`pressScale = 1 + (4dp / h) * press`），不依赖框架的 160ms 缓动。

### 13.4 构建与部署

```bat
cd "E:\下载\SiliconRootTool-EUI\交付\源码工程\EuiRoot"
_cmake_build.bat
```
产物覆盖 `交付\SiliconRootTool\SiliconRootTool.exe`（本次 **2,364,416 B @2026-10-23 14:12**）。

### 13.5 验收截图

| 文件 | 内容 |
|---|---|
| `集成截图\37-浅色-主页-程序化背景.png` | 新的渐变+光斑背景 |
| `集成截图\38-浅色-授权页-卡片白边高光.png` | 卡片白边 / 内层倒角 / 顶部反光 |
| `集成截图\39-浅色-管理器页.png` | 管理器卡片 |
| `集成截图\40-浅色-投屏页.png` | 投屏页 |
| `集成截图\41-浅色-关于作者页.png` | 关于作者页 |
| `集成截图\42-深色-主页.png` | 深色主题（卡片改深色玻璃） |
| `集成截图\43-深色-授权页.png` | 深色下的边框/高光 |

> 说明：真正的"折射"（把背后画面按 SDF 法线扭曲）仍受框架限制——`EUI-NEO` 的玻璃分层渲染对这些尺寸的元素不出像素（第 12 章 A/B 实验有记录）。当前用「渐变磨砂面 + 双道白边高光 + 顶部反光 + 投影」在观感上逼近，性能开销为零。

---

## 第 15 章 · 无边框窗口收口：圆角 / 拖动 / 拉伸 / 兼容 / 打包

### 15.1 需求对照

| 需求 | 实现 | 位置 |
| --- | --- | --- |
| 窗口要圆角 | `DwmSetWindowAttribute(hwnd, 33 /*WINDOW_CORNER_PREFERENCE*/, DWMWCP_ROUND(2))`，同时把系统描边设成 `DWMWA_COLOR_NONE`（属性 34） | `src/main.cpp` 的 `setupWindowChrome()` |
| 拖动要跟手不掉帧 | `WM_NCHITTEST` 在标题带返回 `HTCAPTION`，交给 DWM/系统拖动循环，不再每帧 `SetWindowPos` | `chromeWindowProc()` |
| 窗口可以拉伸 | 给窗口补 `WS_THICKFRAME`，并在 `WM_NCHITTEST` 里自己判边缘（`HTLEFT/HTRIGHT/HTTOP/HTBOTTOM` + 四角） | `chromeWindowProc()` + `setupWindowChrome()` |
| 三个自绘按钮 | 最小化 `SW_MINIMIZE`、最大化/还原 `IsZoomed ? SW_RESTORE : SW_MAXIMIZE`、关闭 `WM_CLOSE` | `composeTitleBar()` |
| Win7 / 10 / 11 都能用 | 窗口尺寸按桌面裁剪、DPI 用 `GetDeviceCaps` 兜底、启动失败弹提示框 | `dslAppConfig()`、`setupWindowChrome()`、`glfw_app_main.cpp` 的 `main()` |

### 15.2 为什么这样拖不卡

旧实现是在 `onDrag` 里每收到一个鼠标移动就 `SetWindowPos` 一次：窗口移动会重新进入窗口过程、触发重排，拖动过程中容易掉帧。

新实现把标题带的命中测试直接返回 `HTCAPTION`，Windows 用系统拖动循环移动窗口（DWM 合成层整体搬运），应用侧不需要参与；顺带白送贴边分屏（Snap）和双击最大化。实测拖拽请求 `(+160, +90)`，窗口实际位移 `(160, 90)`，完全 1:1。

拉伸同理：返回 `HTLEFT` 等命中码后，缩放也由系统循环接管，鼠标指针自动变成双向箭头，不需要自己画光标。

### 15.3 圆角实测

启动日志会打印一行：

```
[INFO] 圆角: DwmSetWindowAttribute corner=0x0 border=0x0 hwnd=...
```

`0x0` = `S_OK`。在 1804×972 窗口上取四角像素：左上角外侧 8×8 平均 `(74,78,87)`、内侧 40×40 平均 `(26,30,42)`，差值约 48 → 角落确实被切掉（桌面透出），即圆角生效。

- Windows 11：显示系统圆角（约 8px）。
- Windows 10 / 7：系统没有这个 API，调用返回失败但**完全不报错、不影响功能**，窗口为直角。
- 圆角是系统级裁剪，应用内不需要写任何遮罩，性能开销为 0。

### 15.4 兼容性处理（Win7 / 10 / 11）

1. **窗口别超出屏幕**：读配置后按 `GetSystemMetrics(SM_CXSCREEN/SM_CYSCREEN)` 裁剪——宽不超过桌面 94%、高不超过 90%（下限 960×640）。1366×768 的笔记本上不会再出现窗口跑到屏幕外、按钮点不到的情况。
2. **最小尺寸跟着屏幕走**：`.minWindowSize(min(1180, w), min(780, h))`，避免最小尺寸大于可用桌面导致无法缩小。
3. **DPI 兜底**：`GetDpiForWindow` 在 Win7 上不存在（动态 `GetProcAddress` 返回空），此时用 `GetDeviceCaps(GetDC(nullptr), LOGPIXELSX)` 兜底，125%/150% 缩放下标题带与四个角的判定仍然准确。
4. **启动失败给提示**：窗口创建失败（多数是显卡驱动不支持 OpenGL 3.3，或跑在远程桌面/虚拟机里）时弹出中文对话框，告诉用户"更新显卡驱动 / 确认不是远程桌面 / 重新解压"，不再"双击没反应"。
5. **按需渲染**：静止时框架不重绘（实测 idle 仅 2~4 FPS、CPU 0%、GPU 0~2%、Render 0.3 ms）；只有动画、悬停、点击时才满帧。老机器上也不会一直烧显卡。

> 硬性前提：显卡驱动支持 **OpenGL 3.3**（框架用 3.3 Core）。2010 年之后的独显/核显驱动基本都满足；极老机器或精简版系统若缺 OpenGL 会命中第 4 条的提示框。

### 15.5 实测数据（最新构建）

| 项目 | 结果 |
| --- | --- |
| 标题拖动 | 请求 (+160,+90) → 实际 (160,90) |
| 右边缘拉伸 | 宽 +180 px（1360 → 1540） |
| 下边缘拉伸 | 高 +120 px（900 → 1020） |
| 右下角拉伸 | −120 / −90 px |
| 左边缘拉伸 | 窗口左移 200 px、宽度同步 −200 px |
| 最大化 / 还原 | `IsZoomed=1`，1920×1032 → 还原回 1360×900 |
| 最小化 / 关闭 | `IsIconic=1`；关闭进程 code 0 |
| 圆角 | `DwmSetWindowAttribute` 返回 `S_OK`，四角像素差 ≈48 |

### 15.6 打包产物

| 路径 | 说明 |
| --- | --- |
| `D:\下载\新建文件夹\SiliconRootTool-v3.4.0\` | 解压即用的绿色版目录 |
| `D:\下载\新建文件夹\SiliconRootTool-v3.4.0.zip` | 压缩包（同内容） |

包内结构：

```
SiliconRootTool-v3.4.0/
  SiliconRootTool.exe      主程序（无边框 + 圆角 + 可拖可拉伸）
  assets/                  字体 / 图标 / 管理器包 / 投屏组件
  config.ini               主题与状态（theme=dark|light）
  author.ini               作者信息
  使用说明.txt             原版功能说明
  README-运行说明.txt      本版运行说明与目录解释
  docs/液态玻璃开关-集成说明.md
  预览/01..04-*.png        界面截图（浅色/深色）
```

清理掉的无用文件：`LiquidToggle.qml`、`LiquidToggle_qt5.qml`、`shaders/`（QML 阶段的遗留物，C++ 版用不到）、两份旧 exe 备份（`A_old.exe`、`SiliconRootTool.exe.old`）、运行日志。

### 15.7 复现构建

```bat
cd /d "E:\下载\SiliconRootTool-EUI\交付\源码工程\EuiRoot"
_cmake_build.bat
```

产物在 `C:\srtbuild\SiliconRootTool.exe`，复制到 `交付\SiliconRootTool\` 即可。**改了 `ui_toggle.h` 这类头文件后要先删** `C:\srtbuild\CMakeFiles\SiliconRootTool.dir\src\*.obj`，否则 ninja 的头文件依赖可能不触发重编。

---

## 第 16 章 · 自由拉伸窗口（解决拉伸变黑）

### 16.1 问题

上一版加完 `WS_THICKFRAME` 后能拉了，但拖边缘的瞬间，**新露出来的那条区域是黑的**——用户截图里就是右侧/底部一条黑带。

### 16.2 原因

无边框窗口（GLFW `decorated=false`）创建时没有设置窗口类的背景画刷（`GCLP_HBRBACKGROUND` 为空）。拖动缩放时 Windows 会把"新变成可见"的那一条立刻擦一遍，没有画刷就擦成**纯黑**；而 OpenGL 的下一帧要几毫秒之后才到，中间这段时间屏幕上就是黑的。

QML/Qt 那类程序之所以没这问题，是因为 Qt 窗口自己带 backing store，Windows 擦出来的那块会立刻被 Qt 重绘。GL 直绘窗口没有这个机制。

### 16.3 参考项目怎么做的

参考 <https://github.com/1zmiao/QRoundedFrame>（`app/cpp/frameless_native/src/native_window_agent.cpp`），它用三件事解决同一问题：

```cpp
// 1) 给窗口类装一个和界面同色的背景画刷
HBRUSH nextBrush = CreateSolidBrush(RGB(color.red(), color.green(), color.blue()));
SetClassLongPtrW(hwnd, GCLP_HBRBACKGROUND, reinterpret_cast<LONG_PTR>(nextBrush));

// 2) 拦截 WM_ERASEBKGND，用这个颜色填
case WM_ERASEBKGND: {
    HBRUSH brush = CreateSolidBrush(RGB(...));
    FillRect(reinterpret_cast<HDC>(msg->wParam), &rect, brush);
    ...
    return true;
}

// 3) WM_NCCALCSIZE 里让系统重绘新客户区
case WM_NCCALCSIZE:
    *result = WVR_REDRAW;
    return true;
```

（它的 `fillWindowBackground()` 还会在 `WM_ENTERSIZEMOVE / WM_SIZING / WM_WINDOWPOSCHANGING / WM_SIZE / WM_EXITSIZEMOVE` 里主动填一遍。）

### 16.4 我们的做法（照同一思路，改动只在窗口层）

1. `setupWindowChrome()`：按 `config.ini` 的 `[ui] theme` 生成画刷，装进窗口类：
   ```cpp
   gChrome.bgColor = (themeName == "light") ? RGB(245, 247, 252) : RGB(14, 16, 20);
   gChrome.bgBrush = CreateSolidBrush(gChrome.bgColor);
   SetClassLongPtrW(hwnd, GCLP_HBRBACKGROUND,
                    reinterpret_cast<LONG_PTR>(gChrome.bgBrush));
   ```
   这样 Windows 擦新露出来的那条时，用的是**和界面同色的底**，不是黑色。
2. **不**在 `WM_SIZE` 里整块填色。这一点和参考项目不同：它是 Qt 方案，整块填完 QML 会立刻重绘；我们是 GL 直绘，整块填会把当前帧擦掉（实测整窗变成一块纯色）。所以只依赖窗口类画刷擦"新露出的边"，其余区域留给 GL。

### 16.5 实测

拖动右边缘分 5 步（+80 → +400 px），**在鼠标仍按住时**抓屏统计纯黑像素：

| 步进 | 窗口尺寸 | 纯黑像素 |
| --- | --- | --- |
| +80px | 1426×886 | 0 / 79254（0.00%） |
| +160px | 1506×886 | 0 / 83694（0.00%） |
| +240px | 1586×886 | 0 / 88134（0.00%） |
| +320px | 1666×886 | 0 / 92574（0.00%） |
| +400px | 1746×886 | 0 / 97014（0.00%） |

拉伸过程中界面是**完整内容**（卡片、文字、日志全在），不是纯色块，也不是黑带；松手后布局按新尺寸重排。

### 16.6 四条边的拉伸 + 系统行为

- 四边四角都能拖，鼠标移到边缘自动变双向箭头（`WM_NCHITTEST` 返回 `HTLEFT/HTTOP...`）。
- 缩放由系统循环接管 → 不占 CPU、和拖动一样跟手。
- 最大化 / 还原 / 最小化 / 关闭沿用第 15 章的实现。
- 圆角（Win11）在拉伸过程中保持，不会变直角。

### 16.7 本次只动了窗口层

对照「不要改任何 UI 和功能」：本章改动全部在 `src/main.cpp` 的 `NativeChrome` / `chromeWindowProc` / `setupWindowChrome` 里，页面布局、控件、业务逻辑、动画参数一律没动。

---

## 第 17 章 · 更大的窗口圆角

### 17.1 为什么不能直接调 DWM

Windows 11 的 `DwmSetWindowAttribute(hwnd, DWMWA_WINDOW_CORNER_PREFERENCE, …)` 只有三个可选值：
`DWMWCP_DONOTROUND(1)` / `DWMWCP_ROUND(2)` / `DWMWCP_ROUNDSMALL(3)`，半径是系统定死的约 8px，**没有"自定义半径"这个参数**。

### 17.2 参考项目的做法

`QRoundedFrame` 的窗口圆角并不是靠 DWM，而是自己裁剪窗口区域（`native_window_agent.cpp`）：

```cpp
HRGN region = CreateRoundRectRgn(0, 0, width + 1, height + 1, radius * 2, radius * 2);
SetWindowRgn(hwnd, region, redraw);      // 窗口真正被裁成圆角
```

半径按 DPI 换算（`nativeCornerRadiusPx`），并且在 `WM_SIZING` 里用"目标尺寸"提前更新区域，避免等下一帧 Resize 才修圆角；最大化/全屏时改成矩形区域（`CreateRectRgn`），不然最大化后四个角会缺一块。

### 17.3 我们的实现

`src/main.cpp`：

```cpp
constexpr float kWindowCornerDp = 22.0f;   // 原来系统圆角约 8px，现在 22dp

void applyChromeRegion(HWND hwnd) {
    const bool square = IsZoomed(hwnd) || IsIconic(hwnd);
    int radius = square ? 0 : lround(kWindowCornerDp * dpi / 96.0);
    HRGN region = square ? CreateRectRgn(0, 0, w + 1, h + 1)
                         : CreateRoundRectRgn(0, 0, w + 1, h + 1, radius * 2, radius * 2);
    SetWindowRgn(hwnd, region, TRUE);
}
```

配合三处调用：

1. `setupWindowChrome()` 里装完窗口子类化后先应用一次；
2. `WM_SIZE / WM_SIZING / WM_EXITSIZEMOVE` 里跟着新尺寸重算；
3. `DwmSetWindowAttribute(33, DWMWCP_DONOTROUND)` —— **必须把系统圆角关掉**，否则系统 8px 圆角会叠在我们的 22px 圆角上，拐角处会出现一个小缺口。

### 17.4 实测

- 圆角像素：左侧 8×8 平均 `(239.9, 240.2, 241.5)`（桌面），内侧 40×40 平均 `(45.2, 50.0, 62.9)`（窗口内容），差值 **≈195**——角落被完整裁掉。
- 最大化：`IsZoomed=1` 时切成矩形区域，四角像素 `(21,26,40)` ≈ 内侧 `(18,22,34)`，**没有缺角**。
- 拉伸：`WM_SIZING` 里同步更新区域，实测 +80…+400px 五步，纯黑像素 0/68000+（0.00%）。

### 17.5 说明

`SetWindowRgn` 是**二进制区域**裁剪，没有抗锯齿，圆角弧线上会有轻微锯齿（参考项目也是同样代价——它的圆角同样是 region 裁的）。要完全平滑只能改成分层窗口（`WS_EX_LAYERED` + 逐像素 alpha）或自己画阴影窗口，代价和风险都大得多，本次不做。

半径想再调大/调小，只改 `kWindowCornerDp`（默认 22）即可。

---

## 第 18 章 · 收尾修的三处小毛病

### 18.1 首页「快捷工具」三个开关贴到卡片边、右边被切

`src/pages_home.cpp` 里开关的 x 是写死的旧值：

```cpp
toggleSwitch(ui, rows[i].id, bx + innerW - 42.0f, ry + 5.0f, rows[i].on, rows[i].onClick);
```

开关本体宽 `liquid::kTrackW`（64dp），却只往里让了 42dp，所以右边多出 22dp、正好压在卡片右边框上（放大看在边框处是被"切平"的样子）。现在改成按实际宽度让位，并留 8dp 呼吸：

```cpp
toggleSwitch(ui, rows[i].id, bx + innerW - liquid::kTrackW - 8.0f, ry + 5.0f, ...);
```

标签宽度同步改成 `innerW - liquid::kTrackW - 12.0f`，长文案不会压到开关。

### 18.2 每次启动窗口都会瘦 14px

原来退出时保存的是 `s.lastW/lastH`（客户端逻辑像素），但窗口创建时 `DslAppConfig::windowSize(w, h)` 是当**外层尺寸**用的。为了支持自由拉伸，我们又给窗口补了 `WS_THICKFRAME`——它带来 7px × 2 的边框，于是"保存客户端尺寸 → 下次当外层尺寸创建"就每次缩 14px，连开五次窗口会一路缩到最小尺寸。

修法（`src/main.cpp` 的 `onShutdown`）：保存前把边框补回去。

```cpp
HWND chrome = gAppChromeWindow != nullptr ? gAppChromeWindow : GetActiveWindow();
RECT wr{};
GetWindowRect(chrome, &wr);
frameW = (wr.right - wr.left) - s.lastW;   // = 14
backend::writeIni(ini, "window", "width", std::to_string((int)(s.lastW + frameW + 0.5f)));
```

实测连开三次：`rect=(0,0,1360,900)`、配置文件始终 `width=1360 height=900`，不再缩。

### 18.3 卡片高斯模糊的最后取舍（回顾）

第 14 章已经定型：框架的 `blur()` 通道会把 `fill.a` 强制成 1.0（`opengl_primitives.cpp:437-442`），卡片会变成不透明灰块，而且会把投影混进填充里。所以卡片的"磨砂"最终是 **竖向渐变 + 2px 白边 + 内层倒角环 + 顶部反光 + 双层柔和投影** 画出来的，`blur` 保持 0——观感接近毛玻璃，并且 0 额外开销。

## 19. 头像 / 作者名 / 边缘观感（2026-10-23 晚）

### 19.1 头像与作者名
- 作者卡的头像和名字**不需要改代码**，都从程序目录的 `author.ini` 读：
  - `[author] name=` → 作者卡大字（本次改为 `minsao`）
  - `[author] avatar=` → 头像图路径（默认 `assets/about/avatar.png`）
- 本次已把新头像放到 `assets/about/avatar.png`（512×512 PNG，圆角 24dp 由代码裁）；
  并把 `author.ini` 的 `name=` 改为 `minsao`。改完重启程序即生效，无需重新编译。

### 19.2 右边缘那条"蓝色竖条"是什么
- 那是页面滚动条（`components/scroll.h`）的滑块，按下/悬停时用主题主色显示，
  并且贴着窗口右边框画，所以看起来像多出来一条蓝色边。
- 本次改法：轨道透明、滑块改为中性灰（亮色 α0.18 / 暗色 α0.22，按下 0.36），
  并从右边缘内缩 4px（`components/scrollview.h`），不再贴着窗口边框。

### 19.3 窗口圆角外侧"漏出文字"
- 圆角窗口（`CreateRoundRectRgn` 22dp）在四角是**真正挖空**的，那里显示的是桌面
  本身的内容（例如桌面图标的文字）。这不是界面画错，是圆角窗口的必然结果。
- 附带加固：拖拽/缩放结束后强制一次整窗重绘（`WM_EXITSIZEMOVE` →
  `RedrawWindow(RDW_INVALIDATE|RDW_ERASE|RDW_FRAME|RDW_UPDATENOW)`），
  避免个别显卡/合成器下旧帧残留在窗口周围。

### 19.4 本次构建
- `_cmake_build.bat` → `[100%] Built target SiliconRootTool`，exe 2,379,264 B。
- 部署到 `交付\SiliconRootTool\` 与发布包目录，zip 已重新打包。


---

## 20 圆角修复：从硬边裁剪改成抗锯齿圆角

### 20.1 你看到的问题是什么
不是背景是方形，而是**圆角是用 SetWindowRgn 二值裁剪出来的**：区域只有在/不在两种状态，没有抗锯齿，
所以 22dp 的圆角在屏幕上是一圈**像素阶梯**，远看就像直角的硬边。

### 20.2 这次怎么修的
| 系统 | 方案 | 效果 |
|---|---|---|
| Windows 11（build ≥ 22000） | 关掉自己裁区域，改用 DWM 原生圆角 DWMWCP_ROUND | **抗锯齿、平滑**（系统半径 ≈8dp，随缩放放大） |
| Windows 10 及更早 | 保留 CreateRoundRectRgn + SetWindowRgn | 有圆角但边缘是硬边（老系统没有 DWM 圆角 API） |

实现（src/main.cpp）：
- 新增 ool isWindows11()（
tdll!RtlGetVersion，不受清单影响的真实 build 号）；
- NativeChrome 增加 ool dwmRound；
- setupWindowChrome() 里 const int round = win11 ? 2 : 1;（DWMWCP_ROUND / DWMWCP_DONOTROUND）；
- pplyChromeRegion() 开头 if (gChrome.dwmRound) return; —— Win11 上不再调用 SetWindowRgn。

### 20.3 验证
- 日志：円角: DwmSetWindowAttribute corner=0x0 border=0x0 hwnd=… win11=1（corner=0x0 = S_OK）。
- 像素：窗口左上角 5× 放大后，角部是**桌面→应用背景的渐变过渡**（(255,117,79)→(255,209,196)→(137,150,175)），
  无阶梯；改之前同一处是硬切。
- 冒烟：包目录启动 → 窗口出现、
esponding=True、关闭 exit 0。

### 20.4 一个取舍
Windows 11 的 DWM 圆角半径是系统固定的（DWMWCP_ROUND / ROUNDSMALL / DONOTROUND 三档），
**不能自定义大小**。想要 22dp 那种大圆角，就只能回到 SetWindowRgn 的硬边（会看到锯齿）。
当前默认 = 抗锯齿的平滑圆角。若更想要大半径，把 pplyChromeRegion 里的 if (gChrome.dwmRound) 改成
if (false) 并让 
ound = 1 即可复原大圆角版本。
