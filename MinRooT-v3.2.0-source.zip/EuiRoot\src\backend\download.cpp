#include "backend/download.h"

#include <windows.h>
#include <winhttp.h>
#include <wininet.h>
#include <urlmon.h>
#include <ws2tcpip.h>

#include <algorithm>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#pragma comment(lib, "winhttp.lib")
#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "urlmon.lib")
#pragma comment(lib, "wininet.lib")

namespace backend {
namespace {

std::wstring widenA(const std::string& in) {
    if (in.empty()) return std::wstring();
    const int need = MultiByteToWideChar(CP_UTF8, 0, in.c_str(), -1, nullptr, 0);
    if (need <= 0) return std::wstring();
    std::wstring out(static_cast<size_t>(need), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, in.c_str(), -1, out.data(), need);
    out.resize(static_cast<size_t>(need) - 1);
    return out;
}

std::string narrowW(const std::wstring& in) {
    if (in.empty()) return std::string();
    const int need = WideCharToMultiByte(CP_UTF8, 0, in.c_str(), -1, nullptr, 0, nullptr, nullptr);
    if (need <= 0) return std::string();
    std::string out(static_cast<size_t>(need), '\0');
    WideCharToMultiByte(CP_UTF8, 0, in.c_str(), -1, out.data(), need, nullptr, nullptr);
    out.resize(static_cast<size_t>(need) - 1);
    return out;
}

std::string hex(long value) {
    char buf[32] = {};
    sprintf_s(buf, "0x%08lX", value);
    return std::string(buf);
}

// 读 IE / WinHTTP 配置里的代理串，用于自动代理失败时的回退。
std::wstring ieProxyName() {
    WINHTTP_CURRENT_USER_IE_PROXY_CONFIG ie{};
    if (WinHttpGetIEProxyConfigForCurrentUser(&ie)) {
        std::wstring result;
        if (ie.lpszProxy) result = ie.lpszProxy;
        if (ie.lpszProxy) GlobalFree(ie.lpszProxy);
        if (ie.lpszProxyBypass) GlobalFree(ie.lpszProxyBypass);
        if (ie.lpszAutoConfigUrl) GlobalFree(ie.lpszAutoConfigUrl);
        return result;
    }
    return std::wstring();
}

struct UrlParts {
    bool ok = false;
    bool https = true;
    std::wstring host;
    std::wstring path;      // 含 query
    INTERNET_PORT port = 0;
};

UrlParts splitUrl(const std::wstring& url) {
    UrlParts parts;
    URL_COMPONENTS c{};
    c.dwStructSize = sizeof(c);
    c.dwSchemeLength = static_cast<DWORD>(-1);
    c.dwHostNameLength = static_cast<DWORD>(-1);
    c.dwUrlPathLength = static_cast<DWORD>(-1);
    c.dwExtraInfoLength = static_cast<DWORD>(-1);
    if (!WinHttpCrackUrl(url.c_str(), static_cast<DWORD>(url.size()), 0, &c)) return parts;
    parts.host.assign(c.lpszHostName, c.dwHostNameLength);
    parts.path.assign(c.lpszUrlPath, c.dwUrlPathLength);
    if (c.dwExtraInfoLength > 0) parts.path.append(c.lpszExtraInfo, c.dwExtraInfoLength);
    parts.port = c.nPort;
    parts.https = (c.nScheme == INTERNET_SCHEME_HTTPS);
    parts.ok = !parts.host.empty();
    return parts;
}

// 代理策略：有显式 IE 代理就显式用它，否则关掉自动探测直连。
// 这里不用 WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY：在没跑 WPAD、也没配代理的机器上
// 它会留下一个「配置好但不可用」的会话，后续 SendRequest 直接返回 0x57
// （ERROR_INVALID_PARAMETER），表现为所有请求都失败却和网络无关。
HINTERNET openSession(std::wstring& note) {
    const std::wstring proxy = ieProxyName();
    if (!proxy.empty()) {
        HINTERNET session = WinHttpOpen(L"SiliconRootTool/1.0", WINHTTP_ACCESS_TYPE_NAMED_PROXY,
                                        proxy.c_str(), WINHTTP_NO_PROXY_BYPASS, 0);
        if (session) {
            note = L"系统代理 " + proxy;
            return session;
        }
    }
    HINTERNET session = WinHttpOpen(L"SiliconRootTool/1.0", WINHTTP_ACCESS_TYPE_NO_PROXY,
                                    WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (session) note = L"直连";
    return session;
}

// 一次 HTTP GET。out 非空则把响应体收进内存；fileSink 非空则写文件。
bool httpGet(const std::wstring& url, const std::string& acceptHeader, std::string* out,
             HANDLE fileSink, const DownloadProgress& progress, std::string& err) {
    const UrlParts parts = splitUrl(url);
    if (!parts.ok) {
        err = "URL 解析失败";
        return false;
    }

    // 以前这里先自己 GetAddrInfoW 出 IP，再用 IP 去 WinHttpConnect，靠 Host 头补主机名。
    // 那是为了绕开 WinHTTP 内部的 12007（NAME_NOT_RESOLVED），但代价是**丢了 SNI**：
    // 直连 https://api.github.com 会握手失败，而最后一档镜像失败时又把真实原因覆盖掉，
    // 表现为「DNS 解析失败 ghproxy.net」这种误导性结论。
    // 实测标准链路（主机名交给 WinHttpConnect）四档全部正常，所以恢复成标准写法。
    const std::wstring& connectHost = parts.host;

    std::wstring note;
    HINTERNET session = openSession(note);
    if (!session) {
        err = "WinHTTP 初始化失败（" + hex(GetLastError()) + "）";
        return false;
    }
    // 超时口径（v3.1 修）：
    //   解析 8s / 连接 8s / 发送 15s / 接收 20s。
    // 早期是 20/20/40/120 —— 接收 120s 意味着一个卡住的镜像能闷 2 分钟，
    // 而 downloadToFile / fetchReleaseApkUrl 都会轮 4 个镜像，最坏十几分钟，
    // 表现为「点了安装就不动了，CPU 也不涨」（WinHttpQueryDataAvailable 纯阻塞）。
    // 下载大文件本身不靠这条兜底：循环里另有「连续 N 秒零字节」的进度看门狗。
    WinHttpSetTimeouts(session, 8000, 8000, 15000, 20000);

    HINTERNET connect = WinHttpConnect(session, connectHost.c_str(), parts.port, 0);
    if (!connect) {
        err = "无法连接 " + narrowW(parts.host) + "（" + hex(GetLastError()) + "，" +
              narrowW(note) + "）";
        WinHttpCloseHandle(session);
        return false;
    }

    HINTERNET request = WinHttpOpenRequest(connect, L"GET", parts.path.c_str(), nullptr,
                                           WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                                           parts.https ? WINHTTP_FLAG_SECURE : 0);
    if (!request) {
        err = "创建请求失败（" + hex(GetLastError()) + "）";
        WinHttpCloseHandle(connect);
        WinHttpCloseHandle(session);
        return false;
    }

    // 部分镜像站用交叉签名证书，这里放宽校验以免被拦。
    DWORD security = SECURITY_FLAG_IGNORE_UNKNOWN_CA | SECURITY_FLAG_IGNORE_CERT_CN_INVALID |
                     SECURITY_FLAG_IGNORE_CERT_DATE_INVALID;
    WinHttpSetOption(request, WINHTTP_OPTION_SECURITY_FLAGS, &security, sizeof(security));

    // 关掉自动重定向（v3.1 修）。
    // 踩过的坑：GitHub release 资产一定是 302 到 objects.githubusercontent.com。
    // 开着自动重定向时，WinHTTP 在**请求句柄内部**重新建连，WinHttpSetTimeouts 里那份
    // 接收超时对这条新连接不一定生效 —— 实测能挂到 100 秒以上还回不来，
    // 而且卡在 WinHttpQueryDataAvailable 里面，外层写的进度看门狗根本没机会跑
    // （循环体都进不去）。所以改成手动跟一层 302，跳转目标的时机完全可控。
    DWORD redirectPolicy = WINHTTP_OPTION_REDIRECT_POLICY_NEVER;
    WinHttpSetOption(request, WINHTTP_OPTION_REDIRECT_POLICY, &redirectPolicy,
                     sizeof(redirectPolicy));

    // 第二行必须带 "Accept: " 前缀。
    // 踩过的坑：acceptHeader 参数里装的是媒体类型值（application/vnd.github+json），
    // 早期直接把它拼成独立一行，结果头发成 "application/vnd.github+json\r\n" ——
    // 没有冒号的裸串会被 WinHTTP 参数校验拒掉，返回 0x57（ERROR_INVALID_PARAMETER），
    // 外面看到的就是「四个镜像全 0x57」，非常像网络故障，实际跟网络无关。
    std::wstring headers = L"User-Agent: SiliconRootTool/1.0\r\n";
    if (!acceptHeader.empty()) headers += L"Accept: " + widenA(acceptHeader) + L"\r\n";

    // 不要在这里重试。
    // 踩过的坑：以前是 3 次 SendRequest + 每次 Sleep(800)。看起来只是多了 2.4 秒，
    // 实际每次失败都要先吃满 8 秒连接超时，一轮就是 8*3+1.6 ≈ 26 秒；
    // 外层 downloadToFile / fetchReleaseApkUrl 还要轮 4 个镜像，最坏 100 秒以上，
    // 期间界面只有一个「正在下载」的转圈，看起来就是彻底死掉了。
    // 换镜像由外层负责，单次尝试只做一遍。
    std::wstring wndHeader = headers;
    SetLastError(0);
    const BOOL snd = WinHttpSendRequest(request, wndHeader.c_str(), static_cast<DWORD>(-1),
                                        WINHTTP_NO_REQUEST_DATA, 0, static_cast<DWORD>(-1), 0);
    const DWORD sendErr = GetLastError();
    if (!snd || !WinHttpReceiveResponse(request, nullptr)) {
        err = "请求 " + narrowW(parts.host) + " 失败（" + hex(sendErr) + "，" + narrowW(note) + "）";
        WinHttpCloseHandle(request);
        WinHttpCloseHandle(connect);
        WinHttpCloseHandle(session);
        return false;
    }

    DWORD status = 0;
    DWORD statusLen = sizeof(status);
    WinHttpQueryHeaders(request, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                        WINHTTP_HEADER_NAME_BY_INDEX, &status, &statusLen, WINHTTP_NO_HEADER_INDEX);

    // 302 自己跟（见上面关掉自动重定向的理由）。只跟一层：GitHub 资产是一跳到底，
    // 多层跳转的镜像本来就该判失败，免得变成循环。
    if (status >= 300 && status < 400) {
        std::wstring location;
        DWORD locLen = 0;
        WinHttpQueryHeaders(request, WINHTTP_QUERY_LOCATION, WINHTTP_HEADER_NAME_BY_INDEX, nullptr,
                            &locLen, WINHTTP_NO_HEADER_INDEX);
        if (locLen > 0) {
            location.resize(locLen / sizeof(wchar_t) + 1);
            if (WinHttpQueryHeaders(request, WINHTTP_QUERY_LOCATION, WINHTTP_HEADER_NAME_BY_INDEX,
                                    &location[0], &locLen, WINHTTP_NO_HEADER_INDEX)) {
                location.resize(wcslen(location.c_str()));
            } else {
                location.clear();
            }
        }
        WinHttpCloseHandle(request);
        WinHttpCloseHandle(connect);
        WinHttpCloseHandle(session);
        if (location.empty()) {
            err = narrowW(parts.host) + " 返回 HTTP " + std::to_string(status) + " 且无 Location";
            return false;
        }
        // 绝对地址才跟；相对地址拼回原主机
        if (location.rfind(L"http", 0) != 0) {
            std::wstring base = parts.https ? L"https://" : L"http://";
            base += parts.host;
            if (!parts.path.empty() && parts.path[0] != L'/') base += L"/";
            location = base + location;
        }
        return httpGet(location, acceptHeader, out, fileSink, progress, err);
    }

    if (status != 200) {
        err = narrowW(parts.host) + " 返回 HTTP " + std::to_string(status);
        WinHttpCloseHandle(request);
        WinHttpCloseHandle(connect);
        WinHttpCloseHandle(session);
        return false;
    }

    unsigned long long total = 0;
    {
        wchar_t lenBuf[64] = {};
        DWORD lenSize = static_cast<DWORD>(sizeof(lenBuf) - sizeof(wchar_t));
        if (WinHttpQueryHeaders(request, WINHTTP_QUERY_CONTENT_LENGTH,
                                WINHTTP_HEADER_NAME_BY_INDEX, lenBuf, &lenSize,
                                WINHTTP_NO_HEADER_INDEX)) {
            lenBuf[lenSize / sizeof(wchar_t)] = L'\0';
            total = _wcstoui64(lenBuf, nullptr, 10);
        }
    }

    unsigned long long done = 0;
    bool ok = true;
    // 进度看门狗：连续 idleLimitMs 一字节都没读到就主动断开。
    // 只靠 WinHttpSetTimeouts 的接收超时不够——只要服务端隔一阵发一个字节的心跳，
    // 那个超时就会被不断重置，连接能挂到天荒地老。
    // 这里判断的是「距上一次拿到数据过了多久」，所以要在读循环顶部先查、读到数据后再更新。
    const DWORD idleLimitMs = fileSink != nullptr ? 25000u : 12000u;
    DWORD lastProgress = GetTickCount();
    for (;;) {
        if (GetTickCount() - lastProgress > idleLimitMs) {
            err = "传输停滞（" + std::to_string(idleLimitMs / 1000) + " 秒无数据）";
            ok = false;
            break;
        }
        DWORD avail = 0;
        if (!WinHttpQueryDataAvailable(request, &avail)) break;
        if (avail == 0) break;
        std::vector<char> chunk(avail);
        DWORD read = 0;
        if (!WinHttpReadData(request, chunk.data(), avail, &read) || read == 0) break;
        if (fileSink != nullptr && fileSink != INVALID_HANDLE_VALUE) {
            DWORD written = 0;
            if (!WriteFile(fileSink, chunk.data(), read, &written, nullptr) || written != read) {
                err = "写入文件失败（" + hex(GetLastError()) + "）";
                ok = false;
                break;
            }
        } else if (out) {
            out->append(chunk.data(), read);
            if (out->size() > 8u * 1024u * 1024u) break;   // JSON 安全上限
        }
        done += read;
        lastProgress = GetTickCount();
        if (progress) progress(done, total);
    }
    if (ok && total > 0 && done < total) {
        // 服务端声明了长度却没给够：别当成功，否则后面 adb install 会拿到残包
        err = "传输中断（" + std::to_string(done) + "/" + std::to_string(total) + " 字节）";
        ok = false;
    }

    WinHttpCloseHandle(request);
    WinHttpCloseHandle(connect);
    WinHttpCloseHandle(session);
    return ok;
}

// 从 release JSON 里挑出匹配 pattern 的 browser_download_url。
// v3.1 加的两条排除：
//   · "spoofed"：KernelSU Next v3.4.2 同时挂了 KernelSU_Next_v3.4.2_33355-release.apk
//     和 KernelSU_Next_v3.4.2-spoofed_33355-release.apk 两个资产。按前缀匹配会先撞上
//     spoofed 那条，而那条在服务端是坏的（.NET 直连 21 秒后「无法连接到远程服务器」），
//     整次下载就跟着失败。spoofed 是给特定场景替换包名用的，不是常规安装包。
//   · ".sha256"/".asc"：有些仓库把校验和也放在同一批资产里。
std::string pickAssetUrl(const std::string& json, const std::string& pattern) {
    std::string needle = pattern;
    for (auto& ch : needle) ch = static_cast<char>(tolower(static_cast<unsigned char>(ch)));

    size_t pos = 0;
    while (true) {
        const size_t at = json.find("browser_download_url", pos);
        if (at == std::string::npos) break;
        const size_t colon = json.find(':', at);
        if (colon == std::string::npos) break;
        const size_t q1 = json.find('"', colon);
        if (q1 == std::string::npos) break;
        const size_t q2 = json.find('"', q1 + 1);
        if (q2 == std::string::npos) break;
        const std::string url = json.substr(q1 + 1, q2 - q1 - 1);
        pos = q2 + 1;
        if (url.size() < 5) continue;
        std::string lowered = url;
        for (auto& ch : lowered) ch = static_cast<char>(tolower(static_cast<unsigned char>(ch)));
        if (lowered.compare(lowered.size() - 4, 4, ".apk") != 0) continue;
        if (lowered.find("spoofed") != std::string::npos) continue;
        if (!needle.empty() && lowered.find(needle) == std::string::npos) continue;
        return url;
    }
    return std::string();
}

} // namespace

// WinINet 兜底通道：URLDownloadToFileW。
// 为什么需要这条：
//   GitHub release 资产会 302 到 release-assets.githubusercontent.com，而**那个域名对
//   WinHTTP 返回它解析不了的响应**（实测 WinHttpReceiveResponse 直接
//   ERROR_WINHTTP_INVALID_SERVER_RESPONSE / 12032，或吃满接收超时 12002）。
//   同一时刻 .NET 的 HttpWebRequest / Invoke-WebRequest 能在 14 秒内把 13.6 MB 完整拉下来，
//   说明网络本身是通的，卡的是 WinHTTP 这一层的协议栈。
//   WinINet 与 .NET 走同一套底层实现，实测能过，所以拿它做「WinHTTP 读不回来」时的兜底。
bool downloadViaWinInet(const std::string& urlUtf8, const std::string& destPathUtf8,
                        std::string& err) {
    const std::wstring url = widenA(urlUtf8);
    const std::wstring dest = widenA(destPathUtf8);
    DeleteFileW(dest.c_str());

    const HRESULT hr = URLDownloadToFileW(nullptr, url.c_str(), dest.c_str(), 0, nullptr);
    if (SUCCEEDED(hr)) {
        WIN32_FILE_ATTRIBUTE_DATA attrs{};
        if (GetFileAttributesExW(dest.c_str(), GetFileExInfoStandard, &attrs)) {
            const unsigned long long size =
                (static_cast<unsigned long long>(attrs.nFileSizeHigh) << 32) | attrs.nFileSizeLow;
            if (size >= 512ull * 1024ull) return true;
            DeleteFileW(dest.c_str());
            err = "WinINet 只取到 " + std::to_string(size) + " 字节，疑似错误页面";
            return false;
        }
        err = "WinINet 下载完但文件不可读";
        return false;
    }
    err = "WinINet 下载失败（HRESULT " + hex(static_cast<DWORD>(hr)) + "）";
    return false;
}

std::string mirrorUrl(const std::string& url, int mirrorIndex) {
    if (mirrorIndex <= 0 || url.empty()) return url;
    // 顺序按实测可用性排：gh-proxy 最快且支持 API，ghfast 次之，ghproxy.net 对 API 返 403。
    switch (mirrorIndex) {
        case 1:
            return "https://gh-proxy.com/" + url;
        case 2:
            return "https://ghfast.top/" + url;
        case 3:
            return "https://ghproxy.net/" + url;
        default:
            return url;
    }
}

const char* mirrorLabel(int mirrorIndex) {
    switch (mirrorIndex) {
        case 1: return "gh-proxy";
        case 2: return "ghfast";
        case 3: return "ghproxy.net";
        default: return "直连";
    }
}

std::string systemProxySummary() {
    const std::wstring proxy = ieProxyName();
    return proxy.empty() ? std::string("未配置系统代理") : ("系统代理 " + narrowW(proxy));
}

bool downloadToFile(const std::string& urlUtf8, const std::string& destPathUtf8,
                    const DownloadProgress& progress, std::string& err) {
    const std::wstring dest = widenA(destPathUtf8);
    DeleteFileW(dest.c_str());

    // 整体截止时间。单看每个通道的超时都还在可接受范围，四档叠起来就不行了：
    // 用户看到的是「点了就没反应」。这里硬性封顶，超时立刻把原因抛出去，
    // 让调用方能打日志、能让 UI 恢复，而不是让工作线程在后台默默挂着。
    const DWORD kTotalBudgetMs = 180000u;
    const DWORD started = GetTickCount();

    std::string lastError;
    // 每一档的失败原因都留住。以前只留 lastError，四档轮完只剩最后一档
    // （ghproxy.net 对资产固定失败）的原因，前面真正可用的诊断信息全被盖掉，
    // 日志里只剩一句「请求 ghproxy.net 失败」，看不出直连和 WinINet 是怎么挂的。
    std::string allReasons;
    auto noteReason = [&allReasons](const std::string& r) {
        if (r.empty()) return;
        if (!allReasons.empty()) allReasons += "；";
        allReasons += r;
    };
    for (int mirror = 0; mirror < 4; ++mirror) {
        if (GetTickCount() - started > kTotalBudgetMs) {
            lastError = "下载总时长超过 " + std::to_string(kTotalBudgetMs / 1000) + " 秒，已放弃";
            noteReason(lastError);
            break;
        }
        const std::string candidate = mirrorUrl(urlUtf8, mirror);
        if (candidate.empty()) continue;
        const DWORD stepStart = GetTickCount();

        // 直连（mirror 0）先让 WinINet 试一把：GitHub 资产 302 到的
        // release-assets.githubusercontent.com，WinHTTP 读它必挂（12032 / 12002），
        // WinINet 却能正常拿完，见 downloadViaWinInet 上面的说明。
        // 镜像站（mirror>0）不用 WinINet：镜像本身常挂，交回 WinHTTP 更好控制超时。
        if (mirror == 0) {
            std::string inetErr;
            if (downloadViaWinInet(candidate, destPathUtf8, inetErr)) return true;
            lastError = std::string(mirrorLabel(mirror)) + "：WinINet " + inetErr + "（" +
                        std::to_string(GetTickCount() - stepStart) + " ms）";
            noteReason(lastError);
        }

        HANDLE file = CreateFileW(dest.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_ALWAYS,
                                  FILE_ATTRIBUTE_NORMAL, nullptr);
        if (file == INVALID_HANDLE_VALUE) {
            err = "无法创建目标文件（" + hex(GetLastError()) + "）";
            return false;
        }
        std::string stepErr;
        const bool ok = httpGet(widenA(candidate), "application/octet-stream", nullptr, file,
                                progress, stepErr);
        CloseHandle(file);

        if (ok) {
            WIN32_FILE_ATTRIBUTE_DATA attrs{};
            if (GetFileAttributesExW(dest.c_str(), GetFileExInfoStandard, &attrs)) {
                const unsigned long long size =
                    (static_cast<unsigned long long>(attrs.nFileSizeHigh) << 32) | attrs.nFileSizeLow;
                if (size >= 512ull * 1024ull) return true;
                DeleteFileW(dest.c_str());
                lastError = "下载文件仅 " + std::to_string(size) + " 字节，疑似错误页面";
            } else {
                lastError = "下载完成但文件不可读";
            }
        } else {
            lastError = std::string(mirrorLabel(mirror)) + "：" + stepErr + "（" +
                        std::to_string(GetTickCount() - stepStart) + " ms）";
        }
        noteReason(lastError);
    }

    err = allReasons.empty() ? "所有下载通道均失败" : allReasons;
    return false;
}

bool fetchReleaseApkUrl(const std::string& apiUrl, const std::string& pattern, std::string& out,
                        std::string& err) {
    std::string lastError;
    for (int mirror = 0; mirror < 4; ++mirror) {
        const std::string candidate = mirrorUrl(apiUrl, mirror);
        if (candidate.empty()) continue;
        std::string json;
        std::string stepErr;
        if (!httpGet(widenA(candidate), "application/vnd.github+json", &json, nullptr, nullptr,
                     stepErr)) {
            lastError = stepErr;
            continue;
        }
        out = pickAssetUrl(json, pattern);
        if (!out.empty()) return true;
        lastError = "release 里没有匹配「" + pattern + "」的 APK 资产";
    }
    err = lastError;
    return false;
}

namespace {

// 从 JSON 里取第一个 "tag_name":"..." 的值
std::string pickTagName(const std::string& json) {
    const size_t at = json.find("\"tag_name\"");
    if (at == std::string::npos) return std::string();
    const size_t colon = json.find(':', at);
    if (colon == std::string::npos) return std::string();
    const size_t q1 = json.find('"', colon);
    if (q1 == std::string::npos) return std::string();
    const size_t q2 = json.find('"', q1 + 1);
    if (q2 == std::string::npos) return std::string();
    return json.substr(q1 + 1, q2 - q1 - 1);
}

} // namespace

bool fetchLatestReleaseInfo(const std::string& apiUrl, const std::string& pattern,
                            std::string& tag, std::string& apkUrl, std::string& err) {
    // 四档都记下来再拼成一句：
    // 只留 lastError 的话，最后一档（ghproxy.net，对 API 固定 403）会把
    // 前面真正可用的失败原因全盖掉，日志里只剩一句误导性的结论。
    std::vector<std::string> reasons;
    for (int mirror = 0; mirror < 4; ++mirror) {
        const std::string candidate = mirrorUrl(apiUrl, mirror);
        if (candidate.empty()) continue;
        const char* label = mirrorLabel(mirror);
        std::string json;
        std::string stepErr;
        if (!httpGet(widenA(candidate), "application/vnd.github+json", &json, nullptr, nullptr,
                     stepErr)) {
            reasons.push_back(std::string(label) + "：" + stepErr);
            continue;
        }
        tag = pickTagName(json);
        apkUrl = pickAssetUrl(json, pattern);
        if (!apkUrl.empty()) return true;
        // tag 拿到了但资产没匹配上：这条通道本身是通的，把原因说清楚再继续试镜像
        reasons.push_back(std::string(label) + "：" +
                          (tag.empty() ? std::string("release 里没有 tag_name")
                                       : ("最新版 " + tag + " 里没有匹配「" + pattern + "」的 APK 资产")));
    }
    std::string joined;
    for (const std::string& r : reasons) {
        if (!joined.empty()) joined += "；";
        joined += r;
    }
    err = joined.empty() ? "所有镜像均不可用" : joined;
    return false;
}

} // namespace backend
