#include "backend/workspace.h"

#include "../obfstr.h"
#include "backend/assets.h"
#include "backend/process.h"

#include <windows.h>
#include <shellapi.h>

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <sstream>
#include <vector>

namespace backend {
namespace {

std::string g_sessionLog;

std::wstring exePathW() {
    std::vector<wchar_t> buffer(4096, L'\0');
    const DWORD len = GetModuleFileNameW(nullptr, buffer.data(),
                                        static_cast<DWORD>(buffer.size()));
    if (len == 0) return L".";
    return std::wstring(buffer.data(), len);
}

std::string timestamp(const char* format) {
    SYSTEMTIME st{};
    GetLocalTime(&st);
    char buf[64] = {0};
    std::snprintf(buf, sizeof(buf), "%04d-%02d-%02d %02d:%02d:%02d",
                  st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
    (void)format;
    return std::string(buf);
}

std::string stampForFile() {
    SYSTEMTIME st{};
    GetLocalTime(&st);
    char buf[64] = {0};
    std::snprintf(buf, sizeof(buf), "%04d%02d%02d-%02d%02d%02d",
                  st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
    return std::string(buf);
}

bool ensureDirW(const std::wstring& path) {
    std::error_code ec;
    std::filesystem::create_directories(std::filesystem::path(path), ec);
    return !ec;
}

std::wstring joinW(const std::string& dir, const std::string& name) {
    std::wstring out = widen(dir);
    if (!out.empty() && out.back() != L'\\' && out.back() != L'/') out.push_back(L'\\');
    out += widen(name);
    return out;
}

} // namespace

std::string appDir() {
    static const std::string cached = [] {
        const std::wstring full = exePathW();
        const std::size_t slash = full.find_last_of(L"\\/");
        const std::wstring dir = (slash == std::wstring::npos) ? L"." : full.substr(0, slash);
        return narrow(dir);
    }();
    return cached;
}

bool ensureWorkspace() {
    const std::string dir = appDir();
    bool ok = true;
    ok = ensureDirW(joinW(dir, "logs")) && ok;
    ok = ensureDirW(joinW(dir, "temp")) && ok;
    ok = ensureDirW(joinW(dir, "temp\\cache")) && ok;

    if (g_sessionLog.empty()) {
        g_sessionLog = dir + "\\logs\\run-" + stampForFile() + ".log";
        std::ofstream touch(std::filesystem::path(widen(g_sessionLog)),
                            std::ios::app | std::ios::binary);
        touch << "\xEF\xBB\xBF";
    }
    return ok;
}

const std::string& sessionLogPath() {
    return g_sessionLog;
}

// 落盘格式与界面完全对齐：HH:mm:ss  [级别]  内容
// 时长格式的时间戳（日期已在文件名 run-<日期>-<时间>.log 里，行内再带一遍没有意义）
void logToFile(const std::string& level, const std::string& clock, const std::string& text) {
    if (g_sessionLog.empty()) return;
    std::ofstream out(std::filesystem::path(widen(g_sessionLog)),
                      std::ios::app | std::ios::binary);
    if (!out) return;
    out << timestamp("") << "  [" << level << "]  " << text << "\n";
}

std::string readIni(const std::string& file, const std::string& section,
                    const std::string& key, const std::string& def) {
    std::ifstream in(std::filesystem::path(widen(file)), std::ios::binary);
    if (!in) return def;
    std::string line;
    std::string current;
    while (std::getline(in, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        const std::string trimmed = [&] {
            std::size_t b = line.find_first_not_of(" \t");
            if (b == std::string::npos) return std::string();
            std::size_t e = line.find_last_not_of(" \t");
            return line.substr(b, e - b + 1);
        }();
        if (trimmed.empty() || trimmed[0] == ';' || trimmed[0] == '#') continue;
        if (trimmed.front() == '[' && trimmed.back() == ']') {
            current = trimmed.substr(1, trimmed.size() - 2);
            continue;
        }
        if (current != section) continue;
        const std::size_t eq = trimmed.find('=');
        if (eq == std::string::npos) continue;
        std::string k = trimmed.substr(0, eq);
        while (!k.empty() && (k.back() == ' ' || k.back() == '\t')) k.pop_back();
        if (k != key) continue;
        std::string v = trimmed.substr(eq + 1);
        while (!v.empty() && (v.front() == ' ' || v.front() == '\t')) v.erase(v.begin());
        return v;
    }
    return def;
}

bool writeIni(const std::string& file, const std::string& section,
              const std::string& key, const std::string& value) {
    std::vector<std::string> lines;
    {
        std::ifstream in(std::filesystem::path(widen(file)), std::ios::binary);
        std::string line;
        while (std::getline(in, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            lines.push_back(line);
        }
    }

    std::string header = "[" + section + "]";
    std::size_t sectionAt = lines.size();
    for (std::size_t i = 0; i < lines.size(); ++i) {
        std::string t = lines[i];
        t.erase(0, t.find_first_not_of(" \t") == std::string::npos ? t.size()
                                                                  : t.find_first_not_of(" \t"));
        if (t == header) {
            sectionAt = i;
            break;
        }
    }
    if (sectionAt == lines.size()) {
        if (!lines.empty() && !lines.back().empty()) lines.push_back("");
        lines.push_back(header);
        sectionAt = lines.size() - 1;
    }

    std::string prefix = key + "=";
    bool replaced = false;
    std::size_t insertAt = sectionAt + 1;
    for (std::size_t i = sectionAt + 1; i < lines.size(); ++i) {
        std::string t = lines[i];
        const std::size_t b = t.find_first_not_of(" \t");
        if (b == std::string::npos) {
            insertAt = i + 1;
            continue;
        }
        if (t[b] == '[') break;
        insertAt = i + 1;
        if (t.compare(b, prefix.size(), prefix) == 0) {
            lines[i] = prefix + value;
            replaced = true;
            break;
        }
    }
    if (!replaced) {
        lines.insert(lines.begin() + static_cast<std::ptrdiff_t>(insertAt), prefix + value);
    }

    std::ofstream out(std::filesystem::path(widen(file)), std::ios::binary | std::ios::trunc);
    if (!out) return false;
    for (const std::string& l : lines) out << l << "\r\n";
    return true;
}

std::string authorIniPath() {
    return appDir() + "\\author.ini";
}

std::string appIniPath() {
    return appDir() + "\\config.ini";
}

void ensureAuthorIni() {
    const std::string path = authorIniPath();
    if (fileExists(path)) return;
    std::ofstream out(std::filesystem::path(widen(path)), std::ios::binary | std::ios::trunc);
    if (!out) return;
    out << "; ------------------------------------------------------------------\r\n"
          "; 界面上的作者联系方式为程序内置固化信息，本文件仅控制名称、头像与赞赏码。\r\n"
          "; 支持中文；等号右侧直接写内容。删除本文件会在下次启动时重新生成模板。\r\n"
          "; ------------------------------------------------------------------\r\n"
          "[author]\r\n"
          "; 下面这些填「未填写」时，界面上对应按钮会置灰\r\n"
          "name=茗茗茗茗\r\n"
          "role=独立开发者 · Android 折腾爱好者\r\n"
          "slogan=做能用、好用、不烦人的工具\r\n"
          "avatar=about/avatar.png\r\n"
          << "qq=" << OBF("1241252612") << "\r\n"
          << "qq_group=" << OBF("3842920539") << "\r\n"
          << "group_name=Min RooT 交流群\r\n"
          << "email=未填写\r\n"
          << "homepage=" << OBF("https://github.com/minsao889-oss/SiliconRootTool") << "\r\n"
          << "project=" << OBF("https://github.com/minsao889-oss/SiliconRootTool") << "\r\n"
        "\r\n"
        "[donate]\r\n"
        "; 赞赏码图片放到下面路径，点击卡片会在窗口内放大显示（手机直接扫）；文件不存在时显示占位提示\r\n"
        "alipay=about/alipay.png\r\n"
        "wechat=about/wechat.png\r\n"
        "note=如果这个工具帮你省了时间，可以请我喝杯咖啡 · 完全自愿\r\n"
        "\r\n"
        "[app]\r\n"
        "version=3.3.0\r\n"
        "build=2026-10-21\r\n"
        "license=仅供本人拥有并授权的设备使用\r\n";
}

void ensureAppIni() {
    const std::string path = appIniPath();
    if (fileExists(path)) return;
    std::ofstream out(std::filesystem::path(widen(path)), std::ios::binary | std::ios::trunc);
    if (!out) return;
    out <<
        "; 窗口与状态记忆，关闭窗口时自动写回\r\n"
        "[window]\r\n"
        "width=1360\r\n"
        "height=900\r\n"
        "maximized=0\r\n"
        "\r\n"
        "[state]\r\n"
        "last_manager=kernelsu\r\n"
        "last_page=0\r\n"
        "\r\n"
        "[ui]\r\n"
        "; dark = 深色主题，light = 浅色主题（界面上也能切）\r\n"
        "theme=dark\r\n";
}

bool fileExists(const std::string& path) {
    std::error_code ec;
    return !path.empty() && std::filesystem::exists(std::filesystem::path(widen(path)), ec) && !ec;
}

// 把配置里可能出现的相对路径 / 正斜杠 / 混合分隔符，统一成 ShellExecuteW 认得
// 的绝对 Windows 路径。
//
// 历史 bug：author.ini 里写的是 "assets/about/alipay.png"（正斜杠相对路径），
// 直接丢给 ShellExecuteW 会静默失败（它按当前工作目录解析，而工具是从任意目录
// 启动的），表现为「点卡片什么都不发生」。所以这里必须自己拼成绝对路径。
std::wstring resolvePathW(const std::string& path) {
    // 逻辑资源相对路径（"about/alipay.png"）→ 走受控入口拿到可用的磁盘路径；
    // 加密形态下这一步会把文件解到 runtime 缓存目录。
    const std::string logical = assets::normalize(path);
    if (!logical.empty() && logical.find(':') == std::string::npos &&
        !(logical.size() > 1 && (logical[0] == '\\' || logical[0] == '/'))) {
        const std::string resolved = assets::pathForExternal(logical);
        if (!resolved.empty()) {
            std::wstring w = widen(resolved);
            for (wchar_t& ch : w) {
                if (ch == L'/') ch = L'\\';
            }
            return w;
        }
    }
    std::filesystem::path p(widen(path));
    if (!p.is_absolute()) p = std::filesystem::path(widen(appDir())) / p;
    std::error_code ec;
    const std::filesystem::path canon = std::filesystem::weakly_canonical(p, ec);
    const std::filesystem::path& use = (ec || canon.empty()) ? p : canon;
    std::wstring out = use.wstring();
    for (wchar_t& ch : out) {
        if (ch == L'/') ch = L'\\';
    }
    return out;
}

void openFolder(const std::string& path) {
    if (path.empty()) return;
    const std::wstring full = resolvePathW(path);
    const HINSTANCE r = ShellExecuteW(nullptr, L"open", full.c_str(), nullptr,
                                      nullptr, SW_SHOWNORMAL);
    // ShellExecuteW 失败时返回值 <= 32，不抛异常也不弹窗，必须自己记日志
    if (reinterpret_cast<std::intptr_t>(r) <= 32) {
        HANDLE h = ShellExecuteW(nullptr, L"open", L"explorer.exe",
                                 (L"/select,\"" + full + L"\"").c_str(), nullptr,
                                 SW_SHOWNORMAL);
        (void)h;
    }
}

void openFile(const std::string& path) {
    if (path.empty()) return;
    const std::wstring full = resolvePathW(path);
    std::error_code ec;
    if (!std::filesystem::exists(std::filesystem::path(full), ec) || ec) {
        // 文件不存在时退回打开所在目录，避免「点了没反应」
        const std::size_t slash = full.find_last_of(L'\\');
        const std::wstring dir = (slash == std::wstring::npos) ? full : full.substr(0, slash);
        ShellExecuteW(nullptr, L"open", dir.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
        return;
    }
    const HINSTANCE r = ShellExecuteW(nullptr, L"open", full.c_str(), nullptr,
                                      nullptr, SW_SHOWNORMAL);
    if (reinterpret_cast<std::intptr_t>(r) <= 32) {
        const std::size_t slash = full.find_last_of(L'\\');
        const std::wstring dir = (slash == std::wstring::npos) ? full : full.substr(0, slash);
        ShellExecuteW(nullptr, L"open", dir.c_str(), nullptr, nullptr, SW_SHOWNORMAL);
    }
}

bool copyTextToClipboard(const std::string& utf8) {
    if (utf8.empty()) return false;
    const std::wstring wide = widen(utf8);
    if (!OpenClipboard(nullptr)) return false;
    EmptyClipboard();
    const std::size_t bytes = (wide.size() + 1) * sizeof(wchar_t);
    HGLOBAL mem = GlobalAlloc(GMEM_MOVEABLE, bytes);
    if (!mem) {
        CloseClipboard();
        return false;
    }
    void* dst = GlobalLock(mem);
    if (!dst) {
        GlobalFree(mem);
        CloseClipboard();
        return false;
    }
    std::memcpy(dst, wide.c_str(), bytes);
    GlobalUnlock(mem);
    if (!SetClipboardData(CF_UNICODETEXT, mem)) {
        GlobalFree(mem);
        CloseClipboard();
        return false;
    }
    CloseClipboard();
    return true;
}

} // namespace backend
