#include "app.h"

#include "obfstr.h"

#include "backend/assets.h"
#include "backend/bundle.h"
#include "backend/download.h"
#include "backend/process.h"
#include "backend/workspace.h"

#include <windows.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

namespace app {

namespace {
// 资源路径要在整个进程生命周期内有效（DslAppConfig 只存 char*），所以放静态区
struct AssetPaths {
    std::string fontMain;
    std::string fontIcon;
    std::string icon;
    std::string brand;
    std::string navbar;
};
const AssetPaths& assetPaths() {
    static const AssetPaths p = [] {
        AssetPaths a;
        a.fontMain = backend::assets::pathForExternal("JingNanJunJunTi-JinNanJunJunTi-Bold-2.ttf");
        a.fontIcon = backend::assets::pathForExternal("Font Awesome 7 Free-Solid-900.otf");
        a.icon = backend::assets::pathForExternal("icon.ico");
        a.brand = backend::assets::pathForExternal("icon-navbar.png");
        a.navbar = a.brand;
        return a;
    }();
    return p;
}
} // namespace

// LIQUID_FRAME: filled in by setupWindowChrome(), used when saving the window size.
HWND gAppChromeWindow = nullptr;

const DslAppConfig& dslAppConfig() {
    // 多文件形态：读程序目录下 config.ini 的窗口尺寸（首次启动由 ensureWorkspace 生成）
    static const DslAppConfig config = [] {
        backend::ensureWorkspace();
        backend::ensureAuthorIni();
        backend::ensureAppIni();

        const std::string ini = backend::appIniPath();
        float w = 1360.0f;
        float h = 900.0f;
        try {
            const std::string sw = backend::readIni(ini, "window", "width", "1360");
            const std::string sh = backend::readIni(ini, "window", "height", "900");
            w = std::clamp(static_cast<float>(std::atof(sw.c_str())), 1180.0f, 6000.0f);
            h = std::clamp(static_cast<float>(std::atof(sh.c_str())), 780.0f, 4000.0f);
        } catch (...) {
        }

        // LIQUID_COMPAT: never open larger than the usable desktop. Windows 7/10
        // laptops are commonly 1366x768 or 1024x768, where a 1360x900 window would
        // hang off the screen (looks like a broken / unusable app).
        {
            const int screenW = GetSystemMetrics(SM_CXSCREEN);
            const int screenH = GetSystemMetrics(SM_CYSCREEN);
            if (screenW > 0 && screenH > 0) {
                const float maxW = static_cast<float>(screenW) * 0.94f;
                const float maxH = static_cast<float>(screenH) * 0.90f;
                w = std::min(w, std::max(960.0f, maxW));
                h = std::min(h, std::max(640.0f, maxH));
            }
        }

        // 字体 / 图标 / 品牌图统一从受控入口取（加密形态下会解密到 runtime 缓存）
        const AssetPaths& paths = assetPaths();

        DslAppConfig config = DslAppConfig{}
            .title("Min RooT - 管理器安装与提权")
            .pageId("silicon_root_tool")
            .appId("silicon.root.tool")
            // 窗口底色跟主题走。这个配置只在启动时算一次，所以直接读 ini 里的
            // [ui] theme；运行时切换由 root.bg 那层全屏矩形盖住，不受影响。
            .clearColor(backend::readIni(ini, "ui", "theme", "dark") == "light"
                            ? core::Color{1.0f, 1.0f, 1.0f, 1.0f}
                            : core::Color{0.0f, 0.0f, 0.0f, 1.0f})
            .transparent(false)
            .windowSize(w, h)
            .minWindowSize(std::min(1180.0f, w), std::min(780.0f, h))
            .resizable(true)
            .decorated(true)
            .highDpi(true)
            .fps(90.0f)
            .iconPath(paths.icon.c_str())
            .fonts(paths.fontMain.c_str(), paths.fontIcon.c_str())
            .onStart([] {
                backend::ensureWorkspace();
                backend::sweepStaleBundles();   // 清掉上次被强杀留下的解密缓存
                AppState& s = state();
                s.admin = backend::isAdmin();
                const std::string lastPage = backend::readIni(backend::appIniPath(), "state",
                                                              "last_page", "0");
                s.page = static_cast<Page>(std::clamp(std::atoi(lastPage.c_str()), 0, 4));
                // 运行方式：Cold / Refire / Interactive，默认 Interactive（点一下就打、不预先重启）
                const std::string runMode =
                    backend::readIni(backend::appIniPath(), "state", "run_mode", "Interactive");
                s.runMode = (runMode == "Cold" || runMode == "Refire") ? runMode
                                                                      : std::string("Interactive");

                loadMirrorSettings();
                logLine(LOG_INFO, std::string("启动 Min RooT · 运行方式=") +
                                       AppState::runModeLabel(s.runMode) +
                                       (s.admin ? " · 管理员" : " · 普通权限"));
                logLine(LOG_INFO, "会话日志 · " + backend::sessionLogPath());
                logLine(LOG_INFO, "网络代理 · " + backend::systemProxySummary());
                loadTheme();
                logLine(LOG_INFO, std::string("界面主题 · ") +
                                       (s.darkTheme ? "深色" : "浅色") + " · 已加载");
                // 框架只在窗口创建时用 stbi 读 iconPath 设一次窗口图标，而 stbi 不认 ICO
                // （assets/icon.ico 会被它直接忽略，窗口图标其实是空的）。这里自己补一次。
                applyWindowIconForTheme();
                // 深色主题下标题栏不能是系统白：用 DWM 刷成与界面同色
                applyTitlebarForTheme();
                logLine(LOG_INFO, "设备监听 · 已启动");
                // 设备状态改为实时监听：插拔 USB / 授权完成后会自动识别，不需要手动刷新
                startDeviceWatcher();
                startHomeWatcher();
            })
            .onShutdown([] {
                AppState& s = state();
                const std::string ini = backend::appIniPath();
                // 关窗时顺手结束投屏进程，避免留下孤儿 scrcpy
                if (s.mirrorRunning && s.mirrorTask != 0) {
                    backend::cancelStreaming(s.mirrorTask);
                }
                if (s.lastW > 400.0f && s.lastH > 300.0f) {
                    // LIQUID_FRAME: s.lastW/lastH are the *client* size in dp, but the
                    // window is created from these numbers as the outer size. With
                    // WS_THICKFRAME (we add it for free resizing) the difference is the
                    // frame, so saving the raw client size made the window shrink by a few
                    // pixels on every launch. Save client + frame instead.
                    float frameW = 0.0f;
                    float frameH = 0.0f;
                    HWND chrome = gAppChromeWindow != nullptr ? gAppChromeWindow : GetActiveWindow();
                    RECT wr{};
                    if (chrome != nullptr && GetWindowRect(chrome, &wr) != FALSE) {
                        frameW = static_cast<float>((wr.right - wr.left) - static_cast<int>(s.lastW));
                        frameH = static_cast<float>((wr.bottom - wr.top) - static_cast<int>(s.lastH));
                        if (frameW < 0.0f) {
                            frameW = 0.0f;
                        }
                        if (frameH < 0.0f) {
                            frameH = 0.0f;
                        }
                    }
                    backend::writeIni(ini, "window", "width",
                                      std::to_string(static_cast<int>(s.lastW + frameW + 0.5f)));
                    backend::writeIni(ini, "window", "height",
                                      std::to_string(static_cast<int>(s.lastH + frameH + 0.5f)));
                }
                backend::writeIni(ini, "state", "last_page",
                                  std::to_string(static_cast<int>(s.page)));
                backend::writeIni(ini, "state", "last_manager", s.selected);
                backend::writeIni(ini, "state", "run_mode", s.runMode);
                logLine(LOG_INFO, "退出程序 · 状态已保存 · 完成");
                backend::cleanupBundle();
            });

        // 帧率诊断开关：设置环境变量 SRT_FPS=1 时，标题栏每秒刷新一次
        // "FPS | CPU | Render ms"（框架 core/app/app_runner.h 自带），方便现场测帧率。
        // 默认关闭，正式版标题栏保持干净。
        char fpsProbe[16] = {};
        const DWORD fpsProbeLen = GetEnvironmentVariableA("SRT_FPS", fpsProbe, sizeof(fpsProbe));
        if (fpsProbeLen > 0 && fpsProbeLen < sizeof(fpsProbe)) {
            config.showDebugStatsInTitle(std::string(fpsProbe) != "0");
        }
        return config;
    }();
    return config;
}

namespace {

constexpr float kNavWidth = 248.0f;
constexpr bool kUseNativeTitlebar = true;
constexpr float kTitleBarH = kUseNativeTitlebar ? 0.0f : 46.0f;
constexpr float kPad = 32.0f;

void composeNavigation(eui::Ui& ui, float width, float height) {
    AppState& s = state();
    components::navbar(ui, "navigation")
        .theme(theme())
        .size(width, height)
        .compact(false)
        .brand("Min RooT", 0xF135)
        .brandImage(assetPaths().brand.c_str())
        .brandImageSize(48.0f)
        .subtitle("管理器安装与提权")
        .selected(static_cast<int>(s.page))
        .items({
            {"home", "主页", 0xF015, 0},
            {"tool", "提权", 0xF135, 1},
            {"managers", "管理器", 0xF1C0, 2},
            {"mirror", "安卓投屏", 0xF26C, 3},
            {"about", "关于作者", 0xF007, 4},
        })
        .footer("连接设备", 0xF021, [] { actionConnectDevice(); })
        .transition(motion())
        .onChange([](int page) {
            AppState& inner = state();
            inner.page = static_cast<Page>(std::clamp(page, 0, 4));
            inner.popup = Popup::None;
            backend::writeIni(backend::appIniPath(), "state", "last_page",
                              std::to_string(static_cast<int>(inner.page)));
        })
        .build();
}

// 赞赏码放大层：点卡片不是丢给系统看图软件，而是在应用里铺一个大图，
// 手机对着屏幕直接扫。窗口背景调暗，点任意空白处关闭。
void composeDonateZoom(eui::Ui& ui, const eui::Screen& screen, Popup which,
                       const std::string& id, const std::string& title) {
    AppState& s = state();

    // 只在真正要显示时才读 ini：这个函数每帧都被调用，读盘不能放在热路径上。
    if (s.popup != which) {
        return;
    }

    std::string path = backend::readIni(backend::authorIniPath(), "donate",
                                        which == Popup::ZoomAlipay ? "alipay" : "wechat",
                                        "");
    if (path.empty() || !backend::fileExists(path)) {
        // 逻辑路径（author.ini 里是 "about/alipay.png" 这类包内路径）→ 走加密包解析
        const std::string bundled = backend::assets::pathForExternal(
            which == Popup::ZoomAlipay ? "about/alipay.png" : "about/wechat.png");
        if (!bundled.empty() && backend::fileExists(bundled)) path = bundled;
    }
    if (path.empty() || !backend::fileExists(path)) {
        // 图没了就把弹窗状态收掉，否则会卡在一个点不掉的全屏遮罩上
        s.popup = Popup::None;
        logLine(LOG_WARN, "赞赏码 · 图片缺失 · 已关闭放大视图");
        return;
    }

    // 面板尺寸按二维码反推：二维码越大越好扫，其余只留标题条和一行提示
    const float pad = 22.0f;
    const float titleH = 26.0f;
    const float hintH = 22.0f;
    const float qr = std::min(420.0f, std::min(screen.width - 120.0f, screen.height - 160.0f));
    const float panelW = qr + pad * 2.0f;
    const float panelH = titleH + qr + hintH + 20.0f;

    components::dialog(ui, id)
        .theme(theme())
        .screen(screen.width, screen.height)
        .size(panelW, panelH)
        .open(s.popup == which)
        .onOpenChange([](bool open) {
            if (!open) state().popup = Popup::None;
        })
        .content([&ui, path, title, id, panelW, panelH, pad, qr, titleH, hintH] {
            ui.text(id + ".title")
                .x(pad).y((titleH - 22.0f) * 0.5f).size(panelW - pad * 2.0f, 22.0f)
                .text(title).fontSize(16.0f).lineHeight(22.0f).fontWeight(740)
                .color(theme().text).build();

            // 二维码贴一个大白底，深色主题下更容易扫出来
            ui.rect(id + ".qrbg")
                .x((panelW - qr) * 0.5f).y(titleH).size(qr, qr)
                .color({1.0f, 1.0f, 1.0f, 1.0f})
                .radius(12.0f).build();

            ui.image(id + ".qr")
                .x((panelW - qr) * 0.5f).y(titleH).size(qr, qr)
                .source(path)
                .radius(12.0f)
                .contain()
                .build();

            ui.text(id + ".hint")
                .x(pad).y(titleH + qr + 10.0f).size(panelW - pad * 2.0f, hintH - 4.0f)
                .text("手机对着屏幕扫码 · 点空白处关闭")
                .fontSize(12.0f).lineHeight(18.0f)
                .horizontalAlign(eui::HorizontalAlign::Center)
                .color(components::theme::withAlpha(theme().text, 0.55f)).build();
        })
        .build();
}

void composeDialogLayer(eui::Ui& ui, const eui::Screen& screen) {
    AppState& s = state();

    composeDonateZoom(ui, screen, Popup::ZoomAlipay, "dlg.zoom.alipay", "支付宝赞赏");
    composeDonateZoom(ui, screen, Popup::ZoomWechat, "dlg.zoom.wechat", "微信赞赏");

    components::dialog(ui, "dlg.warn")
        .theme(theme())
        .screen(screen.width, screen.height)
        .size(430.0f, 214.0f)
        .title("尚未安装管理器")
        .message("请先安装并检测到管理器后再提权。当前管理器：" + selectedName() +
                 "，状态：" + backend::stateLabel(selectedState()) + "。")
        .primaryText("去安装")
        .secondaryText("知道了")
        .open(s.popup == Popup::WarnNoManager)
        .onOpenChange([](bool open) {
            if (!open) state().popup = Popup::None;
        })
        .onPrimary([] {
            AppState& inner = state();
            inner.popup = Popup::None;
            inner.page = Page::Managers;
        })
        .onSecondary([] { state().popup = Popup::None; })
        .build();

    components::dialog(ui, "dlg.uninstall")
        .theme(theme())
        .screen(screen.width, screen.height)
        .size(430.0f, 214.0f)
        .title("确认卸载？")
        .message("将卸载所选管理器：" + selectedName() + "。卸载后需要重新安装并检测才能再次提权。")
        .primaryText("确认卸载")
        .secondaryText("取消")
        .open(s.popup == Popup::ConfirmUninstall)
        .onOpenChange([](bool open) {
            if (!open) state().popup = Popup::None;
        })
        .onPrimary([] {
            state().popup = Popup::None;
            actionUninstall();
        })
        .onSecondary([] { state().popup = Popup::None; })
        .build();

    components::dialog(ui, "dlg.reboot")
        .theme(theme())
        .screen(screen.width, screen.height)
        .size(440.0f, 220.0f)
        .title(state().pendingRebootTarget.empty() ? "确认重启设备？"
                                                   : ("确认" + state().pendingRebootLabel + "？"))
        .message(state().pendingRebootTarget.empty()
                     ? ("将给手机发送 adb reboot（" + state().device.serial + " · " +
                        state().device.model + "）。重启会清掉临时 root，重启后需要重新执行提权。")
                     : ("将给手机发送 adb reboot " + state().pendingRebootTarget + "（" +
                        state().detail.serial + "）。这是不可撤销的操作，手机立即离开当前系统，"
                        "重启后会清掉临时 root，需要重新执行提权。"))
        .primaryText(state().pendingRebootTarget.empty() ? "确认重启" : state().pendingRebootLabel)
        .secondaryText("取消")
        .open(s.popup == Popup::ConfirmReboot)
        .onOpenChange([](bool open) {
            if (!open) {
                state().popup = Popup::None;
                state().pendingRebootTarget.clear();
                state().pendingRebootLabel.clear();
            }
        })
        .onPrimary([] {
            state().popup = Popup::None;
            // 下拉里选的「重启到 X」：目标非空走带参数的那一支，否则是普通 adb reboot。
            const std::string target = state().pendingRebootTarget;
            state().pendingRebootTarget.clear();
            state().pendingRebootLabel.clear();
            if (target.empty()) {
                actionRebootDevice();
            } else {
                actionRebootInto(target);
            }
        })
        .onSecondary([] {
            state().popup = Popup::None;
            state().pendingRebootTarget.clear();
            state().pendingRebootLabel.clear();
        })
        .build();

    // 检查更新后的确认框：把「哪些要更新」列清楚，点「全部更新」才真去下载安装。
    // 消息体逐条拼名字 + 版本变化，条数少时正好一屏，不必做成列表控件。
    {
        std::string lines;
        std::vector<std::string> keys;
        for (const auto& item : s.updates) {
            if (!item.hasUpdate) continue;
            keys.push_back(item.key);
            if (!item.installed) {
                const std::string lv = item.localVersion.empty() ? "未知" : item.localVersion;
                lines += "· " + item.name + "   可安装内置包 " + lv + "\n";
                continue;
            }
            std::string from = item.installedVersion.empty() ? item.localVersion : item.installedVersion;
            if (from.empty()) from = "未知";
            lines += "· " + item.name + "   " + from + " → " + item.latestVersion + "\n";
        }
        if (lines.empty()) lines = "（没有可更新的管理器）";
        const bool multiple = keys.size() > 1;
        components::dialog(ui, "dlg.update")
            .theme(theme())
            .screen(screen.width, screen.height)
            .size(520.0f, 340.0f)
            .title(multiple ? ("发现 " + std::to_string(keys.size()) + " 个管理器可安装/更新")
                            : "发现 1 个管理器可安装/更新")
            .message(lines + "\n将优先使用内置安装包，本地缺失时才下载最新包，"
                             "再 adb install -r -d 安装。结束后临时 root 可能需要重新执行一次提权。")
            .primaryText(multiple ? "全部安装/更新" : "立即安装/更新")
            .secondaryText("取消")
            .open(s.popup == Popup::ConfirmUpdate)
            .onOpenChange([](bool open) {
                if (!open) state().popup = Popup::None;
            })
            .onPrimary([] {
                state().popup = Popup::None;
                actionApplyUpdates(pendingUpdateKeys());
            })
            .onSecondary([] { state().popup = Popup::None; })
            .build();
    }
}

// 按像素宽度粗略裁剪（CJK 记 1 个字宽，ASCII 记 0.55），超宽补省略号
std::string clipText(const std::string& text, float maxWidth, float fontSize) {
    if (maxWidth <= 8.0f) return text;
    float used = 0.0f;
    std::size_t i = 0;
    while (i < text.size()) {
        const unsigned char c = static_cast<unsigned char>(text[i]);
        std::size_t step = 1;
        if ((c & 0x80) == 0x00) step = 1;
        else if ((c & 0xE0) == 0xC0) step = 2;
        else if ((c & 0xF0) == 0xE0) step = 3;
        else step = 4;
        const float w = (step == 1) ? fontSize * 0.55f : fontSize;
        if (used + w > maxWidth - fontSize * 0.8f) {
            return text.substr(0, i) + "…";
        }
        used += w;
        i += step;
    }
    return text;
}
// 侧栏底部：主题切换（两段式，「深色 / 浅色」）
// 放在设备卡下方，导航栏 footer 按钮（连接设备）之上。
void composeThemeSwitch(eui::Ui& ui, float width, float height) {
    const float inset = 30.0f;
    const float segW = std::max(120.0f, width - inset * 2.0f);
    const float segH = 34.0f;
    // 设备卡上沿在 height - 82 - 10 - 70；这里再往上让 8px 呼吸
    const float cardY = std::max(120.0f, height - 82.0f - 10.0f - 70.0f);
    const float segY = cardY - segH - 14.0f;

    ui.text("side.theme.label")
        .position(inset, segY - 22.0f).size(segW, 18.0f)
        .text("界面主题").fontSize(11.5f).lineHeight(17.0f).fontWeight(720)
        .color(textFaint()).build();

    // SegmentedBuilder 不继承 BuilderBase，没有 .position()/.x()/.y()，
    // 它内部的 stack 默认落在父容器 (0,0)。所以套一层定位用的 stack，
    // 否则这个两段开关会跑到窗口左上角盖住导航栏顶部。
    ui.stack("side.theme.box")
        .position(inset, segY)
        .size(segW, segH)
        .content([&ui, segW, segH] {
            components::segmented(ui, "side.theme.seg")
                .size(segW, segH)
                .items({"深色", "浅色"})
                .selected(state().darkTheme ? 0 : 1)
                .fontSize(13.0f)
                .theme(theme())
                .transition(motion())
                .onChange([](int index) { setDarkTheme(index == 0); })
                .build();
        })
        .build();
}

// 侧栏底部：当前连接的设备（放在「检测设备」按钮上方）
void composeSidebarDevice(eui::Ui& ui, float width, float height) {
    // 拷一份快照：监听线程随时可能改写 state().device，不能拿引用
    backend::DeviceInfo dev;
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        dev = state().device;
    }
    const float inset = 30.0f;                 // 与 navbar 的 sideInset 一致
    const float cardW = std::max(120.0f, width - inset * 2.0f);
    const float cardH = 70.0f;
    const float cardX = inset;
    const float cardY = std::max(120.0f, height - 82.0f - 10.0f - cardH);

    components::panel(ui, "side.dev.card", theme())
        .position(cardX, cardY).size(cardW, cardH)
        .radius(12.0f)
        .color(components::theme::withAlpha(theme().surface, 0.9f))
        .border(1.0f, borderColor(dev.ready ? 0.55f : 0.4f))
        .transition(motion())
        .build();

    const eui::Color dotColor = dev.ready ? components::theme::color(0.298f, 0.765f, 0.541f)
                                          : components::theme::color(0.478f, 0.510f, 0.561f);
    components::panel(ui, "side.dev.dot", theme())
        .position(cardX + 12.0f, cardY + 14.0f).size(8.0f, 8.0f)
        .radius(4.0f).color(dotColor).build();

    ui.text("side.dev.title")
        .position(cardX + 26.0f, cardY + 8.0f).size(cardW - 38.0f, 18.0f)
        .text(dev.ready ? "已连接设备" : "未连接设备")
        .fontSize(12.5f).lineHeight(18.0f).fontWeight(750)
        .color(dev.ready ? textPrimary() : textMuted()).build();

    const std::string line1 = dev.ready ? dev.serial
                                        : (dev.message.empty() ? std::string("未检测到设备")
                                                               : dev.message);
    ui.text("side.dev.line1")
        .position(cardX + 12.0f, cardY + 28.0f).size(cardW - 24.0f, 18.0f)
        .text(clipText(line1, cardW - 24.0f, 11.5f))
        .fontSize(11.5f).lineHeight(18.0f)
        .color(dev.ready ? textMuted() : textFaint()).build();

    std::string line2;
    if (dev.ready) {
        line2 = dev.model;
        if (!dev.android.empty()) line2 += "  ·  Android " + dev.android;
    } else {
        line2 = "点此卡片或下方「连接设备」重试";
    }
    ui.text("side.dev.line2")
        .position(cardX + 12.0f, cardY + 46.0f).size(cardW - 24.0f, 16.0f)
        .text(clipText(line2, cardW - 24.0f, 11.0f))
        .fontSize(11.0f).lineHeight(16.0f).color(textFaint()).build();

    components::panel(ui, "side.dev.hit", theme())
        .position(cardX, cardY).size(cardW, cardH)
        .radius(12.0f)
        .color({0.0f, 0.0f, 0.0f, 0.0f})
        .interactive(true)
        .hoverColor(hoverTint())
        .pressedColor(pressedTint())
        .onClick([] { actionConnectDevice(); })
        .build();
}

void composeFooter(eui::Ui& ui, float x, float y, float width) {
    ui.text("footer.text")
        .position(x, y).size(std::max(200.0f, width - 160.0f), 18.0f)
        .text("仅限在本人拥有并授权的设备上使用  ·  提权工具由 Neo10-Root 提供  ·  UI 基于 EUI-NEO (Apache-2.0)")
        .fontSize(12.0f).lineHeight(17.0f).color(textFaint()).build();
    // 右下角固定署名：锚在内容区右下角，窗口缩放时始终贴住右下
    ui.text("footer.qq")
        .position(x + width - 150.0f, y).size(150.0f, 18.0f)
        .text(OBF("QQ：1241252612"))
        .fontSize(12.0f).lineHeight(17.0f)
        .color(components::theme::withAlpha(theme().text, 0.45f))
        .horizontalAlign(eui::HorizontalAlign::Right).build();
}

// ---- 动态视频背景（帧序列）--------------------------------------------------
// assets\app-bg-frames\ 里是从视频抽好的帧序列（本次交付：120 帧 f000.jpg…f119.jpg，
// 560x300 / 15fps）。帧数与播放节奏一律以同目录的 manifest.txt 为准
// （frames= / fps= / width=），换素材不用改代码；manifest 缺失时退化为逐帧探测，
// 目录整体缺失则保持纯色底，行为与没有动态背景时一致。
// 这里不新增解码器、不重新抽帧：只是逐帧换 ui.image 的 .source()，把「静态壁纸」
// 升级成「动态壁纸」。框架的图片纹理缓存（core/render/image.cpp：32 张 idle /
// 64MB 上限 LRU，按 路径+mtime 作 key）负责显存回收，120 帧不会被全部常驻，
// 未命中的帧按需重新解码。实测（RX 580，1376x939 窗口，24 秒连续播放）：
// 进程专用显存稳定 92.7MB（没有帧序列时 43.6MB，动态背景约占 49MB），
// 两轮 120 帧循环后不增长；主循环 86~90 FPS、Render ~0.9ms、CPU 0~1%。
// 玻璃控件 blit 的是「已经渲染完的画面」，背景一动，玻璃里的模糊/折射内容
// 自然就是动态的，不用改任何玻璃控件。

// ---------------------------------------------------------------- designed background
// Procedural wallpaper: vertical gradient + soft glow blobs built from stacked
// translucent circles (no image assets, no texture memory).
[[maybe_unused]] static void glowBlob(eui::Ui& ui, const std::string& id, float cx, float cy, float radius,
                     const eui::Color& color, int rings) {
    if (rings < 1) rings = 1;
    for (int i = 0; i < rings; ++i) {
        const float t = static_cast<float>(i) / static_cast<float>(rings - 1 ? rings - 1 : 1);
        const float r = radius * (1.0f - 0.72f * t);
        const float a = color.a * (0.55f / static_cast<float>(rings));
        ui.rect(id + "." + std::to_string(i))
            .position(cx - r, cy - r).size(r * 2.0f, r * 2.0f)
            .radius(r)
            .color(eui::Color{color.r, color.g, color.b, a})
            .build();
    }
}

struct WallpaperFrames {
    std::vector<std::string> paths;   // 已解析成可交给渲染层的磁盘路径
    int width = 0;                    // manifest 声明的原始宽度（只用于日志）
    int declaredFrames = 0;           // manifest 声明的帧数（实际可用帧数看 paths）
    float fps = 15.0f;                // 播放节奏，来自 manifest 的 fps=
    bool ok() const { return paths.size() >= 2; }
};

// manifest.txt 是极简 "key=value" 文本（frames=120 / fps=15.0 / width=560 / bytes=…）。
// 只在行首匹配，避免 "frames=" 误命中别的前缀子串。
bool manifestNumber(const std::string& text, const char* key, double& out) {
    const std::string needle = std::string(key) + "=";
    std::size_t pos = 0;
    while ((pos = text.find(needle, pos)) != std::string::npos) {
        const bool atLineStart = (pos == 0 || text[pos - 1] == '\n' || text[pos - 1] == '\r');
        if (atLineStart) {
            const char* begin = text.c_str() + pos + needle.size();
            char* end = nullptr;
            const double value = std::strtod(begin, &end);
            if (end != begin) {
                out = value;
                return true;
            }
            return false;
        }
        pos += needle.size();
    }
    return false;
}

// assets::pathForExternal 给出的是 UTF-8 窄路径（安装目录可能含中文，例如「下载」），
// 所以统一转成宽字符再走 Win32 文件 API，绕开 std::ifstream 的 ANSI 代码页问题。
std::wstring widenPathUtf8(const std::string& utf8) {
    if (utf8.empty()) return std::wstring();
    const int len = MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()),
                                        nullptr, 0);
    std::wstring out(static_cast<std::size_t>(len), L'\0');
    if (len > 0) {
        MultiByteToWideChar(CP_UTF8, 0, utf8.data(), static_cast<int>(utf8.size()), out.data(), len);
    }
    return out;
}

// 读一个磁盘上的小文本文件（manifest.txt 只有几十字节）。失败返回 false。
bool readSmallTextFile(const std::string& utf8Path, std::string& out) {
    if (utf8Path.empty()) return false;
    const std::wstring wide = widenPathUtf8(utf8Path);
    if (wide.empty()) return false;
    HANDLE handle = CreateFileW(wide.c_str(), GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                                nullptr, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (handle == INVALID_HANDLE_VALUE) return false;
    LARGE_INTEGER size{};
    if (!GetFileSizeEx(handle, &size) || size.QuadPart <= 0 || size.QuadPart > (1 << 20)) {
        CloseHandle(handle);
        return false;
    }
    out.resize(static_cast<std::size_t>(size.QuadPart));
    DWORD read = 0;
    const bool ok = ReadFile(handle, out.data(), static_cast<DWORD>(out.size()), &read, nullptr) != 0;
    CloseHandle(handle);
    if (!ok) {
        out.clear();
        return false;
    }
    out.resize(read);
    return true;
}

const WallpaperFrames& wallpaperFrames() {
    static const WallpaperFrames frames = [] {
        WallpaperFrames f;
        // 帧数 / 播放节奏以 manifest.txt 为准。注意不能用 backend::assets::read：
        // 它在明文形态下会「持锁再取锁」（bundle.cpp:462/476 的 ensureBundle 重入
        // 非递归 std::mutex）而抛 resource deadlock；这里走 pathForExternal + Win32 读盘。
        std::string manifest;
        const bool manifestOk = readSmallTextFile(
            backend::assets::pathForExternal("app-bg-frames/manifest.txt"), manifest);
        if (manifestOk) {
            double value = 0.0;
            if (manifestNumber(manifest, "fps", value) && value >= 1.0 && value <= 120.0) {
                f.fps = static_cast<float>(value);
            }
            if (manifestNumber(manifest, "width", value) && value > 0.0) {
                f.width = static_cast<int>(value);
            }
            if (manifestNumber(manifest, "frames", value) && value >= 2.0 && value <= 600.0) {
                f.declaredFrames = static_cast<int>(value);
            }
        }
        // 逐帧探测而不是扫目录：加密包形态下 assets 里没有真实目录可扫，
        // 必须走 assets::exists / pathForExternal 这个受控入口（两种形态都成立）。
        // manifest 给了帧数就按它探测（缺帧即停）；没给就退化为最多探 600 帧。
        const int maxFrames = f.declaredFrames > 0 ? f.declaredFrames : 600;
        for (int i = 0; i < maxFrames; ++i) {
            char name[64];
            std::snprintf(name, sizeof(name), "app-bg-frames/f%03d.jpg", i);
            if (!backend::assets::exists(name)) break;
            const std::string path = backend::assets::pathForExternal(name);
            if (path.empty()) break;
            f.paths.push_back(path);
        }
        if (f.ok()) {
            logLine(LOG_INFO, "动态背景 · 帧序列 " + std::to_string(f.paths.size()) + " 帧 · " +
                                  std::to_string(static_cast<int>(f.fps)) + " fps · 已启用");
        } else {
            logLine(LOG_WARN, "动态背景 · assets\\app-bg-frames 缺失或不完整 · 回落静态底色");
        }
        return f;
    }();
    return frames;
}

// 帧播放状态：跨 compose 保活（同 components/workshop/heart_switch.h 的做法），
// 只放时间累加器和帧号，不持有任何 GL 资源，所以页面切换/状态回收都不会漏纹理。
struct WallpaperPlayback {
    double clock = 0.0;   // 未满一帧的余量（秒）
    int frame = 0;        // 当前帧号
};

} // namespace

// ---- custom window chrome -------------------------------------------------
// The native title bar is removed (DslAppConfig::decorated(false)); this strip
// restores dragging plus minimize / maximize-restore / close buttons.
struct ChromeDragState {
    void* hwnd = nullptr;
    int startLeft = 0;
    int startTop = 0;
    float pixelScale = 1.0f;   // physical window px per logical dp
    int startCursorX = 0;      // physical cursor position when the drag began
    int startCursorY = 0;
};

void composeTitleBar(eui::Ui& ui, const eui::Screen& screen) {
    const bool light = !theme().dark;
    const float w = screen.width;
    const float btnW = 44.0f;
    const float btnH = 32.0f;
    const float gap = 2.0f;
    const float rightPad = 10.0f;
    const float by = (kTitleBarH - btnH) * 0.5f;
    const float bx0 = w - rightPad - btnW * 3.0f - gap * 2.0f;

    // A faint glass band so the row reads as a title bar instead of empty space.
    ui.rect("chrome.band")
        .position(0.0f, 0.0f).size(w, kTitleBarH)
        .gradient(light ? eui::Color{1.0f, 1.0f, 1.0f, 0.30f}
                        : eui::Color{0.09f, 0.11f, 0.15f, 0.55f},
                  light ? eui::Color{1.0f, 1.0f, 1.0f, 0.05f}
                        : eui::Color{0.05f, 0.06f, 0.09f, 0.26f})
        .build();

    ui.text("chrome.title")
        .position(18.0f, 0.0f).size(std::max(0.0f, bx0 - 26.0f), kTitleBarH)
        .text("Min RooT")
        .fontSize(12.0f).lineHeight(kTitleBarH)
        .color(components::theme::withAlpha(theme().text, 0.55f))
        .build();

    // Drag anywhere on the strip except the buttons.
    ui.rect("chrome.drag")
        .position(0.0f, 0.0f).size(std::max(1.0f, bx0 - 6.0f), kTitleBarH)
        .color({0.0f, 0.0f, 0.0f, 0.0f})
        .interactive(true)
        .onPress([&ui, screen](const eui::PointerEvent&, const eui::Rect&) {
            ChromeDragState& st = ui.state<ChromeDragState>("chrome.dragfx");
            HWND h = GetForegroundWindow();
            st.hwnd = h;
            RECT rc{};
            if (h != nullptr && GetWindowRect(h, &rc)) {
                st.startLeft = rc.left;
                st.startTop = rc.top;
                const float logicalW = std::max(1.0f, screen.width);
                const float physicalW = static_cast<float>(rc.right - rc.left);
                st.pixelScale = (physicalW > 1.0f) ? (physicalW / logicalW) : 1.0f;
            }
            POINT cursor{};
            if (GetCursorPos(&cursor)) {
                st.startCursorX = cursor.x;
                st.startCursorY = cursor.y;
            }
        })
        .onDrag([&ui](const core::dsl::DragEvent& event) {
            ChromeDragState& st = ui.state<ChromeDragState>("chrome.dragfx");
            if (st.hwnd == nullptr) return;
            HWND h = static_cast<HWND>(st.hwnd);
            if (IsZoomed(h) != 0) return;   // dragging a maximized window is odd
            (void)event;
            POINT cursor{};
            if (!GetCursorPos(&cursor)) return;
            SetWindowPos(h, nullptr,
                         st.startLeft + (cursor.x - st.startCursorX),
                         st.startTop + (cursor.y - st.startCursorY), 0, 0,
                         SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
        })
        .build();

    ui_button(ui, "chrome.min", "", 0xF068, bx0, by, btnW, btnH, false, true, [] {
        HWND h = GetForegroundWindow();
        if (h != nullptr) ShowWindow(h, SW_MINIMIZE);
    });
    ui_button(ui, "chrome.max", "",
              IsZoomed(GetForegroundWindow()) != 0 ? 0xF066u : 0xF065u,
              bx0 + btnW + gap, by, btnW, btnH, false, true, [] {
        HWND h = GetForegroundWindow();
        if (h == nullptr) return;
        ShowWindow(h, IsZoomed(h) != 0 ? SW_RESTORE : SW_MAXIMIZE);
    });
    ui_button(ui, "chrome.close", "", 0xF00D,
              bx0 + (btnW + gap) * 2.0f, by, btnW, btnH, false, true, [] {
        HWND h = GetForegroundWindow();
        if (h != nullptr) PostMessageW(h, WM_CLOSE, 0, 0);
    });
}

// ---------------------------------------------------------------------------
// LIQUID_CHROME: rounded corners (Windows 11) + system-driven window drag.
// Returning HTCAPTION from WM_NCHITTEST lets DWM/DefWindowProc move the window
// itself. That is far smoother than calling SetWindowPos on every mouse move
// (the old path re-entered the window procedure on each move and dropped frames),
// and it also gives snap layouts + double-click-to-maximize for free.
// ---------------------------------------------------------------------------
struct NativeChrome {
    HWND hwnd = nullptr;
    WNDPROC prevProc = nullptr;
    HBRUSH bgBrush = nullptr;
    COLORREF bgColor = RGB(245, 247, 252);
    int radiusPx = 0;
    int regionW = 0;
    int regionH = 0;
    bool dwmRound = false;   // Win11: rely on DWM anti-aliased corners
};
NativeChrome gChrome;

// LIQUID_CORNER: a bigger corner radius than Windows 11 gives us (DWM only
// knows ~8px). The window gets a clipped radius region instead; maximized /
// full-screen windows stay square, exactly like the reference project
// (QRoundedFrame: CreateRoundRectRgn + SetWindowRgn).
// LIQUID_CORNER: a bigger corner radius than Windows 11 gives us (DWM only
// knows ~8px). The window gets a clipped radius region instead; maximized /
// full-screen windows stay square, exactly like the reference project
// (QRoundedFrame: CreateRoundRectRgn + SetWindowRgn).
constexpr float kWindowCornerDp = 22.0f;

// LIQUID_CORNER: Windows 11 renders round corners in DWM with anti-aliasing;
// SetWindowRgn (used for the bigger custom radius) is a hard binary mask and
// shows a staircase. On Win11 we therefore let DWM do the corners and skip
// the region entirely; Win10 and older still use the region path.
bool isWindows11() {
    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (ntdll == nullptr) {
        return false;
    }
    using RtlGetVersionFn = LONG(WINAPI*)(void*);
    auto rtlGetVersion = reinterpret_cast<RtlGetVersionFn>(
        reinterpret_cast<void*>(GetProcAddress(ntdll, "RtlGetVersion")));
    if (rtlGetVersion == nullptr) {
        return false;
    }
    struct OsVersion {
        ULONG size;
        ULONG major;
        ULONG minor;
        ULONG build;
        ULONG platform;
        WCHAR csd[128];
    } os{};
    os.size = sizeof(os);
    if (rtlGetVersion(&os) != 0) {
        return false;
    }
    return os.major >= 10 && os.build >= 22000;
}

void applyChromeRegion(HWND hwnd) {
    if (hwnd == nullptr) {
        return;
    }
    if (gChrome.dwmRound) {
        // Win11: DWM owns the corners (anti-aliased); clipping here would
        // only re-introduce the jagged staircase.
        return;
    }
    RECT windowRect{};
    if (GetWindowRect(hwnd, &windowRect) == FALSE) {
        return;
    }
    const int width = windowRect.right - windowRect.left;
    const int height = windowRect.bottom - windowRect.top;
    if (width <= 0 || height <= 0) {
        return;
    }
    const bool square = IsZoomed(hwnd) != FALSE || IsIconic(hwnd) != FALSE;
    int radius = 0;
    if (!square) {
        UINT dpi = 96;
        HMODULE user32 = GetModuleHandleW(L"user32.dll");
        if (user32 != nullptr) {
            using DpiFn = UINT(WINAPI*)(HWND);
            auto getDpi = reinterpret_cast<DpiFn>(
                reinterpret_cast<void*>(GetProcAddress(user32, "GetDpiForWindow")));
            if (getDpi != nullptr) {
                const UINT value = getDpi(hwnd);
                if (value != 0) {
                    dpi = value;
                }
            }
        }
        if (dpi == 96) {
            HDC screenDc = GetDC(nullptr);
            if (screenDc != nullptr) {
                const int caps = GetDeviceCaps(screenDc, LOGPIXELSX);
                if (caps > 0) {
                    dpi = static_cast<UINT>(caps);
                }
                ReleaseDC(nullptr, screenDc);
            }
        }
        radius = static_cast<int>(std::lround(kWindowCornerDp * dpi / 96.0));
        const int limit = std::min(width, height) / 2;
        radius = std::max(0, std::min(radius, limit));
    }
    if (gChrome.regionW == width && gChrome.regionH == height &&
        gChrome.radiusPx == radius) {
        return;
    }
    HRGN region = nullptr;
    if (radius <= 0) {
        region = CreateRectRgn(0, 0, width + 1, height + 1);
    } else {
        region = CreateRoundRectRgn(0, 0, width + 1, height + 1, radius * 2, radius * 2);
    }
    if (region == nullptr) {
        return;
    }
    if (SetWindowRgn(hwnd, region, TRUE) != 0) {
        gChrome.regionW = width;
        gChrome.regionH = height;
        gChrome.radiusPx = radius;
    } else {
        DeleteObject(region);
    }
}

// LIQUID_RESIZE: paint the client area with the theme background instead of
// letting Windows erase it to black. Called from WM_ERASEBKGND and from the
// resize messages, so the newly exposed strip is never black.
void paintChromeBackground(HWND hwnd) {
    if (hwnd == nullptr || gChrome.bgBrush == nullptr) {
        return;
    }
    RECT client{};
    if (GetClientRect(hwnd, &client) == FALSE) {
        return;
    }
    HDC dc = GetDC(hwnd);
    if (dc == nullptr) {
        return;
    }
    FillRect(dc, &client, gChrome.bgBrush);
    ReleaseDC(hwnd, dc);
}

LRESULT CALLBACK chromeWindowProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
    if (message == WM_SIZE || message == WM_EXITSIZEMOVE || message == WM_SIZING) {
        applyChromeRegion(hwnd);
    }
    // LIQUID_REPAINT: once the user stops dragging/resizing, force one clean
    // full repaint. Otherwise the frame of the previous position can linger
    // around the rounded window on some compositors.
    if (message == WM_EXITSIZEMOVE) {
        RedrawWindow(hwnd, nullptr, nullptr,
                     RDW_INVALIDATE | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN |
                         RDW_UPDATENOW);
    }
    // LIQUID_RESIZE: the freshly exposed strip is erased by DefWindowProc with
    // the window-class brush we installed below, so it never shows black.
    // Do NOT fill the whole client here: that would wipe the current GL frame.
    if (message == WM_NCHITTEST) {
        POINT pt{ static_cast<LONG>(static_cast<short>(LOWORD(lParam))),
                  static_cast<LONG>(static_cast<short>(HIWORD(lParam))) };
        ScreenToClient(hwnd, &pt);
        RECT client{};
        GetClientRect(hwnd, &client);
        UINT dpi = 96;
        HMODULE user32 = GetModuleHandleW(L"user32.dll");
        if (user32 != nullptr) {
            using DpiFn = UINT(WINAPI*)(HWND);
            auto getDpi = reinterpret_cast<DpiFn>(
                reinterpret_cast<void*>(GetProcAddress(user32, "GetDpiForWindow")));
            if (getDpi != nullptr) {
                const UINT value = getDpi(hwnd);
                if (value != 0) {
                    dpi = value;
                }
            }
        }
        if (dpi == 96) {
            HDC screenDc = GetDC(nullptr);
            if (screenDc != nullptr) {
                const int caps = GetDeviceCaps(screenDc, LOGPIXELSX);
                if (caps > 0) {
                    dpi = static_cast<UINT>(caps);
                }
                ReleaseDC(nullptr, screenDc);
            }
        }
        const double scale = static_cast<double>(dpi) / 96.0;
        const LONG band = static_cast<LONG>(std::lround(kTitleBarH * scale));
        const LONG buttonsLeft = client.right - static_cast<LONG>(std::lround(152.0 * scale));

        // LIQUID_RESIZE: a frameless window has no system sizing border, so we
        // answer the hit test ourselves. Windows then runs its own resize loop
        // (same smooth path as dragging), and the cursor changes automatically.
        if (IsZoomed(hwnd) == FALSE) {
            const LONG grip = std::max<LONG>(5, static_cast<LONG>(std::lround(7.0 * scale)));
            const bool onLeft = pt.x >= 0 && pt.x < grip;
            const bool onRight = pt.x < client.right && pt.x >= client.right - grip;
            const bool onTop = pt.y >= 0 && pt.y < grip;
            const bool onBottom = pt.y < client.bottom && pt.y >= client.bottom - grip;
            if (onTop && onLeft) {
                return HTTOPLEFT;
            }
            if (onTop && onRight) {
                return HTTOPRIGHT;
            }
            if (onBottom && onLeft) {
                return HTBOTTOMLEFT;
            }
            if (onBottom && onRight) {
                return HTBOTTOMRIGHT;
            }
            if (onTop) {
                return HTTOP;
            }
            if (onBottom) {
                return HTBOTTOM;
            }
            if (onLeft) {
                return HTLEFT;
            }
            if (onRight) {
                return HTRIGHT;
            }
        }

        if (pt.y >= 0 && pt.y < band && pt.x >= 0 && pt.x < buttonsLeft) {
            return HTCAPTION;
        }
        if (gChrome.prevProc != nullptr) {
            return CallWindowProcW(gChrome.prevProc, hwnd, message, wParam, lParam);
        }
        return DefWindowProcW(hwnd, message, wParam, lParam);
    }
    if (gChrome.prevProc != nullptr) {
        return CallWindowProcW(gChrome.prevProc, hwnd, message, wParam, lParam);
    }
    return DefWindowProcW(hwnd, message, wParam, lParam);
}

void setupWindowChrome() {
    if (gChrome.hwnd != nullptr) {
        return;
    }

    struct Finder {
        DWORD pid = 0;
        HWND found = nullptr;
    } finder{ GetCurrentProcessId(), nullptr };
    EnumWindows([](HWND h, LPARAM p) -> BOOL {
        auto* self = reinterpret_cast<Finder*>(p);
        DWORD pid = 0;
        GetWindowThreadProcessId(h, &pid);
        if (pid != self->pid || GetWindow(h, GW_OWNER) != nullptr || !IsWindowVisible(h)) {
            return TRUE;
        }
        self->found = h;
        return FALSE;
    }, reinterpret_cast<LPARAM>(&finder));
    HWND hwnd = finder.found;
    if (hwnd == nullptr) {
        return;
    }

    HMODULE dwm = LoadLibraryW(L"dwmapi.dll");
    if (dwm != nullptr) {
        using SetAttrFn = HRESULT(WINAPI*)(HWND, DWORD, LPCVOID, DWORD);
        auto setAttr = reinterpret_cast<SetAttrFn>(
            reinterpret_cast<void*>(GetProcAddress(dwm, "DwmSetWindowAttribute")));
        if (setAttr != nullptr) {
            HRESULT hrCorner = E_NOTIMPL;
            HRESULT hrBorder = E_NOTIMPL;
            const DWORD kCornerPreference = 33;   // DWMWA_WINDOW_CORNER_PREFERENCE
            const bool win11 = isWindows11();
            gChrome.dwmRound = win11;
            const int round = win11 ? 2 : 1;      // DWMWCP_ROUND / DWMWCP_DONOTROUND
            hrCorner = setAttr(hwnd, kCornerPreference, &round, sizeof(round));
            const DWORD kBorderColor = 34;        // DWMWA_BORDER_COLOR
            const COLORREF none = 0xFFFFFFFE;     // DWMWA_COLOR_NONE
            hrBorder = setAttr(hwnd, kBorderColor, &none, sizeof(none));
            logLine(LOG_INFO, "円角: DwmSetWindowAttribute corner=0x" +
                                        std::to_string(static_cast<unsigned long>(hrCorner)) +
                                        " border=0x" +
                                        std::to_string(static_cast<unsigned long>(hrBorder)) +
                                        " hwnd=" + std::to_string(reinterpret_cast<size_t>(hwnd)) +
                                        (win11 ? " win11=1" : " win11=0"));
        }
        else {
            logLine(LOG_WARN, "円角: dwmapi!DwmSetWindowAttribute 不可用");
        }
    }

    // LIQUID_RESIZE: GLFW's undecorated window is WS_POPUP and has no sizing
    // border, so HTLEFT/HTBOTTOM... would be ignored. Add WS_THICKFRAME and let
    // DWM paint the (invisible) frame - the border colour is set to none above.
    const LONG_PTR style = GetWindowLongPtrW(hwnd, GWL_STYLE);
    if ((style & WS_THICKFRAME) == 0) {
        SetWindowLongPtrW(hwnd, GWL_STYLE, style | WS_THICKFRAME);
        SetWindowPos(hwnd, nullptr, 0, 0, 0, 0,
                     SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE |
                         SWP_FRAMECHANGED);
    }

    {
        const std::string themeName =
            backend::readIni(backend::appIniPath(), "ui", "theme", "light");
        gChrome.bgColor = (themeName == "light") ? RGB(255, 255, 255) : RGB(0, 0, 0);
        if (gChrome.bgBrush != nullptr) {
            DeleteObject(gChrome.bgBrush);
            gChrome.bgBrush = nullptr;
        }
        gChrome.bgBrush = CreateSolidBrush(gChrome.bgColor);
        if (gChrome.bgBrush != nullptr) {
            SetClassLongPtrW(hwnd, GCLP_HBRBACKGROUND,
                             reinterpret_cast<LONG_PTR>(gChrome.bgBrush));
        }
    }

    gChrome.hwnd = hwnd;
    gAppChromeWindow = hwnd;
    gChrome.prevProc = reinterpret_cast<WNDPROC>(
        SetWindowLongPtrW(hwnd, GWLP_WNDPROC, reinterpret_cast<LONG_PTR>(&chromeWindowProc)));

    applyChromeRegion(hwnd);
}

void compose(eui::Ui& ui, const eui::Screen& screen) {
    // 整帧渲染期间独占 AppState：后台监听线程只会在锁外跑 adb，拿锁时间很短，
    // 因此不会拖慢渲染；反过来能彻底避免「渲染到一半 vector 被 realloc」的 AV。
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    AppState& s = state();
    if (!kUseNativeTitlebar) {
        setupWindowChrome();
    }
    s.lastW = screen.width;
    s.lastH = screen.height;

    const float contentX = kNavWidth;
    const float contentW = std::max(0.0f, screen.width - kNavWidth);
    const float bodyH = std::max(0.0f, screen.height - kTitleBarH);
    const float contentH = bodyH;

    ui.stack("root")
        .size(screen.width, screen.height)
        .content([&] {
            ui.rect("root.bg")
                .position(0.0f, 0.0f)
                .size(screen.width, screen.height)
                .color(theme().background)
                .build();

            // 纯色背景：不用渐变、光斑或网格。用户要求整窗只有纯黑/纯白底色，
            // 同时避免半透明背景在拖动窗口时被 DWM 合成为残影。

            
    ui.stack("root.body")
        .position(0.0f, kTitleBarH)
        .size(screen.width, bodyH)
        .content([&] {
    // 侧栏单独一层纯色底：与内容区形成明确的两块背景，再由下面的分界线收口。
    ui.rect("root.nav.bg")
        .position(0.0f, 0.0f)
        .size(kNavWidth, bodyH)
        .color(theme().dark ? eui::Color{0.035f, 0.039f, 0.047f, 1.0f}
                            : eui::Color{0.968f, 0.972f, 0.976f, 1.0f})
        .build();
    // 侧栏与内容区的分界线：两边的底色现在都是纯色，靠这条线做视觉分割。
    ui.rect("root.nav.divider.glow")
        .position(kNavWidth - 2.0f, 0.0f)
        .size(4.0f, bodyH)
        .color(components::theme::withAlpha(theme().text, 0.045f))
        .build();
    ui.rect("root.nav.divider")
        .position(kNavWidth - 0.5f, 0.0f)
        .size(1.0f, bodyH)
        .color(components::theme::withAlpha(theme().text, 0.16f))
        .build();
    composeNavigation(ui, kNavWidth, bodyH);
            composeThemeSwitch(ui, kNavWidth, bodyH);
            composeSidebarDevice(ui, kNavWidth, bodyH);

            switch (s.page) {
                case Page::Home:     composeHome(ui, contentX, 0.0f, contentW, contentH); break;
            case Page::Tool:     composeTool(ui, contentX, 0.0f, contentW, contentH); break;
                case Page::Managers: composeManagers(ui, contentX, 0.0f, contentW, contentH); break;
                case Page::Mirror:   composeMirror(ui, contentX, 0.0f, contentW, contentH); break;
                case Page::About:    composeAbout(ui, contentX, 0.0f, contentW, contentH); break;
            }

            // 页面标题的统一标记：左侧竖向主题色条 + 标题下的细分隔线。
            // 参考 PyQt-SiliconUI 的 GroupTitle，但保留项目原来的背景与排版。
            if (!(s.page == Page::Managers && s.logExpanded)) {
                ui_title_accent(ui, "page.title.accent", contentX + 16.0f, 29.0f, 18.0f);
                ui_divider(ui, "page.header.rule", contentX + 32.0f, 88.0f,
                           std::max(0.0f, contentW - 64.0f), true);
            }

            composeFooter(ui, contentX + kPad, bodyH - 26.0f, contentW - kPad * 2.0f);
                })
                .build();

            if (!kUseNativeTitlebar) {
                composeTitleBar(ui, screen);
            }
        })
        .build();

    composeDialogLayer(ui, screen);
}

} // namespace app
