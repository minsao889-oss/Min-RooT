#pragma once
// 网络下载：APK 直链下载 + GitHub release 资产解析。
//
// 统一走 WinHTTP（不用 URLDownloadToFileW），原因：
//  1) URLDownloadToFile 走 IE/WinINet 的代理栈，很多机器上拿不到系统代理，直连 GitHub 直接
//     返回 HRESULT 0x800C0005 (INET_E_CANNOT_CONNECT)，且拿不到具体原因；
//  2) WinHTTP 的 WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY 会读取系统 WinHTTP 代理，还能自己配回退。
#include <functional>
#include <string>

namespace backend {

// 下载进度回调：已下载字节 / 总字节（总字节未知时为 0）。
using DownloadProgress = std::function<void(unsigned long long, unsigned long long)>;

// 下载 urlUtf8 到 destPathUtf8。
// autoMirror=true 时，若直连失败会自动把 github.com 换成国内镜像重试一遍。
bool downloadToFile(const std::string& urlUtf8, const std::string& destPathUtf8,
                    const DownloadProgress& progress, std::string& err);

// 请求 GitHub release API，返回第一个匹配 pattern 的 .apk 资产直链。
// 直连 api.github.com 失败时会自动换镜像重试。
bool fetchReleaseApkUrl(const std::string& apiUrl, const std::string& pattern, std::string& out,
                        std::string& err);

// 镜像档位的人话名字，报错时拼进原因里（"直连" / "gh-proxy" / "ghfast" / "ghproxy.net"）。
const char* mirrorLabel(int mirrorIndex);

// 一次拿到 release 的 tag 名 + 匹配 pattern 的 APK 直链（检查更新用）。
// 与 fetchReleaseApkUrl 的区别：tag 也一起取，少跑一遍网络；tag 缺失不算失败。
bool fetchLatestReleaseInfo(const std::string& apiUrl, const std::string& pattern,
                            std::string& tag, std::string& apkUrl, std::string& err);

// 把 github.com / api.github.com 之类的 URL 换到镜像站。mirror 为空表示直连。
std::string mirrorUrl(const std::string& url, int mirrorIndex);

// 诊断用：返回当前系统的 WinHTTP 代理配置（无代理时为空串）。
std::string systemProxySummary();

} // namespace backend
