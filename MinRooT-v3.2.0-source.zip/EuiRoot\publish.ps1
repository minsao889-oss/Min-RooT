﻿<#
    publish.ps1 — 把 EuiRoot 发布到 GitHub（仓库 + Release）

    用法（在 PowerShell 里，进入这个目录后）：
        powershell -NoProfile -ExecutionPolicy Bypass -File .\publish.ps1
        powershell -NoProfile -ExecutionPolicy Bypass -File .\publish.ps1 -Public
        powershell -NoProfile -ExecutionPolicy Bypass -File .\publish.ps1 -RepoName MyName -SkipRelease

    第一次运行会：
      1) 检查 git / gh 是否可用（没装会提示 winget 命令）
      2) 如果 gh 未登录，自动走浏览器登录（`gh auth login --web`），按屏幕提示在浏览器里点授权
      3) 创建仓库并推送 main
      4) 打 tag v3.4.0 并上传发布包 zip

    默认仓库是 Private（提权类工具，建议先私有）。确认没问题后再 `gh repo edit --visibility public`。
#>
param(
    [string]$RepoName = "SiliconRootTool",
    [switch]$Public,
    [string]$Tag = "v3.4.0",
    [string]$ZipPath = "D:\下载\新建文件夹\SiliconRootTool-v3.4.0.zip",
    [string]$ReleaseTitle = "SiliconRootTool v3.4.0",
    [switch]$SkipRelease
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# ---- 0. 让本会话能找到 git / gh ----
$candidates = @(
    "$env:ProgramFiles\Git\cmd",
    "$env:ProgramFiles\GitHub CLI",
    "$env:LOCALAPPDATA\Programs\GitHub CLI",
    "${env:ProgramFiles(x86)}\Git\cmd"
)
foreach ($c in $candidates) {
    if ((Test-Path $c) -and ($env:PATH -notlike "*$c*")) { $env:PATH = "$c;$env:PATH" }
}

function Need($name, $hint) {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if (-not $cmd) {
        Write-Host "[X] 找不到 $name" -ForegroundColor Red
        Write-Host "    请先安装：$hint" -ForegroundColor Yellow
        exit 1
    }
    return $cmd.Source
}

$git = Need "git" "winget install --id Git.Git -e"
$gh  = Need "gh"  "winget install --id GitHub.cli -e"
Write-Host "[OK] git = $git"
Write-Host "[OK] gh  = $gh"

Set-Location -Path $PSScriptRoot

# ---- 1. gh 登录 ----
& $gh auth status 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "需要登录 GitHub（会打开浏览器，复制屏幕上的 8 位码粘贴进去即可）：" -ForegroundColor Cyan
    & $gh auth login --hostname github.com --git-protocol https --web
    if ($LASTEXITCODE -ne 0) { Write-Host "[X] 登录失败" -ForegroundColor Red; exit 1 }
}
$owner = (& $gh api user --jq .login).Trim()
Write-Host "[OK] 已登录：$owner"

# ---- 2. 本地仓库确认 ----
if (-not (Test-Path ".git")) {
    Write-Host "[..] 初始化 git 仓库"
    & $git init -b main | Out-Null
}
& $git add -A
$pending = (& $git status --porcelain | Measure-Object -Line).Lines
if ($pending -gt 0) {
    Write-Host "[..] 提交 $pending 个变更"
    & $git commit -m "chore: publish $Tag" | Out-Null
}
Write-Host "[OK] 本地提交：$(& $git rev-parse --short HEAD)"

# ---- 3. 建仓库 / 推送 ----
$visibility = if ($Public) { "--public" } else { "--private" }
$hasRemote = $false
try { & $git remote get-url origin 2>$null | Out-Null; $hasRemote = ($LASTEXITCODE -eq 0) } catch { }

if (-not $hasRemote) {
    Write-Host "[..] 创建仓库 $owner/$RepoName ($visibility)"
    & $gh repo create "$RepoName" $visibility --source . --remote origin 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[!] 远端仓库可能已存在，尝试直接绑定"
        & $git remote add origin "https://github.com/$owner/$RepoName.git"
    }
}
Write-Host "[..] 推送 main"
& $git push -u origin main
if ($LASTEXITCODE -ne 0) { Write-Host "[X] 推送失败（检查网络/代理/权限）" -ForegroundColor Red; exit 1 }
$repoUrl = "https://github.com/$owner/$RepoName"
Write-Host "[OK] 仓库：$repoUrl" -ForegroundColor Green

# ---- 4. Release ----
if (-not $SkipRelease) {
    if (-not (Test-Path $ZipPath)) {
        Write-Host "[!] 找不到发布包：$ZipPath（跳过 Release）" -ForegroundColor Yellow
    }
    else {
        & $gh release view $Tag --repo "$owner/$RepoName" 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "[i] Release $Tag 已存在，改为上传/覆盖附件"
            & $gh release upload $Tag $ZipPath --clobber --repo "$owner/$RepoName"
        }
        else {
            $notes = @"
## 本次更新
- 液态玻璃 (Liquid Glass) UI：胶囊按钮 / 磨砂卡片 / 弹簧按压（k=300, ζ=0.5）
- 运行方式切换条：整条命中、点哪跳哪、可拖动、指示块弹簧滑动
- 无边框窗口：自绘标题栏（最小化 / 最大化 / 关闭）、整窗拖动、四边四角自由拉伸
- 圆角：Windows 11 走 DWM 抗锯齿圆角，Windows 10 走区域裁剪
- 背景：程序化渐变 + 三处光斑（零素材），深浅主题可切换
- 新增作者头像 / 名字配置（`author.ini`，改完重启生效）

## 系统要求
- Windows 10 / 11（64 位），显卡驱动支持 OpenGL 3.3
- 解压即用，不需要装运行库
"@
            Write-Host "[..] 创建 Release $Tag 并上传 $(Split-Path $ZipPath -Leaf)"
            & $gh release create $Tag $ZipPath --repo "$owner/$RepoName" --title $ReleaseTitle --notes $notes
        }
        if ($LASTEXITCODE -eq 0) {
            Write-Host "[OK] 发布页：$repoUrl/releases/tag/$Tag" -ForegroundColor Green
        }
    }
}

Write-Host ""
Write-Host "完成。下一步可以：" -ForegroundColor Cyan
Write-Host "  看仓库   $repoUrl"
Write-Host "  查看状态 git -C `"$PSScriptRoot`" log --oneline -3"
Write-Host "  改可见性 gh repo edit --visibility public   （确认无误后再公开）"
