#include "backend/assets.h"
#include "backend/managers.h"

#include "backend/bundle.h"
#include "backend/download.h"
#include "backend/process.h"

#include <windows.h>
#include <shlobj.h>

#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <sstream>
#include <string>
#include <vector>

namespace backend {
namespace {

std::string g_rootCache;

std::string trim(const std::string& in) {
    size_t a = 0;
    size_t b = in.size();
    while (a < b && (in[a] == ' ' || in[a] == '\r' || in[a] == '\n' || in[a] == '\t')) ++a;
    while (b > a && (in[b - 1] == ' ' || in[b - 1] == '\r' || in[b - 1] == '\n' || in[b - 1] == '\t')) --b;
    return in.substr(a, b - a);
}

std::string quote(const std::string& value) {
    return "\"" + value + "\"";
}

std::string runAdb(const std::string& serial, const std::string& args, int timeoutMs = 20000) {
    std::wstring cmd = widen(quote(adbPath())) + L" ";
    if (!serial.empty()) cmd += L"-s " + widen(serial) + L" ";
    cmd += widen(args);
    ProcessResult r = run(cmd, static_cast<unsigned int>(timeoutMs), true);
    return trim(r.out);
}

// "https://github.com/owner/repo" → "owner/repo"
std::string repoPath(const std::string& github) {
    const std::string prefix = "https://github.com/";
    std::string rest = github;
    if (rest.rfind(prefix, 0) == 0) rest = rest.substr(prefix.size());
    while (!rest.empty() && rest.back() == '/') rest.pop_back();
    return rest;
}

} // namespace

const char* stateLabel(InstallState state) {
    switch (state) {
        case InstallState::NotInstalled: return "未安装";
        case InstallState::Installing:   return "安装中";
        case InstallState::Installed:    return "已安装";
        case InstallState::Failed:       return "安装失败";
        default:                         return "未检测";
    }
}

const char* stateKey(InstallState state) {
    switch (state) {
        case InstallState::NotInstalled: return "not";
        case InstallState::Installing:   return "ing";
        case InstallState::Installed:    return "ok";
        case InstallState::Failed:       return "fail";
        default:                         return "unknown";
    }
}

const std::vector<ManagerInfo>& managers() {
    // 说明：v3.x 之后 release 资产名带构建号后缀（如 KernelSU_v3.3.1_32680-release.apk），
    // 固定的 releases/latest/download/<name> 直链会 404，所以这里留空走 API 资产匹配。
    // 只有 7kimi 的资产名是稳定的，直接给直链。
    static const std::vector<ManagerInfo> list = {
        {"kernelsu",
         "KernelSU",
         "KernelSU 官方分支，基于内核的 Android root 方案，稳定、上游维护。",
         "me.weishu.kernelsu",
         "v3.3.1-29-gab05a062",
         "KernelSU_v3.3.1-29-gab05a062_32709-release(1).apk",
         "APK",
         "https://github.com/tiann/KernelSU",
         "https://github.com/tiann/KernelSU",
         "",
         "",
         "KernelSU_v3",
         {"me.weishu.kernelsu.pr"}, "weishu"},
        {"kernelsu_next",
         "KernelSU Next",
         "KernelSU 社区分支，内置更多模块管理与 App Profile 增强。",
         "com.rifsxd.ksunext",
         "v3.4.2",
         "KernelSU-Next_v3.4.2.apk",
         "APK",
         "https://github.com/KernelSU-Next/KernelSU-Next",
         "https://github.com/KernelSU-Next/KernelSU-Next",
         "",
         "",
         "KernelSU_Next_v",
         {"com.rifsxd.ksunext.debug"}, "ksunext"},
        {"sukisu",
         "SukiSU",
         "SukiSU Ultra，支持非 GKI 内核与 late-load，兼容性最强的分支。",
         "com.sukisu.ultra",
         "v4.3.0",
         "SukiSU_v4.3.0_41100-release.apk",
         "APK",
         "https://github.com/SukiSU-Ultra/SukiSU-Ultra",
         "https://github.com/SukiSU-Ultra/SukiSU-Ultra",
         "",
         "",
         "SukiSU_v",
         {"com.resukisu.resukisu"}, "sukisu"},
        {"7kimisu",
         "7kimi SU",
         "7kimi 维护的轻量分支，界面精简、资源占用低。",
         "com.sevenk.core",
         "v2.30",
         "7kimisu-v2.30.apk",
         "APK",
         "https://github.com/hartgerinktarcila-design/7kimisu",
         "https://github.com/hartgerinktarcila-design/7kimisu",
         "",
         "https://github.com/hartgerinktarcila-design/7kimisu/releases/download/v2.30/7kimisu-v2.30.apk",
         "7kimisu-v",
         {"com.7kimi.su", "com.sevenk.manager"}, "sevenk"},
    };
    return list;
}

const ManagerInfo* findManager(const std::string& key) {
    for (const auto& item : managers()) {
        if (item.key == key) return &item;
    }
    return nullptr;
}

std::string resourceRoot() {
    if (!g_rootCache.empty()) return g_rootCache;
    // ensureBundle() 内部处理三种情形：exe 同级 assets / 上级 assets / 从资源段解压到临时目录
    const std::wstring resolved = ensureBundle();
    g_rootCache = narrow(resolved);
    return g_rootCache;
}

std::string adbPath() {
    // 优先用包内 adb（加密形态会解密落盘），其次系统 adb，最后 PATH
    const std::string bundled = assets::pathForExternal("roottool/adb.exe");
    if (!bundled.empty() &&
        GetFileAttributesW(widen(bundled).c_str()) != INVALID_FILE_ATTRIBUTES) return bundled;
    const std::string local = resourceRoot() + "\\roottool\\adb.exe";
    if (GetFileAttributesW(widen(local).c_str()) != INVALID_FILE_ATTRIBUTES) return local;
    const std::string systemAdb = "C:\\adb\\platform-tools\\adb.exe";
    if (GetFileAttributesW(widen(systemAdb).c_str()) != INVALID_FILE_ATTRIBUTES) return systemAdb;
    return "adb.exe";
}

std::string apkPath(const ManagerInfo& info) {
    const std::string p = assets::pathForExternal(std::string("apk/") + info.apkFile);
    if (!p.empty()) return p;
    return resourceRoot() + "\\apk\\" + info.apkFile;
}

std::string downloadDir() {
    wchar_t* local = nullptr;
    std::wstring base;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_LocalAppData, 0, nullptr, &local)) && local) {
        base = local;
        CoTaskMemFree(local);
    } else {
        wchar_t buffer[MAX_PATH];
        const DWORD len = GetTempPathW(MAX_PATH, buffer);
        base = len > 0 ? std::wstring(buffer, len) : L".";
    }
    const std::wstring dir = base + L"\\SiliconRootTool\\apk";
    CreateDirectoryW((base + L"\\SiliconRootTool").c_str(), nullptr);
    CreateDirectoryW(dir.c_str(), nullptr);
    return narrow(dir);
}

bool hasLocalApk(const ManagerInfo& info) {
    return GetFileAttributesW(widen(apkPath(info)).c_str()) != INVALID_FILE_ATTRIBUTES;
}

std::string resolveApk(const ManagerInfo& info, bool* isLocal) {
    if (hasLocalApk(info)) {
        if (isLocal) *isLocal = true;
        return apkPath(info);
    }
    const std::string cached = downloadDir() + "\\" + info.apkFile;
    if (GetFileAttributesW(widen(cached).c_str()) != INVALID_FILE_ATTRIBUTES) {
        if (isLocal) *isLocal = false;
        return cached;
    }
    if (isLocal) *isLocal = false;
    return std::string();
}

bool downloadApk(const ManagerInfo& info, std::string& log,
                 const std::function<void(unsigned long long, unsigned long long)>& progress) {
    const std::string dest = downloadDir() + "\\" + info.apkFile;
    std::string directErr;   // 直链通道的错误
    std::string apiErr;      // GitHub API 通道的错误

    // 通道一：配置了直链就试直链
    if (!info.downloadUrl.empty()) {
        log = "正在下载 " + info.name + "（直链）…";
        if (downloadToFile(info.downloadUrl, dest, progress, directErr)) {
            log = "下载完成：" + dest;
            return true;
        }
    }

    // 通道二：查 GitHub release API 挑匹配的 APK 资产。
    // 注意：v3.x 之后资产名带构建号后缀，直链基本都会 404，所以这条是主通道而不是兜底。
    if (!info.github.empty()) {
        const std::string api = "https://api.github.com/repos/" + repoPath(info.github) +
                                "/releases/latest";
        std::string found;
        if (fetchReleaseApkUrl(api, info.assetPattern, found, apiErr)) {
            log = "改用 release 资产：" + found;
            if (downloadToFile(found, dest, progress, directErr)) {
                log = "下载完成：" + dest;
                return true;
            }
        }
    } else {
        apiErr = "未配置 GitHub 仓库";
    }

    // 两条通道都失败：把各自的原因都带上，方便排查
    std::string reasons;
    if (!directErr.empty()) reasons += directErr;
    if (!apiErr.empty()) reasons += (reasons.empty() ? "" : "；") + apiErr;
    if (reasons.empty()) reasons = "未知原因";

    log = "下载失败：" + reasons + "\n可在「打开下载页」手动下载后放到 " + downloadDir();
    return false;
}

DeviceInfo detectDevice() {
    DeviceInfo info;
    const std::wstring cmd = widen(quote(adbPath())) + L" devices";
    ProcessResult r = run(cmd, 8000, true);
    if (!r.started) {
        info.message = "找不到 adb，请确认程序目录下的加密资源包 SiliconRootTool.dat 完整";
        return info;
    }
    std::string serial;
    size_t pos = 0;
    while (pos < r.out.size()) {
        const size_t eol = r.out.find('\n', pos);
        const std::string line = trim(r.out.substr(pos, eol == std::string::npos ? std::string::npos : eol - pos));
        pos = (eol == std::string::npos) ? r.out.size() : eol + 1;
        if (line.empty() || line.rfind("List of devices", 0) == 0 || line.rfind("*", 0) == 0) continue;
        const size_t tab = line.find('\t');
        const std::string left = trim(tab == std::string::npos ? line : line.substr(0, tab));
        const std::string state = trim(tab == std::string::npos ? std::string() : line.substr(tab + 1));
        if (state == "device") {
            serial = left;
            break;
        }
    }
    if (serial.empty()) {
        info.message = "未检测到已授权的 Android 设备";
        return info;
    }
    info.ready = true;
    info.serial = serial;
    info.model = runAdb(serial, "shell getprop ro.product.model");
    info.android = runAdb(serial, "shell getprop ro.build.version.release");
    info.kernel = runAdb(serial, "shell uname -r");
    info.message = serial + " · " + info.model + " · Android " + info.android;
    return info;
}

// 所有处于 device 状态（已授权）的序列号，主页的设备下拉用它。
std::vector<std::string> listDeviceSerials() {
    std::vector<std::string> out;
    ProcessResult r = run(widen(quote(adbPath())) + L" devices", 8000, true);
    if (!r.started) return out;
    size_t pos = 0;
    while (pos < r.out.size()) {
        const size_t eol = r.out.find('\n', pos);
        const std::string line = trim(r.out.substr(pos, eol == std::string::npos ? std::string::npos : eol - pos));
        pos = (eol == std::string::npos) ? r.out.size() : eol + 1;
        if (line.empty() || line.rfind("List of devices", 0) == 0 || line.rfind("*", 0) == 0) continue;
        const size_t tab = line.find('\t');
        if (tab == std::string::npos) continue;
        const std::string serial = trim(line.substr(0, tab));
        const std::string state = trim(line.substr(tab + 1));
        if (state.rfind("device", 0) == 0 && !serial.empty()) out.push_back(serial);
    }
    return out;
}

CheckResult checkManager(const ManagerInfo& info, const std::string& serial) {
    CheckResult result;
    result.package = info.package;
    if (serial.empty()) {
        result.state = InstallState::NotInstalled;
        result.message = "无设备连接，无法确认安装状态";
        return result;
    }
    result.deviceReady = true;

    // 候选包名：主包名 + 别名（历史版本 / 社区改包）
    std::vector<std::string> candidates{info.package};
    for (const auto& alias : info.aliases) candidates.push_back(alias);

    // 1) 找出设备上实际存在的那个包
    std::string matched;
    for (const auto& pkg : candidates) {
        const std::string listed = runAdb(serial, "shell pm list packages " + pkg);
        if (listed.find("package:" + pkg) != std::string::npos) {
            matched = pkg;
            break;
        }
    }
    if (matched.empty() && !info.searchHint.empty()) {
        // 兜底：遍历设备全部包名，找包含关键词的包（应对改包名 / 自定义构建）
        const std::string all = runAdb(serial, "shell pm list packages");
        std::size_t pos = 0;
        while (pos < all.size()) {
            const std::size_t eol = all.find('\n', pos);
            std::string line = all.substr(pos, eol == std::string::npos ? std::string::npos : eol - pos);
            pos = (eol == std::string::npos) ? all.size() : eol + 1;
            line = trim(line);
            const std::size_t colon = line.find("package:");
            if (colon == std::string::npos) continue;
            const std::string pkg = line.substr(colon + 8);
            if (pkg.find(info.searchHint) != std::string::npos) {
                matched = pkg;
                break;
            }
        }
    }

    if (matched.empty()) {
        result.state = InstallState::NotInstalled;
        result.message = "设备上未找到包 " + info.package;
        if (!info.aliases.empty()) {
            result.message += "（也查了 ";
            for (std::size_t i = 0; i < info.aliases.size(); ++i) {
                if (i) result.message += " / ";
                result.message += info.aliases[i];
            }
            result.message += "）";
        }
        return result;
    }
    result.package = matched;

    // 2) 取版本号
    const std::string dump = runAdb(serial, "shell dumpsys package " + matched + " | grep versionName");
    const size_t eq = dump.find("versionName=");
    if (eq != std::string::npos) {
        std::string value = dump.substr(eq + 12);
        const size_t end = value.find_first_of("\r\n ");
        if (end != std::string::npos) value.resize(end);
        result.version = trim(value);
    }

    // 3) 进程是否在跑（辅助判断，缺进程也算已安装）
    const std::string ps = runAdb(serial, "shell ps -A | grep " + matched);
    result.state = InstallState::Installed;
    result.message = "已安装" + (result.version.empty() ? "" : " · " + result.version);
    if (matched != info.package) result.message += "（包名 " + matched + "）";
    if (ps.empty()) result.message += "（进程未运行）";
    return result;
}

bool installManagerFromFile(const ManagerInfo& info, const std::string& serial,
                            const std::string& path, std::string& log) {
    WIN32_FILE_ATTRIBUTE_DATA fad{};
    if (!GetFileAttributesExW(widen(path).c_str(), GetFileExInfoStandard, &fad) ||
        (fad.nFileSizeHigh == 0 && fad.nFileSizeLow == 0)) {
        log = "安装包不存在或为空：" + path;
        return false;
    }
    log = "正在安装（已下载包） " + info.name + " …";
    const std::string out = runAdb(serial, "install -r -d " + quote(path), 300000);
    log = out;
    return out.find("Success") != std::string::npos;
}

bool installManager(const ManagerInfo& info, const std::string& serial, std::string& log) {
    bool isLocal = true;
    std::string path = resolveApk(info, &isLocal);
    if (path.empty()) {
        log = "内置安装包缺失，转为在线下载 " + info.name + " …";
        if (!downloadApk(info, log, nullptr)) return false;
        path = resolveApk(info, &isLocal);
        if (path.empty()) {
            log += "\n下载后仍找不到安装包，已中止";
            return false;
        }
    }
    log = std::string(isLocal ? "正在安装（内置包）" : "正在安装（已下载包）") + " " +
          info.name + " …";
    const std::string out = runAdb(serial, "install -r -d " + quote(path), 300000);
    log = out;
    return out.find("Success") != std::string::npos;
}

bool uninstallManager(const ManagerInfo& info, const std::string& serial, std::string& log) {
    const std::string out = runAdb(serial, "uninstall " + info.package, 120000);
    log = out;
    return out.find("Success") != std::string::npos;
}

bool launchManager(const ManagerInfo& info, const std::string& serial, std::string& log) {
    const std::string out = runAdb(serial,
        "shell monkey -p " + info.package + " -c android.intent.category.LAUNCHER 1", 20000);
    log = out;
    return out.find("No activities found") == std::string::npos;
}

bool leaveGroup(const std::string& serial, std::string& log) {
    std::string acc;
    acc += runAdb(serial, "shell pkill -f gl-run.sh", 10000) + "\n";
    acc += runAdb(serial, "shell pkill -f ghostlock", 10000) + "\n";
    for (const auto& item : managers()) {
        acc += runAdb(serial, "shell am force-stop " + item.package, 10000) + "\n";
        for (const auto& alias : item.aliases) {
            acc += runAdb(serial, "shell am force-stop " + alias, 10000) + "\n";
        }
    }
    log = acc.empty() ? "已停止看门狗并结束管理器进程" : acc;
    return true;
}

bool adbRestartServer(std::string& log) {
    // kill-server 之后 start-server 会重新走一遍 USB 握手，
    // 手机端如果还没信任本机指纹就会弹「允许 USB 调试吗」。
    runAdb(std::string(), "kill-server", 10000);
    Sleep(400);
    const std::string out = runAdb(std::string(), "start-server", 20000);
    Sleep(300);
    log = out.empty() ? "adb 服务已重启" : out;
    return true;
}

// ---- 检查更新（v3.1）----
namespace {

// 把 tag 里那些「不是版本号」的前后缀剥掉：v / V 前缀、-release / _32680 之类的构建后缀。
std::string cleanVersion(const std::string& raw) {
    std::string s = trim(raw);
    if (!s.empty() && (s[0] == 'v' || s[0] == 'V')) s.erase(0, 1);
    // 只保留数字与点，遇到第一个非 [0-9.] 就截断：
    //   "3.3.1-32680-release" → "3.3.1"，"2.30" → "2.30"
    std::string out;
    for (char ch : s) {
        if ((ch >= '0' && ch <= '9') || ch == '.') {
            out.push_back(ch);
        } else {
            break;
        }
    }
    return out;
}

} // namespace

std::vector<int> parseVersion(const std::string& raw) {
    std::vector<int> parts;
    const std::string s = cleanVersion(raw);
    std::size_t pos = 0;
    while (pos < s.size()) {
        const std::size_t dot = s.find('.', pos);
        const std::string seg = s.substr(pos, dot == std::string::npos ? std::string::npos : dot - pos);
        if (!seg.empty()) {
            // 只累加，不吃 strtol 的符号/前导空白；超长段直接截断避免溢出
            long long value = 0;
            bool any = false;
            for (char ch : seg) {
                if (ch < '0' || ch > '9') break;
                any = true;
                if (value > 1000000) continue;
                value = value * 10 + (ch - '0');
            }
            parts.push_back(any ? static_cast<int>(value) : 0);
        }
        if (dot == std::string::npos) break;
        pos = dot + 1;
    }
    return parts;
}

bool versionNewer(const std::string& a, const std::string& b) {
    const std::vector<int> va = parseVersion(a);
    const std::vector<int> vb = parseVersion(b);
    if (va.empty() || vb.empty()) {
        // 解析不出来的时候只能退化：两个串都不一样就当有更新，
        // 至少能让用户看到「版本可能不同」，而不是静默当作最新。
        const std::string ca = cleanVersion(a);
        const std::string cb = cleanVersion(b);
        if (ca.empty() || cb.empty()) return false;
        return ca != cb;
    }
    const std::size_t n = std::max(va.size(), vb.size());
    for (std::size_t i = 0; i < n; ++i) {
        const int x = i < va.size() ? va[i] : 0;
        const int y = i < vb.size() ? vb[i] : 0;
        if (x != y) return x > y;
    }
    return false;
}

bool fetchLatestRelease(const ManagerInfo& info, std::string& tag, std::string& apkUrl,
                        std::string& err) {
    if (info.github.empty()) {
        err = "未配置 GitHub 仓库";
        return false;
    }
    const std::string api =
        "https://api.github.com/repos/" + repoPath(info.github) + "/releases/latest";
    std::string stepErr;
    if (!fetchLatestReleaseInfo(api, info.assetPattern, tag, apkUrl, stepErr)) {
        err = stepErr.empty() ? "查询 release 失败" : stepErr;
        tag.clear();
        return false;
    }
    tag = cleanVersion(tag);
    return true;
}


bool adbReboot(const std::string& serial, std::string& log) {
    if (serial.empty()) {
        log = "设备未连接，无法重启";
        return false;
    }
    const std::string out = runAdb(serial, "reboot", 20000);
    log = out.empty() ? "已向设备发送 reboot" : out;
    return true;
}

RootStatus probeRoot(const std::string& serial) {
    RootStatus status;
    if (serial.empty()) {
        status.detail = "未连接设备";
        return status;
    }
    const std::string out = runAdb(serial, "shell su -c id", 8000);
    const std::size_t nl = out.find('\n');
    const std::string first = nl == std::string::npos ? out : out.substr(0, nl);
    if (out.find("uid=0") != std::string::npos) {
        status.active = true;
        status.detail = first.empty() ? std::string("uid=0(root)") : first;
    } else if (out.find("not found") != std::string::npos ||
               out.find("No such file") != std::string::npos) {
        status.detail = "设备上没有 su，尚未提权";
    } else if (first.empty()) {
        status.detail = "su 无输出，尚未提权";
    } else {
        status.detail = first;
    }
    return status;
}

bool rootToolPreflight(std::string& log) {
    const std::string script = assets::pathForExternal("roottool/Neo10-Root.ps1");
    if (GetFileAttributesW(widen(script).c_str()) == INVALID_FILE_ATTRIBUTES) {
        log = "提权脚本缺失：" + script;
        return false;
    }
    log = "提权工具就绪：" + script;
    return true;
}

std::string rootToolCommand(const std::string& mode, const std::string& serial,
                            const std::string& managerPkg) {
    const std::string script = assets::pathForExternal("roottool/Neo10-Root.ps1");
    // 原版 Neo10-Root.bat 是「有 pwsh 用 pwsh，没有才退回 Windows PowerShell 5.1」。
    // 5.1 处理中文/UTF-8 和大量字符串拼接都更慢，跑同一个脚本耗时明显更长，
    // 所以这里跟原版保持一致，不要硬写 powershell.exe。
    std::string shell = "powershell.exe";
    {
        wchar_t found[MAX_PATH] = {};
        if (SearchPathW(nullptr, L"pwsh.exe", nullptr, MAX_PATH, found, nullptr) > 0) {
            shell = "\"" + narrow(std::wstring(found)) + "\"";
        } else {
            wchar_t pf[MAX_PATH] = {};
            if (GetEnvironmentVariableW(L"ProgramFiles", pf, MAX_PATH) > 0) {
                const std::wstring cand = std::wstring(pf) + L"\\PowerShell\\7\\pwsh.exe";
                if (GetFileAttributesW(cand.c_str()) != INVALID_FILE_ATTRIBUTES) {
                    shell = "\"" + narrow(cand) + "\"";
                }
            }
        }
    }
    // 编码兜底：Windows PowerShell 5.1 解析 .ps1 时，文件**没有 BOM** 就按系统 ANSI
    // 代码页（中文机器是 936/GBK）解码，UTF-8 的中文注释会整片读成乱码，
    // 连引号一起吃掉 —— 报的错就是「字符串缺少终止符」「表达式或语句中包含意外的标记」，
    // 脚本连第一行都跑不过去（run-20261021-135127.log 就是这个）。
    // 脚本本体已强制存成 UTF-8 with BOM，这里再显式声明一次，双保险。
    // -InputFormat Text：管道输入按文本行处理，不按 CLIXML。
    std::string cmd = shell + " -NoProfile -NoLogo -InputFormat Text -ExecutionPolicy Bypass"
                           " -Command \"[Console]::OutputEncoding=[System.Text.Encoding]::UTF8"
                           "; $OutputEncoding=[System.Text.Encoding]::UTF8"
                           "; & " + quote(script);
    cmd += " -Mode " + (mode.empty() ? std::string("Refire") : mode);
    cmd += " -Profile auto -NoPause";
    if (mode == "Interactive") {
        // 关键：脚本的 switch($Mode) 只认 Cold / Refire / Status，
        // 「Interactive」落到 default 分支，而 -NoPause 会让 default 自动按 [1]（开飞行模式并重启）。
        // 所以「不重启直接打」必须显式带 -NoAutoReboot，否则等于偷偷选了模式 1。
        // Neo10-Root.ps1:1268  if ($NoAutoReboot) { $doReboot = $false }
        // Neo10-Root.ps1:1320 $rebootThis = ... -and -not $NoAutoReboot
        cmd += " -NoAutoReboot";
    }
    if (!serial.empty()) cmd += " -Serial " + serial;
    // 把界面上选中的管理器传给脚本 -> gl-run.sh -> ksud-launcher.sh（经 mgr.pkg）。
    // 不传的话，设备端会按内置优先级挑（com.sukisu.ultra 优先），
    // 结果就是「界面上选的是 7kimi，实际激活的却是 SukiSU」。
    if (!managerPkg.empty()) cmd += " -ManagerPkg " + managerPkg;
    // 闭合上面 -Command 的引号（-Command 后面所有参数都会被当成脚本代码，
    // 所以脚本参数必须放在 & 调用这一行里，用引号包住整个命令行）。
    cmd += "\"";
    return cmd;
}

int killStaleRootTool(std::string& log) {
    // Neo10-Root.ps1 用 logs\driver.lock 的独占句柄做单实例锁；
    // 上一次的窗口没关干净（比如点了执行提权后直接关掉本程序），
    // 下一次启动会被判定「已经有一个本工具在跑了」并以退出码 1 直接退出。
    // 这里先把残留的脚本进程结束掉，锁句柄随进程退出自动释放。
    // 注意：必须把自己这个查询进程、以及命令行里只是「提到」脚本名的进程排除掉，
    // 否则会把当前 powershell 查询自身（甚至宿主程序）一起杀掉。
    const std::wstring ps = L"powershell.exe -NoProfile -NoLogo -NonInteractive -ExecutionPolicy Bypass "
        L"-Command "
        L"\"$self = $PID; "
        L"$p = Get-CimInstance Win32_Process | Where-Object { "
        L"$_.ProcessId -ne $self -and $_.CommandLine -ne $null -and "
        L"($_.Name -eq 'powershell.exe' -or $_.Name -eq 'pwsh.exe' -or $_.Name -eq 'cmd.exe') -and "
        L"$_.CommandLine -like '*Neo10-Root.ps1*' -and "
        L"$_.CommandLine -notlike '*Get-CimInstance*' -and "
        L"$_.CommandLine -notlike '*Stop-Process*' }; "
        L"if ($p) { foreach ($x in $p) { try { Stop-Process -Id $x.ProcessId -Force -ErrorAction Stop; "
        L"Write-Output ('killed ' + $x.ProcessId) } catch { } } } else { Write-Output 'none' }\"";

    ProcessResult r = run(ps, 20000, true);
    if (!r.started) {
        log = "无法查询残留实例：" + r.error;
        return -1;
    }
    int count = 0;
    std::string detail;
    size_t pos = 0;
    while (pos < r.out.size()) {
        const size_t eol = r.out.find('\n', pos);
        std::string line = r.out.substr(pos, eol == std::string::npos ? std::string::npos : eol - pos);
        pos = (eol == std::string::npos) ? r.out.size() : eol + 1;
        line = trim(line);
        if (line.rfind("killed ", 0) == 0) {
            ++count;
            if (!detail.empty()) detail += " / ";
            detail += line.substr(7);
        }
    }
    if (count == 0) {
        log = "没有残留实例";
    } else {
        log = "已结束 " + std::to_string(count) + " 个残留实例（PID " + detail + "），单实例锁随之释放";
    }
    return count;
}

// ============================================================ 主页设备详表
// 一次 adb shell 把一个脚本跑完，回传 KEY=VALUE 行。
// 逐项 getprop 要十几次往返（每次 100~300ms），冷启动两秒以上，主页体验无法接受。
DeviceDetail detectDeviceDetail(const std::string& wantSerial) {
    DeviceDetail d;

    std::string serial = wantSerial;
    if (serial.empty()) {
        const std::vector<std::string> all = listDeviceSerials();
        if (!all.empty()) serial = all.front();
    }
    if (serial.empty()) {
        d.error = "未检测到已授权的 Android 设备";
        return d;
    }

    d.ready = true;
    d.serial = serial;
    d.connection = (serial.find(':') != std::string::npos) ? "无线（TCP）" : "USB";

    // 用 echo 段标记切段：比 getprop 全量 dump 可控（后者几 MB 且键名不统一）
    const std::string script =
        "echo @@MODEL; getprop ro.product.model; "
        "echo @@MARKET; getprop ro.product.marketname; "
        "echo @@DEVICE; getprop ro.product.device; "
        "echo @@REL; getprop ro.build.version.release; "
        "echo @@SDK; getprop ro.build.version.sdk; "
        "echo @@ROMVER; getprop ro.build.display.id; "
        "echo @@DATE; getprop ro.build.date; "
        "echo @@SLOT; getprop ro.boot.slot_suffix; "
        "echo @@AONLY; getprop ro.build.ab_update; "
        "echo @@VERIFIED; getprop ro.boot.verifiedbootstate; "
        "echo @@LOCKED; getprop ro.boot.flash.locked; "
        "echo @@SOCMAN; getprop ro.soc.manufacturer; "
        "echo @@SOCMOD; getprop ro.soc.model; "
        "echo @@SOCNAME; getprop ro.soc.name; "
        "echo @@HW; getprop ro.hardware; "
        "echo @@SELINUX; getenforce; "
        "echo @@KERNEL; uname -r; "
        "echo @@CPUINFO; cat /proc/cpuinfo | grep -m1 -E 'Hardware|model name'; "
        "echo @@BATT; dumpsys battery | grep -E 'level|status'; "
        "echo @@DF; df /data; "
        "echo @@MEM; grep -E 'MemTotal|MemAvailable|MemFree' /proc/meminfo; "
        "echo @@END";

    const std::string out = runAdb(serial, "shell " + script, 20000);
    if (trim(out).empty()) {
        d.error = "读取设备信息失败（adb shell 无输出）";
        return d;
    }

    std::vector<std::string> lines;
    {
        size_t pos = 0;
        while (pos < out.size()) {
            const size_t eol = out.find('\n', pos);
            lines.push_back(trim(out.substr(pos, eol == std::string::npos ? std::string::npos : eol - pos)));
            pos = (eol == std::string::npos) ? out.size() : eol + 1;
        }
    }

    // 取某个 @@KEY 段的第一行非空内容
    auto field = [&lines](const std::string& key) -> std::string {
        const std::string tag = "@@" + key;
        for (size_t i = 0; i < lines.size(); ++i) {
            if (lines[i] == tag) {
                for (size_t j = i + 1; j < lines.size(); ++j) {
                    if (lines[j].rfind("@@", 0) == 0) break;
                    if (!lines[j].empty()) return lines[j];
                }
                return std::string();
            }
        }
        return std::string();
    };

    d.model = field("MODEL");
    const std::string market = field("MARKET");
    if (d.model.empty()) d.model = market;
    d.device = field("DEVICE");
    if (d.device.empty()) d.device = field("HW");

    const std::string rel = field("REL");
    d.sdk = field("SDK");
    d.android = rel.empty() ? std::string() : (d.sdk.empty() ? rel : (rel + "（API " + d.sdk + "）"));
    d.buildId = field("ROMVER");
    d.buildDate = field("DATE");
    d.kernel = field("KERNEL");
    d.osPlatform = rel.empty() ? "Android" : ("Android " + rel);

    // A/B
    const std::string slot = field("SLOT");
    const std::string abUpdate = field("AONLY");
    if (slot == "_a") {
        d.abSlot = "支持 A/B · 当前 A 槽位";
    } else if (slot == "_b") {
        d.abSlot = "支持 A/B · 当前 B 槽位";
    } else if (abUpdate == "true") {
        d.abSlot = "支持 A/B";
    } else {
        d.abSlot = "不支持 A/B（A-only）";
    }

    // 解锁状态：flash.locked 最直接（1 锁 / 0 解锁），否则看 verifiedbootstate
    const std::string locked = field("LOCKED");
    const std::string verified = field("VERIFIED");
    if (locked == "1") {
        d.unlock = "已锁定";
    } else if (locked == "0") {
        d.unlock = "已解锁";
    } else if (verified == "orange" || verified == "red") {
        d.unlock = "已解锁";
    } else if (verified == "green") {
        d.unlock = "已锁定";
    } else {
        d.unlock = "未知";
    }
    if (!verified.empty()) d.unlock += "（verifiedboot: " + verified + "）";

    d.cpuVendor = field("SOCMAN");
    if (d.cpuVendor.empty()) d.cpuVendor = field("HW");
    d.cpuModel = field("SOCMOD");
    if (d.cpuModel.empty()) d.cpuModel = field("DEVICE");
    d.cpuName = field("SOCNAME");
    if (d.cpuName.empty()) d.cpuName = field("CPUINFO");

    d.selinux = field("SELINUX");
    if (d.selinux.empty()) d.selinux = "未知";

    // 电池
    {
        const std::string tag = "@@BATT";
        for (size_t i = 0; i < lines.size(); ++i) {
            if (lines[i] != tag) continue;
            for (size_t j = i + 1; j < lines.size(); ++j) {
                if (lines[j].rfind("@@", 0) == 0) break;
                const std::string& ln = lines[j];
                if (ln.rfind("level:", 0) == 0) {
                    d.batteryLevel = std::atoi(trim(ln.substr(6)).c_str());
                } else if (ln.rfind("status:", 0) == 0) {
                    const int st = std::atoi(trim(ln.substr(7)).c_str());
                    if (st == 2) d.batteryState = "充电中";
                    else if (st == 3) d.batteryState = "放电中";
                    else if (st == 4) d.batteryState = "未充电";
                    else if (st == 5) d.batteryState = "已充满";
                }
            }
        }
    }

    // 存储：df /data 末行，1K-blocks 与 Used 两列
    {
        const std::string tag = "@@DF";
        for (size_t i = 0; i < lines.size(); ++i) {
            if (lines[i] != tag) continue;
            std::string last;
            for (size_t j = i + 1; j < lines.size(); ++j) {
                if (lines[j].rfind("@@", 0) == 0) break;
                if (!lines[j].empty() && lines[j].find("Filesystem") == std::string::npos) last = lines[j];
            }
            if (!last.empty()) {
                std::istringstream iss(last);
                std::string fs, total, used;
                iss >> fs >> total >> used;
                d.storageTotal = static_cast<unsigned long long>(std::atoll(total.c_str())) * 1024ULL;
                d.storageUsed = static_cast<unsigned long long>(std::atoll(used.c_str())) * 1024ULL;
            }
        }
    }

    // 内存：MemTotal - MemAvailable
    {
        const std::string tag = "@@MEM";
        unsigned long long total = 0, avail = 0, freeKb = 0;
        for (size_t i = 0; i < lines.size(); ++i) {
            if (lines[i] != tag) continue;
            for (size_t j = i + 1; j < lines.size(); ++j) {
                if (lines[j].rfind("@@", 0) == 0) break;
                const std::string& ln = lines[j];
                const size_t colon = ln.find(':');
                if (colon == std::string::npos) continue;
                const std::string key = trim(ln.substr(0, colon));
                const unsigned long long val =
                    static_cast<unsigned long long>(std::atoll(trim(ln.substr(colon + 1)).c_str())) * 1024ULL;
                if (key == "MemTotal") total = val;
                else if (key == "MemAvailable") avail = val;
                else if (key == "MemFree") freeKb = val;
            }
        }
        d.memoryTotal = total;
        d.memoryUsed = total > (avail ? avail : freeKb) ? total - (avail ? avail : freeKb) : 0;
    }

    if (d.model.empty()) d.model = "未知机型";
    return d;
}

// 快捷重启：把界面上的动作名映射成 adb 命令。
// 只有 adb 明确报错才判失败 —— 重启类命令常常把连接掐断，返回非 0 属正常。
bool rebootInto(const std::string& serial, const std::string& target, std::string& log) {
    if (serial.empty()) {
        log = "没有可用的设备序列号";
        return false;
    }
    std::string cmd;
    if (target == "system") cmd = "reboot";
    else if (target == "fastboot") cmd = "reboot bootloader";
    else if (target == "fastbootd") cmd = "reboot fastboot";
    else if (target == "recovery") cmd = "reboot recovery";
    else if (target == "edl") cmd = "reboot edl";
    else if (target == "sideload") cmd = "reboot sideload";
    else if (target == "shutdown") cmd = "reboot -p";
    else {
        log = "未知的重启目标：" + target;
        return false;
    }

    const std::string out = runAdb(serial, "shell " + cmd, 15000);
    std::string low = out;
    for (char& c : low) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    if (low.find("error") != std::string::npos || low.find("not found") != std::string::npos ||
        low.find("denied") != std::string::npos || low.find("cannot") != std::string::npos) {
        log = "重启失败：" + trim(out);
        return false;
    }
    log = "已下发重启指令：" + cmd;
    return true;
}

// 保存设备信息：UTF-8（带 BOM，记事本直接认）纯文本报告
bool saveDeviceReport(const DeviceDetail& d, const std::string& path, std::string& log) {
    // 必须走宽字符路径：exe 常被放在含中文的目录下（如 E:\下载\…），
    // 窄字符 fopen 按当前 ANSI 代码页解释路径，写不进去。
    const std::wstring wpath = widen(path);
    FILE* fp = _wfopen(wpath.c_str(), L"wb");
    if (!fp) {
        log = "无法写入文件：" + path;
        return false;
    }
    const unsigned char bom[3] = {0xEF, 0xBB, 0xBF};
    std::fwrite(bom, 1, 3, fp);

    auto w = [fp](const std::string& s) { std::fwrite(s.data(), 1, s.size(), fp); };
    auto line = [&w](const std::string& k, const std::string& v) { w(k + "：" + v + "\r\n"); };
    auto sizeLine = [&line](const std::string& k, unsigned long long bytes) {
        char buf[64];
        std::snprintf(buf, sizeof(buf), "%.2f GB", static_cast<double>(bytes) / (1024.0 * 1024.0 * 1024.0));
        line(k, buf);
    };

    w("Min RooT — 设备信息报告\r\n");
    w("========================================\r\n\r\n");
    w("[ 基本 ]\r\n");
    line("设备状态", d.ready ? "已连接" : "未连接");
    line("连接类型", d.connection);
    line("设备序列号", d.serial);
    line("设备名称", d.model);
    line("设备代号", d.device);
    line("安卓版本", d.android);
    line("操作系统", d.osPlatform);
    line("解锁状态", d.unlock);
    line("版本信息", d.buildId);
    line("内核版本", d.kernel);
    line("构建日期", d.buildDate);
    w("\r\n[ 硬件 ]\r\n");
    line("A/B 分区", d.abSlot);
    line("CPU 厂家", d.cpuVendor);
    line("CPU 代号", d.cpuModel);
    line("CPU 名称", d.cpuName);
    line("SELinux", d.selinux);
    w("\r\n[ 电池 ]\r\n");
    line("电量", d.batteryLevel < 0 ? std::string("未知") : (std::to_string(d.batteryLevel) + "%"));
    line("充电状态", d.batteryState.empty() ? std::string("未知") : d.batteryState);
    w("\r\n[ 存储与内存 ]\r\n");
    sizeLine("内部存储总容量", d.storageTotal);
    sizeLine("内部存储已用", d.storageUsed);
    sizeLine("运行内存总容量", d.memoryTotal);
    sizeLine("运行内存已用", d.memoryUsed);

    std::fclose(fp);
    log = "已保存：" + path;
    return true;
}

} // namespace backend
