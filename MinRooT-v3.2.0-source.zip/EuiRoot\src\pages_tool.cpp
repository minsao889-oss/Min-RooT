#include "app.h"

#include "ui_toggle.h"

#include "backend/workspace.h"

#include <algorithm>

namespace app {
namespace {

void card(eui::Ui& ui, const std::string& id, float x, float y, float w, float h,
          eui::Color color, float borderAlpha) {
    liquid::glassCard(ui, id, x, y, w, h, 16.0f, color);
}

void kv(eui::Ui& ui, const std::string& id, const std::string& k, const std::string& v,
        float x, float y, float w, eui::Color valueColor) {
    ui.text(id + ".k")
        .position(x, y).size(96.0f, 20.0f)
        .text(k).fontSize(13.0f).lineHeight(19.0f).color(textFaint()).build();
    ui.text(id + ".v")
        .position(x + 96.0f, y).size(w - 96.0f, 20.0f)
        .text(v).fontSize(13.0f).lineHeight(19.0f).color(valueColor).build();
}

} // namespace

void composeTool(eui::Ui& ui, float x, float y, float width, float height) {
    AppState& s = state();
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    const float left = x + 34.0f;
    const float w = width - 68.0f;
    const bool installed = selectedInstalled();
    const float bottom = y + height - 44.0f;   // 给 footer 留位

    ui.text("tl.title")
        .position(left, y + 24.0f).size(w, 34.0f)
        .text("执行提权").fontSize(24.0f).lineHeight(30.0f).fontWeight(800)
        .color(textPrimary()).build();
    ui.text("tl.sub")
        .position(left, y + 60.0f).size(w, 22.0f)
        .text("仅限在本人拥有并授权的设备上使用  ·  直接在手机当前系统上执行，失败时自动重启手机")
        .fontSize(14.0f).lineHeight(20.0f).color(textMuted()).build();

    // ---------------- 放大态：只画日志，从副标题下方铺到 footer
    // 表单控件（前置校验 / 运行方式 / 按钮 / 说明）全部让位，点标题条「还原」即可回到原布局。
    if (s.logExpanded) {
        const float bigTop = y + 88.0f;
        composeLogPanel(ui, "tl.log", left, bigTop, w,
                        std::max(160.0f, bottom - bigTop), 0);
        return;
    }

    // ---------------- 前置校验卡（含实时 root 状态）
    const float checkY = y + 100.0f;
    const float checkH = 142.0f;
    card(ui, "tl.check.card", left, checkY, w, checkH, cardColor(), 0.7f);

    ui.text("tl.check.title")
        .position(left + 24.0f, checkY + 14.0f).size(w - 48.0f, 22.0f)
        .text("前置校验").fontSize(15.0f).lineHeight(21.0f).fontWeight(740)
        .color(textPrimary()).build();

    components::panel(ui, "tl.check.dot", theme())
        .position(left + w - 40.0f, checkY + 20.0f).size(8.0f, 8.0f)
        .radius(4.0f).color(stateColor(selectedState())).build();
    ui.text("tl.check.badge")
        .position(left + w - 138.0f, checkY + 14.0f).size(92.0f, 20.0f)
        .text(backend::stateLabel(selectedState())).fontSize(13.0f).lineHeight(19.0f)
        .horizontalAlign(eui::HorizontalAlign::Right)
        .color(stateColor(selectedState())).build();

    const int selIdx = selectedIndex();
    const std::string curVer =
        (selIdx >= 0 && selIdx < static_cast<int>(s.versions.size()) && !s.versions[selIdx].empty())
            ? s.versions[selIdx]
            : std::string("—");

    const eui::Color rootColor = s.rootActive ? components::theme::color(0.298f, 0.765f, 0.541f)
                                              : textMuted();
    const std::string rootText = !s.device.ready ? std::string()
                                : (s.rootActive ? std::string("已激活（临时）")
                                                : std::string("未激活"));

    kv(ui, "tl.kv.mgr", "管理器", selectedName(), left + 24.0f, checkY + 46.0f, w - 48.0f,
       accentFor(s.selected));
    kv(ui, "tl.kv.state", "安装状态", backend::stateLabel(selectedState()),
       left + 24.0f, checkY + 68.0f, w - 48.0f, stateColor(selectedState()));
    kv(ui, "tl.kv.ver", "已装版本", curVer, left + 24.0f, checkY + 90.0f, w - 48.0f, textMuted());
    kv(ui, "tl.kv.root", "临时 root",
       s.device.ready ? rootText : std::string("未连接设备"),
       left + 24.0f, checkY + 112.0f, w - 48.0f, s.device.ready ? rootColor : textFaint());

    // root 状态右侧的小徽章（已激活时绿点）
    if (s.rootActive) {
        components::panel(ui, "tl.root.dot", theme())
            .position(left + w - 40.0f, checkY + 118.0f).size(8.0f, 8.0f)
            .radius(4.0f).color(components::theme::color(0.298f, 0.765f, 0.541f)).build();
        ui.text("tl.root.badge")
            .position(left + w - 168.0f, checkY + 112.0f).size(120.0f, 20.0f)
            .text("临时 root 有效").fontSize(12.5f).lineHeight(19.0f)
            .horizontalAlign(eui::HorizontalAlign::Right)
            .color(components::theme::color(0.298f, 0.765f, 0.541f)).build();
    }

    float nextY = checkY + checkH + 16.0f;

    // ---------------- 运行方式（三选一，对应 Neo10-Root.ps1 的 1/2/3）
    ui.text("tl.mode.title")
        .position(left, nextY).size(w - 220.0f, 20.0f)
        .text("运行方式").fontSize(13.5f).lineHeight(19.0f).fontWeight(740)
        .color(textPrimary()).build();
    ui.text("tl.mode.hint")
        .position(left + w - 320.0f, nextY).size(320.0f, 20.0f)
        .text("对应 Neo10-Root.ps1 的 1 / 2 / 3 选项，选择后立即生效")
        .fontSize(12.0f).lineHeight(19.0f)
        .horizontalAlign(eui::HorizontalAlign::Right)
        .color(textFaint()).build();

    const float modeY = nextY + 26.0f;
    const float modeH = 56.0f;
    {
        // LiquidTabBar：三段式分段控件，高亮块用 Spring(300, 0.62) 弹簧滑动
        std::vector<std::string> modeLabels;
        modeLabels.push_back(std::string("\u2460 ") + AppState::runModeLabel("Cold"));
        modeLabels.push_back(std::string("\u2461 ") + AppState::runModeLabel("Refire"));
        modeLabels.push_back(std::string("\u2462 ") + AppState::runModeLabel("Interactive"));
        const int modeIndex = (s.runMode == "Cold") ? 0 : (s.runMode == "Refire" ? 1 : 2);
        liquid::tabbar(ui, "tl.mode", left, modeY, w, modeH, modeLabels, modeIndex,
                       [](int i) {
                           static const char* keys[3] = {"Cold", "Refire", "Interactive"};
                           setRunMode(keys[std::clamp(i, 0, 2)]);
                       });
        ui.text("tl.mode.hintline")
            .position(left, modeY + modeH + 8.0f).size(w, 18.0f)
            .text(AppState::runModeHint(s.runMode))
            .fontSize(11.5f).lineHeight(17.0f).wrap(true)
            .color(textMuted()).build();
    }
    nextY = modeY + modeH + 34.0f;

    // ---------------- 未安装提示条
    if (!installed) {
        card(ui, "tl.warn.card", left, nextY, w, 48.0f, warnCardColor(), 0.0f);
        components::panel(ui, "tl.warn.bar", theme())
            .position(left, nextY).size(3.0f, 48.0f)
            .radius(1.5f).color(warnColor()).build();
        ui.text("tl.warn.txt")
            .position(left + 20.0f, nextY + 14.0f).size(w - 40.0f, 22.0f)
            .text("尚未检测到所选管理器安装成功，执行提权已禁用。请先到「管理器」页安装并检测。")
            .fontSize(14.0f).lineHeight(20.0f)
            .color(warnColor()).build();
        nextY += 62.0f;
    }

    // ---------------- 主操作按钮（四个）
    const float btnH = 50.0f;
    const float gap = 12.0f;
    const float btnW = (w - gap * 3.0f) / 4.0f;

    struct BtnSpec {
        const char* id;
        const char* text;
        unsigned int icon;
        bool enabled;
        void (*fn)();
    };
    const BtnSpec specs[4] = {
        {"tl.btn.elevate", "执行提权", 0xF135, installed && !s.busy && !s.toolRunning,
         [] { actionElevate(); }},
        {"tl.btn.retry", "重试提权", 0xF01E, installed && !s.busy && !s.toolRunning,
         [] { actionElevate(); }},
        {"tl.btn.root", "检测root", 0xF05A, s.device.ready && !s.busy && !s.toolRunning,
         [] { actionCheckRoot(); }},
        {"tl.btn.reboot", "重启设备", 0xF01E, s.device.ready && !s.busy && !s.toolRunning,
         [] { state().popup = Popup::ConfirmReboot; }},
    };

    for (int i = 0; i < 4; ++i) {
        const float bx = left + static_cast<float>(i) * (btnW + gap);
        ui_button(ui, specs[i].id, specs[i].text, specs[i].icon,
                  bx, nextY, btnW, btnH, true, specs[i].enabled, specs[i].fn);
    }
    nextY += btnH + 18.0f;

    // ---------------- 底部：运行日志（自适应）+ 参数说明（固定宽）
    // 日志收起时只占 44px 标题条；标题条横跨整行，下方左右两栏各自向下延展，
    // 把省出来的高度吃掉，页面中间不会留一块空白。
    const float bodyH = std::max(150.0f, bottom - nextY);
    const float logH = s.logCollapsed ? 44.0f : bodyH;
    const float noteW = std::min(340.0f, w * 0.32f);
    const float logW = std::max(240.0f, w - noteW - 16.0f);
    const float noteX = left + logW + 16.0f;
    // 收起：日志只占顶部 44px 横条，正文区从横条下方开始，两栏同高
    const float contentTop = s.logCollapsed ? nextY + logH + 16.0f : nextY;
    const float noteTop = contentTop;
    const float noteH = std::max(120.0f, bottom - noteTop);
    const float bodyW = logW;

    if (s.logCollapsed) {
        // 收起态：整行宽度的标题条，下面左栏补一张说明卡填掉省下的高度，
        // 宽度必须 > 420，否则 composeLogPanel 判定放不下三个操作，收起后就点不到「展开」。
        composeLogPanel(ui, "tl.log", left, nextY, w, logH, 400);
        components::panel(ui, "tl.collapsed.body", theme())
            .position(left, contentTop).size(bodyW, noteH)
            .radius(14.0f).color(mutedCardColor()).border(1.0f, borderColor(0.5f)).build();
        ui.text("tl.collapsed.hint")
            .position(left + 20.0f, contentTop + 16.0f).size(bodyW - 40.0f, 20.0f)
            .text("日志面板已收起，上方标题条点「展开」即可恢复")
            .fontSize(12.5f).lineHeight(19.0f).color(textFaint()).build();
    } else {
        composeLogPanel(ui, "tl.log", left, nextY, logW, logH, 400);
    }

    card(ui, "tl.note.card", noteX, noteTop, noteW, noteH, mutedCardColor(), 0.5f);
    ui.text("tl.note.title")
        .position(noteX + 20.0f, noteTop + 16.0f).size(noteW - 40.0f, 20.0f)
        .text("说明").fontSize(14.0f).lineHeight(20.0f).fontWeight(740)
        .color(textPrimary()).build();

    const std::string body =
        "运行方式 → 对应脚本 1 / 2 / 3\n"
        "① 开机模式并重启：冷启动流程，手机会\n"
        "   自己重启，成功率高\n"
        "② 已经重启过：刚开机，直接再打一发\n"
        "③ 不重启直接打：当前系统直接尝试\n"
        "   （默认，本工具不会主动重启）\n"
        "\n"
        "失败自动重启 → 打完后以 su -c id 的\n"
        "真实结果判定，没拿到 root 才给手机发\n"
        "reboot（①②③ 都适用）\n"
        "\n"
        "检测root → adb shell su -c id，\n"
        "只读查询，不改动设备任何状态\n"
        "\n"
        "重启设备 → 手动 adb reboot，重启后\n"
        "临时 root 失效，需要重新执行提权\n"
        "\n"
        "脚本：内置 Neo10-Root.ps1（随程序加密分发）";

    ui.text("tl.note.body")
        .position(noteX + 20.0f, noteTop + 44.0f).size(noteW - 40.0f, noteH - 60.0f)
        .text(body).fontSize(12.5f).lineHeight(20.0f).wrap(true)
        .color(textMuted()).build();
}

} // namespace app
