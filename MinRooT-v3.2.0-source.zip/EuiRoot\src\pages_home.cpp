#include "app.h"

#include "backend/managers.h"
#include "backend/workspace.h"
#include "ui_toggle.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace app {
namespace {

// 主程序 main.cpp 里那份是匿名命名空间的，跨文件用不了，这里自己来一份。
// CJK 按一个字号宽、ASCII 按 0.55 个字宽估算，超宽补省略号。
std::string clip(const std::string& text, float maxWidth, float fontSize) {
    if (text.empty()) return text;
    float used = 0.0f;
    std::size_t i = 0;
    while (i < text.size()) {
        const unsigned char c = static_cast<unsigned char>(text[i]);
        std::size_t step = 1;
        float advance = fontSize * 0.55f;
        if (c >= 0xF0) step = 4;
        else if (c >= 0xE0) { step = 3; advance = fontSize; }
        else if (c >= 0xC0) step = 2;
        if (used + advance > maxWidth) break;
        used += advance;
        i += step;
    }
    if (i >= text.size()) return text;
    return text.substr(0, i) + "…";
}

std::string humanBytes(unsigned long long bytes) {
    if (bytes == 0) return "—";
    const double kb = 1024.0;
    const double mb = kb * 1024.0;
    const double gb = mb * 1024.0;
    const double v = static_cast<double>(bytes);
    char buf[64];
    if (v >= gb) std::snprintf(buf, sizeof(buf), "%.1fG", v / gb);
    else if (v >= mb) std::snprintf(buf, sizeof(buf), "%.0fM", v / mb);
    else if (v >= kb) std::snprintf(buf, sizeof(buf), "%.0fK", v / kb);
    else std::snprintf(buf, sizeof(buf), "%lluB", bytes);
    return std::string(buf);
}

// 面板：与其它页保持一致的圆角 + 细边
void card(eui::Ui& ui, const std::string& id, float x, float y, float w, float h) {
    liquid::glassCard(ui, id, x, y, w, h, 16.0f, cardColor());
}

// 左标签 + 右值
void kv(eui::Ui& ui, const std::string& id, const std::string& k, const std::string& v,
        float x, float y, float w, float keyW, eui::Color valueColor) {
    ui.text(id + ".k")
        .position(x, y).size(keyW, 20.0f)
        .text(k).fontSize(12.5f).lineHeight(20.0f).color(textFaint()).build();
    const float vx = x + keyW;
    const float vw = std::max(20.0f, w - keyW);
    ui.text(id + ".v")
        .position(vx, y).size(vw, 20.0f)
        .text(clip(v.empty() ? std::string("—") : v, vw, 12.5f))
        .fontSize(12.5f).lineHeight(20.0f).color(valueColor).build();
}

// 环形进度：EUI-NEO 没有弧图元，用 48 段小方块顺时针拼一段弧，
// 中间再盖一个卡片色圆盘挖空。段数不能超 128（渲染器顶点上限）。
void ring(eui::Ui& ui, const std::string& id, float cx, float cy, float radius,
          float thickness, float p, eui::Color track, eui::Color fill,
          const std::string& percent, const std::string& sub) {
    p = std::max(0.0f, std::min(1.0f, p));
    const float d = radius * 2.0f;

    ui.rect(id + ".track")
        .position(cx - radius, cy - radius).size(d, d)
        .radius(radius).color(track).build();

    const int segments = 48;
    const int lit = static_cast<int>(std::lround(p * segments));
    const float arcR = radius - thickness * 0.5f;
    for (int i = 0; i < lit; ++i) {
        const float a = -1.5707963f + (6.2831853f / segments) * static_cast<float>(i);
        const float bx = cx + std::cos(a) * arcR;
        const float by = cy + std::sin(a) * arcR;
        const float bw = thickness * 1.25f;
        ui.rect(id + ".arc" + std::to_string(i))
            .position(bx - bw * 0.5f, by - bw * 0.5f).size(bw, bw)
            .radius(bw * 0.5f).color(fill).build();
    }

    const float inner = radius - thickness;
    ui.rect(id + ".hole")
        .position(cx - inner, cy - inner).size(inner * 2.0f, inner * 2.0f)
        .radius(inner).color(cardColor()).build();

    ui.text(id + ".pct")
        .position(cx - radius, cy - 15.0f).size(d, 22.0f)
        .text(percent).fontSize(17.0f).lineHeight(22.0f).fontWeight(820)
        .color(textPrimary())
        .horizontalAlign(eui::HorizontalAlign::Center).build();
    ui.text(id + ".sub")
        .position(cx - radius, cy + 8.0f).size(d, 16.0f)
        .text(sub).fontSize(10.5f).lineHeight(16.0f)
        .color(textFaint())
        .horizontalAlign(eui::HorizontalAlign::Center).build();
}

// 蓝色实心方块按钮（快捷重启组）
void blockButton(eui::Ui& ui, const std::string& id, const std::string& text, unsigned int icon,
                 float x, float y, float w, float h, bool enabled, std::function<void()> onClick) {
    components::ButtonStyle style = ui_button_style(true, enabled);
    style.pressScale = 1.0f;
    const float scaleNow = liquid::pressSpring(ui, id, x, y, w, h, enabled, std::move(onClick));
    components::button(ui, id)
        .position(x, y).size(w, h)
        .icon(icon).iconSize(15.0f)
        .fontSize(13.0f)
        .text(text)
        .style(style)
        .scale(scaleNow)
        .translate(-w * (scaleNow - 1.0f) * 0.5f, -h * (scaleNow - 1.0f) * 0.5f)
        .transition(motion())
        .build();
    ui_frost_overlay(ui, id, x + w * 0.5f - w * scaleNow * 0.5f,
                     y + h * 0.5f - h * scaleNow * 0.5f,
                     w * scaleNow, h * scaleNow, h * 0.5f * scaleNow, true, enabled);
}

// 绿色描边按钮（快捷工具组）
void softButton(eui::Ui& ui, const std::string& id, const std::string& text, unsigned int icon,
                float x, float y, float w, float h, std::function<void()> onClick) {
    const eui::Color green = components::theme::color(0.300f, 0.690f, 0.560f);
    components::ButtonStyle style(theme(), false);
    style.normal = components::theme::withAlpha(green, theme().dark ? 0.20f : 0.14f);
    style.hover = components::theme::withAlpha(green, theme().dark ? 0.28f : 0.20f);
    style.pressed = components::theme::withAlpha(green, theme().dark ? 0.34f : 0.26f);
    style.text = green;
    style.icon = green;
    style.pressScale = 1.0f;
    const float scaleNow = liquid::pressSpring(ui, id, x, y, w, h, true, std::move(onClick));
    components::button(ui, id)
        .position(x, y).size(w, h)
        .icon(icon).iconSize(15.0f)
        .fontSize(13.0f)
        .text(text)
        .style(style)
        .scale(scaleNow)
        .translate(-w * (scaleNow - 1.0f) * 0.5f, -h * (scaleNow - 1.0f) * 0.5f)
        .transition(motion())
        .build();
    ui_frost_overlay(ui, id, x + w * 0.5f - w * scaleNow * 0.5f,
                     y + h * 0.5f - h * scaleNow * 0.5f,
                     w * scaleNow, h * scaleNow, h * 0.5f * scaleNow, false, true);
}

// 液态玻璃胶囊开关（AndroidLiquidGlass LiquidToggle 1:1）
// 尺寸照搬参考实现：轨道 64x28、旋钮 40x24、内边距 2、行程 20。
// 轨道和旋钮都是玻璃：旋钮压在轨道上，轨道自己再垫一层玻璃底，
// 这样旋钮的折射采样到的是「轨道玻璃」而不是页面背景，和 Compose 版的
// layerBackdrop(trackBackdrop) 效果一致。
// 弹簧物理（过冲回弹 / 按压 1.5x / 速度拉伸 / 拖拽）统一收在 ui_toggle.h，
// 首页与镜像页共用同一份实现，避免两处各写一遍。
void toggleSwitch(eui::Ui& ui, const std::string& id, float x, float y, bool on,
                  std::function<void()> onClick) {
    liquid::toggle(ui, id, x, y, on, std::move(onClick));
}

// 底部小字链接：TextBuilder 没有 hoverColor，挂一层透明矩形做热区
void linkText(eui::Ui& ui, const std::string& id, const std::string& text, float x, float y,
              float w, bool accent, std::function<void()> onClick) {
    ui.rect(id + ".hit")
        .position(x, y).size(w, 20.0f)
        .color({0.0f, 0.0f, 0.0f, 0.0f})
        .radius(6.0f)
        .interactive(true)
        .hoverColor(hoverTint())
        .pressedColor(pressedTint())
        .onClick(std::move(onClick))
        .build();
    ui.text(id)
        .position(x, y).size(w, 20.0f)
        .text(text).fontSize(12.0f).lineHeight(20.0f)
        .color(accent ? theme().primary : textFaint())
        .build();
}

} // namespace

void composeHome(eui::Ui& ui, float x, float y, float w, float h) {
    AppState& s = state();
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    const backend::DeviceDetail& d = s.detail;
    const bool ready = d.ready;

    // ================= 标题区 =================
    ui.text("home.title")
        .position(x + 32.0f, y + 24.0f).size(320.0f, 30.0f)
        .text("主页").fontSize(24.0f).lineHeight(30.0f).fontWeight(800)
        .color(textPrimary()).build();

    std::string sub;
    if (ready) {
        sub = d.serial;
        if (!d.model.empty()) sub += "  ·  " + d.model;
        if (!d.android.empty()) sub += "  ·  Android " + d.android;
    } else if (s.homeBusy) {
        sub = "正在读取设备信息…";
    } else {
        sub = d.error.empty() ? "未检测到已授权的 Android 设备" : d.error;
    }
    const float subW = std::max(200.0f, w - 420.0f);
    ui.text("home.sub")
        .position(x + 32.0f, y + 58.0f).size(subW, 20.0f)
        .text(clip(sub, subW, 12.5f)).fontSize(12.5f).lineHeight(20.0f)
        .color(ready ? textMuted() : textFaint()).build();

    ui_button(ui, "home.refresh", "刷新设备", 0xF021, x + w - 32.0f - 300.0f, y + 26.0f,
              140.0f, 34.0f, false, true, [] { refreshHomeDetail(); });
    ui_button(ui, "home.detect", "设备检测", 0xF0C8, x + w - 32.0f - 148.0f, y + 26.0f,
              148.0f, 34.0f, true, true, [] { actionRefreshDevice(); });

    // ================= 版式基准 =================
    const float pad = 32.0f;
    const float gap = 16.0f;
    const float top = y + 96.0f;
    const float leftW = std::max(320.0f, (w - pad * 2.0f) * 0.545f);
    const float rightX = x + pad + leftW + gap;
    const float rightW = std::max(240.0f, w - pad * 2.0f - leftW - gap);
    const float infoH = 322.0f;
    const float availH = std::max(440.0f, h - top - 66.0f);
    const float bottomH = std::max(150.0f, availH - infoH - gap);
    const float bottomY = top + infoH + gap;

    // ================= 左上：设备信息 =================
    card(ui, "home.info.card", x + pad, top, leftW, infoH);

    ui.text("home.info.title")
        .position(x + pad + 22.0f, top + 18.0f).size(leftW - 44.0f, 24.0f)
        .text("设备信息").fontSize(15.5f).lineHeight(24.0f).fontWeight(780)
        .color(textPrimary()).build();
    ui_divider(ui, "home.info.rule", x + pad + 20.0f, top + 46.0f, leftW - 40.0f, true);

    if (!ready) {
        ui.text("home.info.empty")
            .position(x + pad + 22.0f, top + 130.0f).size(leftW - 44.0f, 70.0f)
            .text(d.error.empty() ? "请先用数据线连接手机，并在手机上允许 USB 调试" : d.error)
            .fontSize(13.0f).lineHeight(22.0f).wrap(true)
            .horizontalAlign(eui::HorizontalAlign::Center)
            .color(textFaint()).build();
    } else {
        const float colGap = 22.0f;
        const float colW = (leftW - 44.0f - colGap) * 0.5f;
        const float colX1 = x + pad + 22.0f;
        const float colX2 = colX1 + colW + colGap;
        const float rowY = top + 58.0f;
        const float rowGap = 27.0f;
        const float keyW = 76.0f;

        const eui::Color ok = stateColor(backend::InstallState::Installed);

        kv(ui, "home.i.status", "设备状态", "已连接", colX1, rowY, colW, keyW, ok);
        kv(ui, "home.i.ab", "A/B 分区", d.abSlot, colX2, rowY, colW, keyW, textPrimary());
        kv(ui, "home.i.conn", "连接类型", d.connection, colX1, rowY + rowGap, colW, keyW, textPrimary());
        kv(ui, "home.i.cpuv", "CPU 厂家", d.cpuVendor, colX2, rowY + rowGap, colW, keyW, textPrimary());
        kv(ui, "home.i.serial", "设备序列号", d.serial, colX1, rowY + rowGap * 2.0f, colW, keyW, textPrimary());
        kv(ui, "home.i.cpum", "CPU 代号", d.cpuModel, colX2, rowY + rowGap * 2.0f, colW, keyW, textPrimary());
        kv(ui, "home.i.model", "设备名称", d.model, colX1, rowY + rowGap * 3.0f, colW, keyW, textPrimary());
        kv(ui, "home.i.cpun", "CPU 名称", d.cpuName, colX2, rowY + rowGap * 3.0f, colW, keyW, textPrimary());
        kv(ui, "home.i.device", "设备代号", d.device, colX1, rowY + rowGap * 4.0f, colW, keyW, textPrimary());
        kv(ui, "home.i.os", "操作系统", d.osPlatform, colX2, rowY + rowGap * 4.0f, colW, keyW, textPrimary());
        kv(ui, "home.i.android", "安卓版本", d.android, colX1, rowY + rowGap * 5.0f, colW, keyW, textPrimary());
        kv(ui, "home.i.selinux", "SELinux", d.selinux, colX2, rowY + rowGap * 5.0f, colW, keyW,
           d.selinux == "Enforcing" ? ok : warnColor());
        kv(ui, "home.i.unlock", "解锁状态", d.unlock, colX1, rowY + rowGap * 6.0f, colW, keyW,
           d.unlock.rfind("已解锁", 0) == 0 ? warnColor() : textPrimary());
        // 这三行内容长，跨两列渲染；硬塞进左列会被裁成「…」。
        const float fullW = leftW - 44.0f;
        kv(ui, "home.i.build", "版本信息", d.buildId, colX1, rowY + rowGap * 7.0f, fullW, keyW, textPrimary());
        kv(ui, "home.i.kernel", "内核版本", d.kernel, colX1, rowY + rowGap * 8.0f, fullW, keyW, textPrimary());
        kv(ui, "home.i.date", "构建日期", d.buildDate, colX1, rowY + rowGap * 9.0f, fullW, keyW, textPrimary());
    }

    // ================= 右上：电池状态 =================
    const float battH = 132.0f;
    card(ui, "home.batt.card", rightX, top, rightW, battH);

    ui.text("home.batt.title")
        .position(rightX + 20.0f, top + 16.0f).size(rightW - 40.0f, 22.0f)
        .text("电池状态").fontSize(14.5f).lineHeight(22.0f).fontWeight(780)
        .color(textPrimary()).build();
    ui_divider(ui, "home.batt.rule", rightX + 20.0f, top + 44.0f, rightW - 40.0f, true);
    {
        const float bx = rightX + 22.0f;
        const float by = top + 54.0f;
        const float bw = std::max(60.0f, rightW - 64.0f);
        const float bh = 56.0f;
        const int lvl = d.batteryLevel < 0 ? -1 : std::min(100, d.batteryLevel);
        const float fillW = lvl < 0 ? 0.0f
                                    : std::max(0.0f, (bw - 8.0f) * (static_cast<float>(lvl) / 100.0f));

        ui.rect("home.batt.body")
            .position(bx, by).size(bw, bh).radius(9.0f)
            .color(components::theme::withAlpha(theme().text, 0.06f))
            .border(1.5f, components::theme::withAlpha(theme().text, 0.20f))
            .zIndex(10).build();
        if (fillW > 2.0f) {
            ui.rect("home.batt.fill")
                .position(bx + 4.0f, by + 4.0f).size(fillW, bh - 8.0f).radius(6.0f)
                .color(theme().primary).zIndex(11).build();
        }
        ui.rect("home.batt.tip")
            .position(bx + bw + 3.0f, by + bh * 0.30f).size(7.0f, bh * 0.40f)
            .radius(3.0f).color(components::theme::withAlpha(theme().text, 0.20f)).build();

        const std::string lvlText = lvl < 0 ? "—" : (std::to_string(lvl) + "%");
        // 填充条是实心 primary，百分比必须压在它上面，
        // 且颜色要取卡片底色（深色下 primary 文字落在 primary 块上会糊成一片）。
        ui.text("home.batt.pct")
            .position(bx, by).size(bw, bh)
            .text(lvlText).fontSize(17.0f).lineHeight(bh).fontWeight(820)
            .color(theme().dark ? eui::Color{1.0f, 1.0f, 1.0f, 1.0f} : theme().primary)
            .horizontalAlign(eui::HorizontalAlign::Center)
            .zIndex(20).build();
    }

    // ================= 右中：存储与内存 =================
    const float ringY = top + battH + gap;
    const float ringH = std::max(150.0f, bottomY - gap - ringY);
    card(ui, "home.mem.card", rightX, ringY, rightW, ringH);

    ui.text("home.mem.title")
        .position(rightX + 20.0f, ringY + 16.0f).size(rightW - 40.0f, 22.0f)
        .text("存储与内存").fontSize(14.5f).lineHeight(22.0f).fontWeight(780)
        .color(textPrimary()).build();
    ui_divider(ui, "home.mem.rule", rightX + 20.0f, ringY + 44.0f, rightW - 40.0f, true);
    {
        const float radius = std::min(52.0f, std::max(32.0f, (ringH - 102.0f) * 0.5f));
        const float cy = ringY + 52.0f + radius;
        const float cx1 = rightX + rightW * 0.29f;
        const float cx2 = rightX + rightW * 0.71f;

        const double sTotal = static_cast<double>(d.storageTotal);
        const double sRatio = sTotal > 0.0 ? static_cast<double>(d.storageUsed) / sTotal : 0.0;
        char sbuf[64];
        std::snprintf(sbuf, sizeof(sbuf), "%s/%s", humanBytes(d.storageUsed).c_str(),
                      humanBytes(d.storageTotal).c_str());

        const double mTotal = static_cast<double>(d.memoryTotal);
        const double mRatio = mTotal > 0.0 ? static_cast<double>(d.memoryUsed) / mTotal : 0.0;
        char mbuf[64];
        std::snprintf(mbuf, sizeof(mbuf), "%s/%s", humanBytes(d.memoryUsed).c_str(),
                      humanBytes(d.memoryTotal).c_str());

        char p1[16];
        char p2[16];
        std::snprintf(p1, sizeof(p1), "%.1f%%", sRatio * 100.0);
        std::snprintf(p2, sizeof(p2), "%.1f%%", mRatio * 100.0);

        const eui::Color track = components::theme::withAlpha(theme().text, 0.10f);
        ring(ui, "home.mem.storage", cx1, cy, radius, 8.0f, static_cast<float>(sRatio), track,
             theme().primary, p1, d.storageTotal == 0 ? std::string("未知") : std::string(sbuf));
        ring(ui, "home.mem.memory", cx2, cy, radius, 8.0f, static_cast<float>(mRatio), track,
             components::theme::color(0.608f, 0.482f, 1.000f), p2,
             d.memoryTotal == 0 ? std::string("未知") : std::string(mbuf));

        const float labelY = cy + radius + 10.0f;
        if (labelY + 18.0f <= ringY + ringH - 6.0f) {
            ui.text("home.mem.storage.label")
                .position(cx1 - radius, labelY).size(radius * 2.0f, 18.0f)
                .text("内部存储").fontSize(11.5f).lineHeight(18.0f)
                .color(textMuted())
                .horizontalAlign(eui::HorizontalAlign::Center).build();
            ui.text("home.mem.memory.label")
                .position(cx2 - radius, labelY).size(radius * 2.0f, 18.0f)
                .text("运行内存").fontSize(11.5f).lineHeight(18.0f)
                .color(textMuted())
                .horizontalAlign(eui::HorizontalAlign::Center).build();
        }
    }

    // ================= 左下：快捷重启 =================
    card(ui, "home.rb.card", x + pad, bottomY, leftW, bottomH);

    ui.text("home.rb.title")
        .position(x + pad + 20.0f, bottomY + 16.0f).size(leftW - 40.0f, 22.0f)
        .text("快捷重启").fontSize(14.5f).lineHeight(22.0f).fontWeight(780)
        .color(textPrimary()).build();
    ui_divider(ui, "home.rb.rule", x + pad + 20.0f, bottomY + 44.0f, leftW - 40.0f, true);
    {
        const bool online = ready;
        const float bx = x + pad + 20.0f;
        const float by = bottomY + 50.0f;
        const float innerW = leftW - 44.0f;
        const float bW = (innerW - 14.0f) * 0.5f;
        const float bH = 40.0f;
        const float col2 = bx + bW + 14.0f;

        blockButton(ui, "home.rb.system", "系统", 0xF011, bx, by, bW, bH, online,
                    [online] { if (online) actionRebootInto("system"); });
        blockButton(ui, "home.rb.fastboot", "Fastboot", 0xF0E7, col2, by, bW, bH, online,
                    [online] { if (online) actionRebootInto("fastboot"); });
        blockButton(ui, "home.rb.fastbootd", "FastbootD", 0xF019, bx, by + bH + 12.0f, bW, bH, online,
                    [online] { if (online) actionRebootInto("fastbootd"); });
        blockButton(ui, "home.rb.recovery", "Recovery", 0xF021, col2, by + bH + 12.0f, bW, bH, online,
                    [online] { if (online) actionRebootInto("recovery"); });
        blockButton(ui, "home.rb.edl", "9008(EDL)", 0xF0E2, bx, by + (bH + 12.0f) * 2.0f, bW, bH, online,
                    [online] { if (online) actionRebootInto("edl"); });
        blockButton(ui, "home.rb.refresh", "刷新设备", 0xF01E, col2, by + (bH + 12.0f) * 2.0f, bW, bH,
                    true, [] { refreshHomeDetail(); });

        const float ddY = by + (bH + 12.0f) * 3.0f + 2.0f;
        const float ddH = 36.0f;
        if (ddY + ddH <= bottomY + bottomH - 10.0f) {
            ui.stack("home.rb.ddbox")
                .position(bx, ddY)
                .size(innerW, ddH)
                .content([&ui, innerW] {
                    components::dropdown(ui, "home.rb.dd")
                        .size(innerW, 36.0f)
                        .items({"更多重启指令", "重启到 Bootloader", "重启到 Sideload",
                                "关机", "重启系统"})
                        .selected(0)
                        .theme(theme())
                        .transition(motion())
                        .onChange([](int index) {
                            // 下拉在滚轮/手滑时很容易误选，而「关机」「重启到 Bootloader」
                            // 一旦下发就不可撤销。这里只登记待确认项并弹确认框，
                            // 真正下发在 dialog 的 onPrimary 里。
                            const char* target = nullptr;
                            const char* label = nullptr;
                            if (index == 1) { target = "fastboot"; label = "重启到 Bootloader"; }
                            else if (index == 2) { target = "sideload"; label = "重启到 Sideload"; }
                            else if (index == 3) { target = "shutdown"; label = "关机"; }
                            else if (index == 4) { target = "system"; label = "重启系统"; }
                            if (target == nullptr) return;
                            state().pendingRebootTarget = target;
                            state().pendingRebootLabel = label;
                            state().popup = Popup::ConfirmReboot;
                        })
                        .build();
                })
                .build();
        }
    }

    // ================= 右下：快捷工具 =================
    card(ui, "home.tool.card", rightX, bottomY, rightW, bottomH);

    ui.text("home.tool.title")
        .position(rightX + 20.0f, bottomY + 16.0f).size(rightW - 40.0f, 22.0f)
        .text("快捷工具").fontSize(14.5f).lineHeight(22.0f).fontWeight(780)
        .color(textPrimary()).build();
    ui_divider(ui, "home.tool.rule", rightX + 20.0f, bottomY + 44.0f, rightW - 40.0f, true);
    {
        const float bx = rightX + 20.0f;
        const float innerW = rightW - 40.0f;
        const float by = bottomY + 52.0f;
        const float bW = (innerW - 12.0f) * 0.5f;
        const float bH = 38.0f;

        softButton(ui, "home.tool.wireless", s.homeWireless ? "断开无线" : "无线调试",
                   s.homeWireless ? 0xF127 : 0xF1EB, bx, by, bW, bH, [] { actionToggleWireless(); });
        softButton(ui, "home.tool.slot", s.homeAbSlot.empty() ? std::string("切换槽位")
                                                              : ("切到 " + s.homeAbSlot),
                   0xF0C4, bx + bW + 12.0f, by, bW, bH, [] { actionSwitchSlot(); });

        const float rowY0 = by + bH + 12.0f;
        const float rowH = 32.0f;
        struct Row {
            const char* id;
            const char* label;
            bool on;
            std::function<void()> onClick;
        };
        const Row rows[3] = {
            {"home.tool.chk", "设备检测", s.homeDeviceCheck,
             [] {
                 AppState& st = state();
                 st.homeDeviceCheck = !st.homeDeviceCheck;
                 if (st.homeDeviceCheck) refreshHomeDetail();
                 logLine(LOG_INFO, std::string("主页面板 · 设备检测 · ") +
                                       (st.homeDeviceCheck ? "已开启" : "已关闭"));
             }},
            {"home.tool.self", "工具自检", s.homeToolCheck,
             [] {
                 AppState& st = state();
                 st.homeToolCheck = !st.homeToolCheck;
                 if (st.homeToolCheck) actionSelfCheck();  // 打开就真跑一遍，别只留个开关
                 else logLine(LOG_INFO, std::string("主页面板 · 工具自检 · 已关闭"));
             }},
            {"home.tool.multi", "多设备", s.homeMultiDevice,
             [] {
                 AppState& st = state();
                 st.homeMultiDevice = !st.homeMultiDevice;
                 logLine(LOG_INFO, std::string("主页面板 · 多设备模式 · ") +
                                       (st.homeMultiDevice ? "已开启" : "已关闭"));
             }},
        };
        for (int i = 0; i < 3; ++i) {
            const float ry = rowY0 + rowH * static_cast<float>(i);
            if (ry + rowH > bottomY + bottomH - 44.0f) break;
            ui.text(std::string(rows[i].id) + ".label")
                .position(bx, ry + 6.0f).size(innerW - liquid::kTrackW - 12.0f, 20.0f)
                .text(rows[i].label).fontSize(12.5f).lineHeight(20.0f)
                .color(textPrimary()).build();
            toggleSwitch(ui, rows[i].id, bx + innerW - liquid::kTrackW - 8.0f, ry + 5.0f, rows[i].on,
                         rows[i].onClick);
        }

        const float ddY2 = bottomY + bottomH - 40.0f;
        std::vector<std::string> items = backend::listDeviceSerials();
        if (items.empty()) items.push_back("未检测到设备");
        ui.stack("home.tool.ddbox")
            .position(bx, ddY2)
            .size(innerW, 34.0f)
            .content([&ui, innerW, items] {
                components::dropdown(ui, "home.tool.dd")
                    .size(innerW, 34.0f)
                    .items(items)
                    .selected(0)
                    .theme(theme())
                    .transition(motion())
                    .openUp(true)
                    .onChange([](int index) {
                        const std::vector<std::string> now = backend::listDeviceSerials();
                        if (index >= 0 && index < static_cast<int>(now.size())) {
                            state().homeSelectSerial = now[static_cast<std::size_t>(index)];
                            refreshHomeDetail();
                        }
                    })
                    .build();
            })
            .build();
    }

    // ================= 底部链接 =================
    {
        const float ly = y + h - 40.0f;
        float lx = x + pad;
        struct Link {
            const char* id;
            const char* text;
            float w;
            bool accent;
            std::function<void()> onClick;
        };
        const Link links[5] = {
            {"home.link.save", "保存设备信息", 96.0f, false, [] { actionSaveDeviceInfo(); }},
            {"home.link.logs", "打开日志目录", 96.0f, false, [] { actionOpenLogDir(); }},
            {"home.link.tutorial", "全功能使用教程", 108.0f, true, [] {
                 actionOpenUrl("https://github.com/Smart-Paocai/VioletToolBox");
             }},
            {"home.link.connect", "连接指南", 72.0f, false, [] {
                 actionOpenUrl("https://developer.android.google.cn/tools/adb");
             }},
            {"home.link.usb3", "USB3.0补丁", 86.0f, false, [] { actionUsb3Compat(); }},
        };
        for (const Link& lk : links) {
            linkText(ui, lk.id, lk.text, lx, ly, lk.w, lk.accent, lk.onClick);
            lx += lk.w + 18.0f;
        }
    }
}

} // namespace app
