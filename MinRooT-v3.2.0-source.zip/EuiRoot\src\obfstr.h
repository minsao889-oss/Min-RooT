// obfstr.h —— 编译期字符串混淆（密文存于二进制，运行时解码为 std::string）
// 原理：OBF("...") 在编译期把明文（含结尾 NUL）XOR 成密文数组，二进制里只有密文；
// 运行时把密文还原进 std::string。不是强加密，目标是防 strings/十六进制直接查看。
#pragma once

#include <string>
#include <cstdint>

namespace obf {

constexpr std::uint8_t maskAt(std::uint64_t seed, std::size_t i) {
    std::uint64_t x = seed ^ (0x9E3779B97F4A7C15ULL * static_cast<std::uint64_t>(i + 1));
    x ^= x >> 33; x *= 0xFF51AFD7ED558CCDULL; x ^= x >> 33;
    x *= 0xC4CEB9FE1A85EC53ULL; x ^= x >> 33;
    return static_cast<std::uint8_t>(x & 0xFF);
}

constexpr std::size_t strLen(const char* s) {
    std::size_t n = 0;
    while (s[n] != '\0') ++n;
    return n;
}

// 编译期密文容器（含 NUL）
template <std::size_t N, std::uint64_t SEED>
struct Cipher {
    std::uint8_t data[N];
    constexpr Cipher(const char* s) : data{} {
        for (std::size_t i = 0; i < N; ++i)
            data[i] = static_cast<std::uint8_t>(s[i]) ^ maskAt(SEED, i);
    }
    // 运行时解码
    std::string str() const {
        std::string out;
        out.resize(N - 1);
        for (std::size_t i = 0; i + 1 < N; ++i)
            out[i] = static_cast<char>(data[i] ^ maskAt(SEED, i));
        return out;
    }
};

} // namespace obf

#define OBF_STR_impl(STR, SEED) std::string(STR) // BISECT: passthrough

#define OBF(STR) OBF_STR_impl(STR, 0xC0FFEE0000ULL + static_cast<std::uint64_t>(__COUNTER__) * 0x2545F4914F6CDD1DULL)
