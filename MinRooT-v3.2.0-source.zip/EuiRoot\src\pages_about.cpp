#include "app.h"

#include "backend/assets.h"
#include "backend/process.h"
#include "backend/workspace.h"
#include "obfstr.h"

#include <algorithm>
#include <string>
#include "ui_toggle.h"

namespace app {
namespace {

// ---------------------------------------------------------------- 作者信息
// 所有字段都来自程序目录下的 author.ini（首次启动自动生成），改文件重启即可生效。
struct AuthorInfo {
    std::string name = "YG";
    std::string role;
    std::string slogan;
    std::string avatar;
    std::string qq;
    std::string qqGroup;
    std::string groupName;
    std::string email;
    std::string homepage;
    std::string project;
    std::string alipay;
    std::string wechat;
    std::string donateNote;
    std::string version = "3.3.0";
    std::string build;
    std::string license;
};

std::string iniValue(const char* section, const char* key, const char* def) {
    return backend::readIni(backend::authorIniPath(), section, key, def);
}

AuthorInfo loadAuthor() {
    AuthorInfo a;
    // —— 作者联系方式：编译期混淆固化（obfstr.h），不读配置、界面与文件均改不了 ——
    a.name = iniValue("author", "name", "YG");
    a.role = iniValue("author", "role", "独立开发者 · Android 折腾爱好者");
    a.slogan = iniValue("author", "slogan", "");
    a.avatar = iniValue("author", "avatar", "about/avatar.png");
    a.qq = OBF("1241252612");
    a.qqGroup = OBF("3842920539");
    a.groupName = OBF("Min RooT 交流群");
    a.email = "";
    a.homepage = OBF("https://github.com/minsao889-oss/SiliconRootTool");
    a.project = OBF("https://github.com/minsao889-oss/SiliconRootTool");
    a.alipay = iniValue("donate", "alipay", "about/alipay.png");
    a.wechat = iniValue("donate", "wechat", "about/wechat.png");
    a.donateNote = iniValue("donate", "note", "如果这个工具帮你省了时间，可以请我喝杯咖啡 · 完全自愿");
    a.version = iniValue("app", "version", "3.3.0");
    a.build = iniValue("app", "build", "2026-10-19");
    a.license = iniValue("app", "license", "仅供本人拥有并授权的设备使用");
    return a;
}

bool filled(const std::string& value) {
    return !value.empty() && value != "未填写" && value != "-";
}

std::string orDash(const std::string& value) {
    return filled(value) ? value : std::string("未填写");
}

// 按像素宽度粗略截断（CJK 记 1 字宽，ASCII 记 0.55），超宽补省略号
std::string clip(const std::string& text, float maxWidth, float fontSize) {
    if (maxWidth <= 8.0f) return text;
    float used = 0.0f;
    std::size_t i = 0;
    while (i < text.size()) {
        const unsigned char c = static_cast<unsigned char>(text[i]);
        std::size_t step = 1;
        if ((c & 0x80) == 0x00) step = 1;
        else if ((c & 0xE0) == 0xC0) step = 2;
        else if ((c & 0xF0) == 0xE0) step = 3;
        else step = 4;
        const float w = (step == 1) ? fontSize * 0.55f : fontSize;
        if (used + w > maxWidth - fontSize * 0.8f) return text.substr(0, i) + "…";
        used += w;
        i += step;
    }
    return text;
}

// ---------------------------------------------------------------- 小工具
void card(eui::Ui& ui, const std::string& id, float x, float y, float w, float h,
          eui::Color color, float borderAlpha, float radius = 16.0f) {
    (void)borderAlpha;
    liquid::glassCard(ui, id, x, y, w, h, radius, color);
}

void kvRow(eui::Ui& ui, const std::string& id, const std::string& key, const std::string& value,
           float x, float y, float w, eui::Color valueColor) {
    ui.text(id + ".k")
        .position(x, y).size(96.0f, 20.0f)
        .text(key).fontSize(13.0f).lineHeight(19.0f).color(textFaint()).build();
    ui.text(id + ".v")
        .position(x + 100.0f, y).size(std::max(40.0f, w - 100.0f), 20.0f)
        .text(value).fontSize(13.0f).lineHeight(19.0f).color(valueColor).build();
}

// 赞赏码卡片（三列之一）
void supportTile(eui::Ui& ui, const std::string& id, const std::string& title,
                 const std::string& imagePath, const std::string& hint,
                 float x, float y, float w, float h, unsigned int icon,
                 std::function<void()> onClick) {
    card(ui, id + ".card", x, y, w, h, mutedCardColor(), 0.6f, 14.0f);

    ui.text(id + ".title")
        .position(x + 16.0f, y + 14.0f).size(w - 32.0f, 20.0f)
        .text(title).fontSize(14.0f).lineHeight(20.0f).fontWeight(740)
        .color(textPrimary()).build();

    // 赞赏码：尽量铺满卡片正文（扫码场景，越大越好扫）
    const float qrX = x + 18.0f;
    const float qrY = y + 40.0f;
    const float qrW = w - 36.0f;
    const float qrH = std::max(72.0f, h - 40.0f - 44.0f);
    const float qr = std::min(qrW, qrH);
    const float qCx = qrX + (qrW - qr) * 0.5f;
    const bool hasImage = filled(imagePath) && backend::assets::exists(imagePath);
    const std::string imageFile = hasImage ? backend::assets::pathForExternal(imagePath) : std::string();
    const bool drawImage = !imageFile.empty();

    if (drawImage) {
        ui.image(id + ".qr")
            .position(qCx, qrY + (qrH - qr) * 0.5f).size(qr, qr)
            .source(imageFile)
            .radius(10.0f)
            .contain()
            .build();
    } else {
        components::panel(ui, id + ".ph", theme())
            .position(qCx, qrY).size(qr, qr)
            .radius(10.0f)
            .color(overlayTint(0.035f))
            .border(1.0f, borderColor(0.75f))
            .build();
        ui.text(id + ".ph.icon")
            .position(qCx, qrY + qr * 0.5f - 26.0f).size(qr, 28.0f)
            .icon(icon).fontSize(24.0f).lineHeight(28.0f)
            .horizontalAlign(eui::HorizontalAlign::Center)
            .color(textFaint()).build();
        ui.text(id + ".ph.txt")
            .position(qCx + 6.0f, qrY + qr * 0.5f + 6.0f).size(qr - 12.0f, 34.0f)
            .text("放入 " + imagePath).fontSize(11.0f).lineHeight(15.0f)
            .wrap(true).horizontalAlign(eui::HorizontalAlign::Center)
            .color(textFaint()).build();
    }

    ui.text(id + ".hint")
        .position(x + 16.0f, y + h - 34.0f).size(w - 32.0f, 24.0f)
        .text(hint).fontSize(12.0f).lineHeight(17.0f).wrap(true)
        .color(textFaint()).build();

    components::panel(ui, id + ".hit", theme())
        .position(x, y).size(w, h)
        .radius(14.0f)
        .color({0.0f, 0.0f, 0.0f, 0.0f})
        .interactive(true)
        .hoverColor(hoverTint())
        .pressedColor(pressedTint())
        .onClick([onClick] {
            if (onClick) onClick();
        })
        .build();
}

} // namespace

void composeAbout(eui::Ui& ui, float x, float y, float width, float height) {
    const AuthorInfo a = loadAuthor();
    const float left = x + 34.0f;
    const float w = width - 68.0f;
    const float bottom = y + height - 44.0f;

    ui.text("ab.title")
        .position(left, y + 24.0f).size(w, 34.0f)
        .text("关于作者").fontSize(24.0f).lineHeight(30.0f).fontWeight(800)
        .color(textPrimary()).build();
    ui.text("ab.sub")
        .position(left, y + 60.0f).size(w, 22.0f)
        .text("联系方式已内置固化 · 赞赏码随程序加密分发")
        .fontSize(14.0f).lineHeight(20.0f).color(textMuted()).build();

    // ---------------- 作者卡
    const float authorH = 176.0f;
    const float authorY = y + 100.0f;
    card(ui, "ab.author", left, authorY, w, authorH, cardColor(), 0.7f);

    // 头像：有图用图，没有就用主题色圆形占位
    const float avSize = 96.0f;
    const float avX = left + 24.0f;
    const float avY = authorY + 24.0f;
    const std::string avatarFile = filled(a.avatar) ? backend::assets::pathForExternal(a.avatar)
                                                    : std::string();
    if (!avatarFile.empty()) {
        ui.image("ab.avatar")
            .position(avX, avY).size(avSize, avSize)
            .source(avatarFile)
            .radius(24.0f).contain().build();
    } else {
        // 没有头像时不再画字体小人，直接显示品牌图标，避免界面上出现两套图形语言。
        components::panel(ui, "ab.avatar.bg", theme())
            .position(avX, avY).size(avSize, avSize)
            .radius(24.0f)
            .color(components::theme::withOpacity(theme().primary, 0.20f))
            .border(1.0f, components::theme::withOpacity(theme().primary, 0.55f))
            .build();
        ui.image("ab.avatar.icon")
            .position(avX + 8.0f, avY + 8.0f).size(avSize - 16.0f, avSize - 16.0f)
            .source(backend::assets::pathForExternal("icon-about.png"))
            .radius(18.0f).contain().build();
    }

    const float textX = avX + avSize + 24.0f;
    const float btnW = 132.0f;
    const float textW = std::max(180.0f, w - (textX - left) - btnW - 48.0f);

    ui.text("ab.name")
        .position(textX, authorY + 24.0f).size(textW, 30.0f)
        .text(a.name).fontSize(22.0f).lineHeight(28.0f).fontWeight(800)
        .color(textPrimary()).build();
    ui.text("ab.role")
        .position(textX, authorY + 56.0f).size(textW, 22.0f)
        .text(a.role).fontSize(14.0f).lineHeight(20.0f)
        .color(textMuted()).build();

    const std::string contact =
        "QQ " + orDash(a.qq) + "    ·    群 " + orDash(a.qqGroup) + "（" + a.groupName +
        "）    ·    " + orDash(a.email);
    ui.text("ab.contact")
        .position(textX, authorY + 84.0f).size(textW, 20.0f)
        .text(clip(contact, textW, 12.5f)).fontSize(12.5f).lineHeight(18.0f)
        .color(textMuted()).build();

    if (!a.slogan.empty()) {
        ui.text("ab.slogan")
            .position(textX, authorY + 110.0f).size(textW, 20.0f)
            .text("“" + a.slogan + "”").fontSize(12.5f).lineHeight(18.0f)
            .color(textFaint()).build();
    }

    // 主页固定为 GitHub 仓库，项目按钮也指向同一地址
    const std::string homeLabel = "GitHub ";
    const std::string homeLine = homeLabel + orDash(a.homepage);
    ui.text("ab.home")
        .position(textX, authorY + 136.0f).size(textW, 20.0f)
        .text(clip(homeLine, textW, 12.0f))
        .fontSize(12.0f).lineHeight(17.0f).color(textFaint()).build();

    // 作者卡右侧三个小按钮
    const float abx = left + w - 24.0f - btnW;
    ui_button(ui, "ab.btn.home", "打开 GitHub 主页", 0xF0AC, abx, authorY + 22.0f, btnW, 34.0f,
              false, filled(a.homepage),
              [url = a.homepage] {
                  if (url.empty() || url == "未填写") return;
                  actionOpenUrl(url);
                  logLine(LOG_INFO, "打开 GitHub 主页 · " + url);
              });
    // 联系按钮：有群号复制群号，否则复制 QQ 号（两者都没有则置灰）
    const bool hasGroup = filled(a.qqGroup);
    const bool hasQq = filled(a.qq);
    const std::string copyLabel = hasGroup ? "复制 QQ 群号" : (hasQq ? "复制 QQ 号" : "复制联系方式");
    const std::string copyValue = hasGroup ? a.qqGroup : a.qq;
    ui_button(ui, "ab.btn.copygroup", copyLabel, 0xF0C5, abx, authorY + 64.0f, btnW, 34.0f,
              false, hasGroup || hasQq,
              [value = copyValue, isGroup = hasGroup] {
                  if (backend::copyTextToClipboard(value)) {
                      logLine(LOG_SUCC, std::string(isGroup ? "复制 QQ 群号 · " : "复制 QQ 号 · ") +
                                            value + " · 完成");
                  } else {
                      logLine(LOG_WARN, "复制联系方式 · 失败 · 原因：剪贴板被占用，请手动选择文本");
                  }
              });
    // 作者联系方式已编译期固化：不再提供 author.ini 编辑入口

    // ---------------- 支持作者
    float cursor = authorY + authorH + 20.0f;
    ui.text("ab.donate.title")
        .position(left, cursor).size(w, 22.0f)
        .text("支持作者").fontSize(16.0f).lineHeight(22.0f).fontWeight(740)
        .color(textPrimary()).build();
    ui.text("ab.donate.note")
        .position(left, cursor + 22.0f).size(w, 20.0f)
        .text(a.donateNote).fontSize(12.5f).lineHeight(18.0f)
        .color(textFaint()).build();
    cursor += 48.0f;

    const float btnH = 44.0f;
    const float tileGap = 16.0f;
    const float tileW = (w - tileGap * 2.0f) / 3.0f;
    // 剩余高度在「赞赏卡 / 项目信息卡 / 底部按钮」之间分配
    const float reserve = 180.0f + 16.0f + btnH + 14.0f;
    const float tileH = std::clamp(bottom - cursor - reserve, 170.0f, 240.0f);

    // 点卡片 = 在应用内把赞赏码放大，方便手机直接扫。
    // 以前是 ShellExecuteW 调系统看图软件，既打断操作又要多开一个窗口。
    supportTile(ui, "ab.tile.alipay", "支付宝赞赏", a.alipay,
                "点卡片放大扫码",
                left, cursor, tileW, tileH, 0xF029,
                [alipay = a.alipay] {
                    if (backend::assets::exists(alipay)) {
                        state().popup = Popup::ZoomAlipay;
                        logLine(LOG_INFO, "赞赏码 · 支付宝 · 放大显示");
                    } else {
                        logLine(LOG_WARN, "赞赏码 · 支付宝 · 缺失 · 原因：资源包里没有 " + alipay);
                    }
                });

    supportTile(ui, "ab.tile.wechat", "微信赞赏", a.wechat,
                "点卡片放大扫码",
                left + tileW + tileGap, cursor, tileW, tileH, 0xF029,
                [wechat = a.wechat] {
                    if (backend::assets::exists(wechat)) {
                        state().popup = Popup::ZoomWechat;
                        logLine(LOG_INFO, "赞赏码 · 微信 · 放大显示");
                    } else {
                        logLine(LOG_WARN, "赞赏码 · 微信 · 缺失 · 原因：资源包里没有 " + wechat);
                    }
                });

    // 第三块：其它支持方式
    {
        const float tx = left + (tileW + tileGap) * 2.0f;
        card(ui, "ab.tile.other.card", tx, cursor, tileW, tileH, mutedCardColor(), 0.6f, 14.0f);
        ui.text("ab.tile.other.title")
            .position(tx + 16.0f, cursor + 14.0f).size(tileW - 32.0f, 20.0f)
            .text("其它支持方式").fontSize(14.0f).lineHeight(20.0f).fontWeight(740)
            .color(textPrimary()).build();

        const std::string ways =
            "· 在群里反馈 bug，比私聊更快\n"
            "· 提 Issue 时附上 logs\\ 里的日志\n"
            "· 把工具分享给同样在折腾的朋友\n"
            "· 给项目点个 Star 也是支持";
        ui.text("ab.tile.other.ways")
            .position(tx + 16.0f, cursor + 44.0f).size(tileW - 32.0f, tileH - 110.0f)
            .text(ways).fontSize(12.5f).lineHeight(22.0f).wrap(true)
            .color(textMuted()).build();

        ui_button(ui, "ab.tile.other.btn", "打开 GitHub 仓库", 0xF0C1,
                  tx + 16.0f, cursor + tileH - 50.0f, tileW - 32.0f, 34.0f, false,
                  filled(a.project),
                  [url = a.project] {
                      if (url.empty() || url == "未填写") return;
                      actionOpenUrl(url);
                      logLine(LOG_INFO, "打开 GitHub 仓库 · " + url);
                  });
    }

    cursor += tileH + 16.0f;

    // ---------------- 项目信息
    const float infoH = std::max(182.0f, bottom - cursor - btnH - 14.0f);
    card(ui, "ab.info.card", left, cursor, w, infoH, mutedCardColor(), 0.55f);

    ui.text("ab.info.title")
        .position(left + 24.0f, cursor + 16.0f).size(w - 48.0f, 20.0f)
        .text("项目信息").fontSize(14.0f).lineHeight(20.0f).fontWeight(740)
        .color(textPrimary()).build();

    const float kvX = left + 24.0f;
    const float kvW = w - 48.0f;
    kvRow(ui, "ab.info.ver", "程序版本", "Min RooT v" + a.version, kvX,
          cursor + 48.0f, kvW, textMuted());
    kvRow(ui, "ab.info.build", "构建日期", orDash(a.build), kvX, cursor + 72.0f, kvW, textMuted());
    kvRow(ui, "ab.info.ui", "界面框架", "EUI-NEO（C++17 · GLFW + OpenGL · Apache-2.0）", kvX,
          cursor + 96.0f, kvW, textMuted());
    kvRow(ui, "ab.info.root", "提权工具", "Neo10-Root v2.1 正式版（GhostLock + KernelSU late-load）",
          kvX, cursor + 120.0f, kvW, textMuted());
    kvRow(ui, "ab.info.license", "使用许可", a.license, kvX, cursor + 144.0f, kvW,
          components::theme::withOpacity(theme().primary, 1.0f));

    cursor += infoH + 14.0f;

    // ---------------- 底部按钮行
    const float bGap = 12.0f;
    const float bW = (w - bGap * 3.0f) / 4.0f;
    const float by = std::min(cursor, bottom - btnH);
    ui_button(ui, "ab.btn.home2", "打开 GitHub 主页", 0xF0AC, left, by, bW, btnH, true,
              filled(a.homepage),
              [url = a.homepage] {
                  if (url.empty() || url == "未填写") return;
                  actionOpenUrl(url);
              });
    ui_button(ui, "ab.btn.qq", "复制 QQ 号", 0xF0C5, left + bW + bGap, by, bW, btnH, false,
              filled(a.qq),
              [value = a.qq] {
                  if (backend::copyTextToClipboard(value)) {
                      logLine(LOG_SUCC, "复制 QQ 号 · " + value + " · 完成");
                  } else {
                      logLine(LOG_WARN, "复制 QQ 号 · 失败 · 原因：剪贴板被占用，请手动选择文本");
                  }
              });
    ui_button(ui, "ab.btn.donateDir", "打开赞赏码目录", 0xF07B,
              left + (bW + bGap) * 2.0f, by, bW, btnH, false, true,
              [] {
                  const std::string dir = backend::assets::dirOf("about");
                  if (backend::fileExists(dir)) {
                      backend::openFolder(dir);
                      logLine(LOG_INFO, "打开目录 · 资源缓存 · 完成");
                  } else {
                      logLine(LOG_WARN, "打开赞赏码目录 · 跳过 · 原因：资源已封装进加密包，无明文目录");
                  }
              });
    ui_button(ui, "ab.btn.reload", "重新读取配置", 0xF01E,
              left + (bW + bGap) * 3.0f, by, bW, btnH, false, true,
              [] {
                  backend::ensureAuthorIni();
                  logLine(LOG_SUCC, "重新读取 author.ini · 完成（页面下次重绘生效）");
              });
}

} // namespace app
