#pragma once
// 主页「快捷工具」与「快捷重启 / 保存设备信息」需要的后端能力。
// 全部走 adb shell，失败一律写 log 并返回 false，调用方只管展示那一行日志。
#include "backend/managers.h"

#include <functional>
#include <string>
#include <vector>

namespace backend {

// ---- 无线调试（adb tcpip + adb connect）----

struct WirelessResult {
    bool ok = false;
    std::string serial;   // 连上之后 adb 认的序列号，形如 192.168.1.20:5555
    std::string ip;       // 本次用的 IP
    int port = 5555;
    std::string message;  // 给日志面板的一行话
};

// 取设备当前局域网 IP：优先 wlan0 地址，退化到 `ip route` 的 src，再退化到 hostname -I。
std::string deviceIpAddress(const std::string& serial);

// 从本机看 <ip>:<port> 通不通。用 Winsock 直连，带毫秒级超时，
// 目的是在 adb tcpip 之前就把「手机和电脑不在同一网段」这种必然失败挡掉，
// 不要等 adb connect 自己超时（那会把界面卡住两分钟）。
// 返回 true 表示三次握手成功；failReason 非空时是可以直接打到日志面板的原因。
bool probeTcpReachable(const std::string& ip, int port, int timeoutMs, std::string& failReason);

// 万能无线调试：
//   1. 已是无线连接 → 直接返回当前序列号；
//   2. 否则 adb tcpip <port>（会让 adbd 在 TCP 上重开，USB 通道保持）→ 轮询确认可连；
//   3. adb connect <ip>:<port>（adb 找不到 IP 时用 lanIp 覆盖）。
bool enableWirelessDebug(const std::string& serial, int port, const std::string& lanIp,
                         WirelessResult& result);

// 断开无线并切回 USB：adb disconnect <serial>，可选 adb usb。
bool disableWirelessDebug(const std::string& serial, std::string& log);

// ---- 切换 A/B 槽位 ----

struct SlotResult {
    std::string current;   // _a / _b
    std::string other;     // 另一槽
    std::string active;    // A / B（来自 ro.boot.slot_suffix）
    bool bootControlOk = false;   // bootctl 可用
    bool setActiveOk = false;     // set-active 成功
    std::string message;
};

// 读当前槽位；active 参数为 true 时顺带 `bootctl set-active <other>`（下次开机生效）。
bool switchSlot(const std::string& serial, bool active, SlotResult& result);

// ---- USB 3.0 兼容补丁 ----

// USB2 会把 adb 限速在 ~35 MB/s；切到 USB3 需要「传输侧 + 设备侧」一起确认。
struct Usb3Result {
    bool ok = false;
    bool adbUsb2 = false;     // getprop sys.usb.config 含 adb,usb2
    std::string current;      // 当前 sys.usb.config
    std::string message;
};

// checkOnly=true 只体检，不改任何东西；否则按「setprop 候选 → 仍不行提示手动改线/换口」推进。
bool usb3Compat(const std::string& serial, bool checkOnly, Usb3Result& result);

// ---- 一键保活 / 快捷动作 ----

// 把设备屏幕常亮打开（svc power stayon true），失败退回 settings 里的 stay_on_while_plugged_in。
bool keepScreenOn(const std::string& serial, bool on, std::string& log);

// 清理「adb 日志 / adb 缓存 / 设备端 /sdcard 上的本工具临时文件」，返回清掉的文件数。
int cleanTempFiles(const std::string& serial, std::string& log);

// ---- 多设备 ----

struct SerialItem {
    std::string serial;
    std::string state;    // device / offline / unauthorized
    std::string model;    // 可能取不到
};

// 带状态的设备列表（下拉里能看出哪台没授权）
std::vector<SerialItem> listDeviceSerialItems();

} // namespace backend
