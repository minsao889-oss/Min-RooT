@echo off
set "VSB=C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools"
call "%VSB%\VC\Auxiliary\Build\vcvars64.bat" >nul
set "CMAKE=%VSB%\Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe"
if not exist "C:\srtbuild" mkdir "C:\srtbuild"
"%CMAKE%" -S "E:\下载\SiliconRootTool-EUI\交付\源码工程\EuiRoot" -B "C:\srtbuild" -G "NMake Makefiles" -DCMAKE_BUILD_TYPE=Release
