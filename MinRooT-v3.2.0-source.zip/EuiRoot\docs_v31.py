# -*- coding: utf-8 -*-
"""把 v3.1 的文档改动写进 EuiRoot 工作区那份 README.md / 开发全记录.md。

为什么要有这个脚本：
    deliver.py 每次都从工作区（HERE）把 README.md / 开发全记录.md 复制到交付目录，
    所以在交付目录里改文档，下次打包必定被覆盖回旧版。文档的**唯一真源是工作区这份**，
    要改就改这里。本脚本幂等：已经打过补丁的文件再跑一遍不会重复插入。

用法：
    python docs_v31.py          # 给工作区文档打 v3.1 补丁
    python docs_v31.py --check  # 只检查当前状态
"""
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
README = os.path.join(HERE, "README.md")
RECORD = os.path.join(HERE, "开发全记录.md")


def load(path):
    with io.open(path, encoding="utf-8") as f:
        return f.read()


def save(path, text):
    with io.open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def patch_readme(t):
    """README.md 的 v3.1 改动。每一条都先查后改，重复跑安全。"""
    if t.startswith("# Silicon Root Tool v3.0"):
        t = t.replace("# Silicon Root Tool v3.0（多文件版）",
                      "# Silicon Root Tool v3.1（多文件版）", 1)

    anchor = "收起后页面自动重新排版，省下来的高度不会留白。"
    if anchor in t and "**v3.1 重点**" not in t:
        t = t.replace(anchor, anchor + "\n\n"
                      "**v3.1 重点**：管理器页新增 **检查更新** —— 一次点出四个管理器哪些有新版，"
                      "弹确认框逐条列「现版本 → 上游版本」，确认后自动下载 + 覆盖安装。"
                      "顺带修掉了自动下载卡死、日志只剩一句「请求 ghproxy.net 失败」的老问题。", 1)

    t = t.replace("主程序（2.14 MB，静态链接 MSVC 运行时）",
                  "主程序（2.17 MB，静态链接 MSVC 运行时）")
    t = t.replace("产物：`build/SiliconRootTool.exe`（约 2.14 MB",
                  "产物：`build/SiliconRootTool.exe`（约 2.17 MB")
    t = t.replace("version=3.0.0", "version=3.1.0")
    t = t.replace("### 性能与稳定性（v2.4 / v2.5 / v2.8 / v3.0）",
                  "### 性能与稳定性（v2.4 / v2.5 / v2.8 / v3.0 / v3.1）")

    # 新增章节：管理器检查更新
    new_sec = """### 管理器检查更新（v3.1）

管理器页右下角「检查更新」按钮，点一次做三件事：

| 步骤 | 做什么 |
|---|---|
| 检测 | 对四个管理器分别查「手机已装版本」和「GitHub 上游最新 tag」 |
| 弹窗 | 有可更新项时弹确认框，正文逐条列 `名称 现版本 → 上游版本`，可以点「取消」 |
| 更新 | 确认后串行执行「下载最新安装包 → `adb install -r -d` 覆盖安装」，每步都写日志 |

三条要注意：

- **未安装的不算「更新」**：只报「未安装（上游最新 X）」，不进批量更新列表；
- **不再悄悄动**：v3.0 之前只有「安装包缺失」时才去下载，现在有新版会明确问一句；
- **更新期间会断 root**：覆盖安装后临时 root 需要回提权页重新打一次。

上游版本号来自 `GET https://api.github.com/repos/<owner>/<repo>/releases/latest` 的 `tag_name`，
去掉 `v` 前缀与非数字尾巴后再逐段比较，`3.4.2-spoofed` 这种非规范 tag 会退化成字符串比较。

### 安卓投屏（scrcpy）"""
    if "### 管理器检查更新（v3.1）" not in t:
        t = t.replace("### 安卓投屏（scrcpy）", new_sec, 1)

    # 性能与稳定性补三条
    anchor2 = ("- **日志三件套不再抢文件句柄（v3.0）**：清屏只动内存，导出用独立读写流复制一份，\n"
               "  后台写 `run-*.log` 的线程不受影响。")
    add2 = """- **更新检测不动设备（v3.1）**：检查更新只发两件只读请求（GitHub API + 本机 `pm list packages`），
  不装不卸不改任何东西；确认后才走下载与安装。
- **下载失败会给出全部通道的原因（v3.1）**：四档镜像（直连 / gh-proxy / ghfast / ghproxy.net）各自的
  错误与耗时都会拼进同一条日志，不再只剩最后一档的一句「请求 ghproxy.net 失败」。
- **安装包与设备检查解耦（v3.1）**：设备没连时安装会取消，但**已下载的安装包保留**，
  接上手机直接点「安装所选」即可，不用重下一遍。"""
    if anchor2 in t and "更新检测不动设备（v3.1）" not in t:
        t = t.replace(anchor2, anchor2 + "\n" + add2, 1)

    # 验收要点补一条
    anchor3 = ("- 日志三件套：清屏后 `logs\\run-*.log` 仍在增长；导出生成 `logs\\export-*.log` 并打开目录；\n"
               "  收起后标题条 44 px、点「展开」恢复且自动滚到最新一行；")
    add3 = ("\n- 管理器检查更新：点一次出四行结果（未安装 / 可更新 / 已是最新），有更新时弹确认框逐条列版本差；\n"
            "  点「取消」后无任何下载；删空 `%LOCALAPPDATA%\\SiliconRootTool\\apk\\*` 后逐个装能自动下载就位；")
    if anchor3 in t and "管理器检查更新：点一次出四行结果" not in t:
        t = t.replace(anchor3, anchor3 + add3, 1)

    return t


def patch_record(t):
    """开发全记录.md 的 v3.1 改动。"""
    t = t.replace("> 记录时间：2026-10-20 ｜ 当前版本：**v3.0** ｜ 目标系统：Windows 10/11 64 位",
                  "> 记录时间：2026-10-20 ｜ 当前版本：**v3.1** ｜ 目标系统：Windows 10/11 64 位", 1)

    # 时间线补 v3.1 一行
    tl3 = ("| **v3.0** | **日志面板三件套：清屏 / 导出 / 收起**（提权页与管理器页共用 `composeLogPanel`）；"
           "收起后面板只留 44px 标题条、空间回流页面重新排版；版本号升 3.0.0 |")
    tl31 = (tl3 + "\n"
            "| **v3.1** | **管理器更新检测与一键更新**（`fetchLatestRelease` + `versionNewer` + "
            "`Popup::ConfirmUpdate` + `actionApplyUpdates`）；修 `WinHttpSendRequest` 长度参数 `0x57`、"
            "`Accept:` 前缀丢失、`pickAssetUrl` 撞上 `-spoofed` 坏资产、多档下载只留最后一档原因；"
            "下载与设备检查解耦；版本号升 3.1.0 |")
    if tl3 in t and "| **v3.1** |" not in t:
        t = t.replace(tl3, tl31, 1)

    # 8.5 新增章节（原 8.5 投屏 → 8.6，8.6 残留实例 → 8.7，8.7 真打穿 → 8.8）
    new_sec = """### 8.5 管理器更新检测与一键更新（v3.1）

v3.0 之前管理器页只有「安装所选」，安装包缺失时才悄悄去 GitHub 拉一份，**从不告诉用户上游有没有新版**。
v3.1 补上完整的「检测 → 确认 → 更新」链路，并在同一条链路上顺手修掉了自动下载卡死的老问题。

#### 检测链路

点「检查更新」→ `actionCheckUpdates()`（`app.cpp`）：

1. `updateChecking` 置位防重入（按钮同时变「正在检查…」）；
2. `runBlocking()` 包住整轮，UI 不会僵；
3. 对四个管理器逐个跑两件事：
   - `checkManager(info)` → 手机已装与否 + 已装版本号；
   - `fetchLatestRelease(info, tag, apkUrl, err)` → `GET https://api.github.com/repos/<owner/repo>/releases/latest`
     取 `tag_name`，再过 `cleanVersion()` 去掉 `v` 前缀与非数字尾巴；
4. 判定 `hasUpdate = versionNewer(tag, installedVersion) || versionNewer(tag, localVersion)`；
   **未安装的强制 `hasUpdate = false`**（没装就不叫「更新」，日志里只报「未安装（上游最新 X）」）；
5. 汇总写进 `state().updates`，`updateNote` 记「最近检查 HH:MM:SS · N 项可更新」；
6. 真有可更新的就弹 `Popup::ConfirmUpdate`。

`parseVersion()` 按 `.` 切段累积整数，`versionNewer()` 逐段比较、短的一侧补 0，
任一方解析为空时退化成字符串不等即视为更新 —— 上游偶尔会出 `3.4.2-spoofed` 这类非规范 tag。

#### 确认弹窗

`main.cpp` 的 `dlg.update`（`460×230`）：标题「发现 N 个管理器可更新」，正文逐条列
`· <名称>   <现版本> → <上游版本>`，尾部固定一句
「更新会先下载最新安装包，再 `adb install -r -d` 覆盖安装。结束后临时 root 可能需要重新执行一次提权。」
多选时主按钮文案是「全部更新」，单选是「立即更新」。

#### 更新执行

`actionApplyUpdates(keys)` 逐 key 串行：`downloadApk()` → `installManager()`，每步都写日志，
最后汇总「更新结束：成功 N，失败 M」。串行是刻意的 —— 四个 `adb install` 并发会互相抢 adb server。

#### 顺带修掉的三个真问题

**（1）`pickAssetUrl` 挑到了 `-spoofed` 资产。**
KernelSU Next v3.4.2 的 release 同时挂了
`KernelSU_Next_v3.4.2_33355-release.apk` 和 `KernelSU_Next_v3.4.2-spoofed_33355-release.apk`。
按前缀 `KernelSU_Next_v` 匹配会先撞上 spoofed 那条，而**那条在服务端是坏的**
（.NET 直连 21 秒后报「无法连接到远程服务器」），整次下载跟着失败。
`download.cpp` 的 `pickAssetUrl()` 加了一条排除：

```cpp
if (lowered.find("spoofed") != std::string::npos) continue;
```

spoofed 是给特定场景替换包名用的变体，不是常规安装包。

**（2）下载失败时日志只剩最后一档的原因。**
`downloadToFile()` 四档镜像轮完只留 `lastError`，而 ghproxy.net 对资产固定失败，
把直连与 WinINet 的真实诊断信息全盖掉，日志里永远只有一句「请求 ghproxy.net 失败」。
改成 `allReasons` 累积，每档附耗时：

```cpp
auto noteReason = [&allReasons](const std::string& r) { ... };
lastError = std::string(mirrorLabel(mirror)) + "：" + stepErr + "（" +
            std::to_string(GetTickCount() - stepStart) + " ms）";
```

**（3）设备没连时整个安装被取消，安装包已经下好了也不留。**
`actionApplyUpdates` 原先先查设备再下载，没设备直接 return。改成**下载与设备检查解耦**：
先把包装就位，最后再判设备；没设备就给
`[ERROR] 未连接设备，安装取消（安装包已就绪，接上手机再点「安装所选」即可）`。
这样用户刷机、换机的空档里也能先把四个包备齐。

#### v3.1 实测（四管理器全部下载成功）

| 管理器 | 文件 | 大小 | 耗时 |
|---|---|---|---|
| KernelSU | `KernelSU_v3.3.1.apk` | 13,637,206 | 2 s |
| KernelSU Next | `KernelSU-Next_v3.4.2.apk` | 16,682,167 | 8 s |
| SukiSU | `SukiSU_v4.2.1.apk` | 17,173,205 | 4 s |
| 7kimi SU | `7kimisu_v2.30.apk` | 13,349,961 | 2 s |

日志样本：

```text
[STEP]    正在安装 KernelSU…
[STEP]    内置安装包缺失，转为在线下载 KernelSU …
[DEBUG]   下载完成：C:\\Users\\<user>\\AppData\\Local\\SiliconRootTool\\apk\\KernelSU_v3.3.1.apk
[SUCCESS] KernelSU 安装包已就绪，等待安装
[ERROR]   未连接设备，安装取消（安装包已就绪，接上手机再点「安装所选」即可）
```

检查更新的四行输出：

```text
[INFO] KernelSU：未安装（上游最新 3.3.1）
[INFO] KernelSU Next：未安装（上游最新 3.4.2）
[INFO] SukiSU：未安装（上游最新 4.2.1）
[INFO] 7kimi SU：未安装（上游最新 2.30）
```

### 8.6 投屏（scrcpy）"""
    if "### 8.5 管理器更新检测与一键更新（v3.1）" not in t:
        t = t.replace("### 8.5 投屏（scrcpy）", new_sec, 1)
        t = t.replace("### 8.6 残留实例清理", "### 8.7 残留实例清理", 1)
        t = t.replace("### 8.7 以「真打穿」为成功判据", "### 8.8 以「真打穿」为成功判据", 1)

    # 9.8 坑表
    pit44_tail = "| 44 | **导出再补一次 BOM**"
    idx = t.find(pit44_tail)
    if idx >= 0 and "### 9.8 网络与更新检测类（v3.1）" not in t:
        eol = t.find("\n", idx)
        pits = """\n\n### 9.8 网络与更新检测类（v3.1）

| # | 坑 | 现象 | 正确做法 |
|---|---|---|---|
| 45 | **`WinHttpSendRequest` 的两个长度参数填了真实字节数** | 返回 `0x57 ERROR_INVALID_PARAMETER`，所有 GitHub API 与资产请求全挂，日志里却显示成「DNS 解析失败」 | 带自定义 header 时 `dwHeadersLength` 与 `dwHeadersTotalLength` 都必须传 `(DWORD)-1`。矩阵实测：不带 header 传 0 可以；带 header 传 `len/len` 或 `len/0` 一律 err=87 |
| 46 | **拼接 header 时丢了 `Accept: ` 前缀** | 服务端收到一整行怪东西，API 返回 4xx，被上层误报成网络故障 | 用 `WINHTTP_ADDREQ_FLAG_ADD` 时每一条都要写完整的 `Name: Value`，`Accept` 与 `application/vnd.github+json` 之间必须有冒号空格 |
| 47 | **「自己解析 IP 再 `WinHttpConnect`」会丢 SNI** | 直连 https 握手必然失败，而同一域名用浏览器 / curl 正常 | 连接目标就用域名本身，交给 WinHTTP 做 SNI。想修 DNS 应该换解析器，不是换连接主机名 |
| 48 | **`WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY` 在没有 WPAD 的机器上留死会话** | 首次请求就超时，删掉代理设置也不改善 | 有 `ieProxyName()` 就 `NAMED_PROXY`，否则明确 `NO_PROXY`，别用 AUTOMATIC |
| 49 | **`pickAssetUrl` 按前缀匹配撞上 `-spoofed` 变体** | KernelSU Next 每次都下载失败，服务端那条资产本身是坏的（.NET 直连 21 s 后「无法连接到远程服务器」） | 匹配时排除：`if (lowered.find("spoofed") != npos) continue;`。这类变体是换包名用的，不是安装包 |
| 50 | **多档下载只保留 `lastError`** | 四档轮完日志只剩「请求 ghproxy.net 失败」，直连与 WinINet 的真实原因全被覆盖，排障时看不到主线 | 用 `allReasons` 累积每档原因，并附每档耗时 `（NNN ms）` |
| 51 | **确认框与其它弹窗互相抢 `Popup` 状态** | 对话框关了但 `popup` 没复位，下一次点击被吞掉 | `onOpenChange(false)` 与 `onSecondary` 都要显式把 `popup` 置 `None` |
| 52 | **更新时四个 `adb install` 并发** | adb server 互相抢设备，随机三个失败 | `actionApplyUpdates` 串行执行，每步之间都有日志，失败不中断后续项 |
"""
        t = t[:eol] + pits + t[eol:]

    # 11.3 自测清单
    ck = ("- [ ] 窗口拉窄到 1000px 以下后「收起」，标题条上的「展开」仍然可点（v3.0，宽度阈值 420px）")
    ck_add = """\n- [ ] 点「检查更新」→ 四管理器各出一行「未安装（上游最新 X）」或「可更新 X → Y」（v3.1）
- [ ] 有可更新时弹确认框，标题「发现 N 个管理器可更新」，正文逐条 `名称 现版本 → 上游版本`（v3.1）
- [ ] 确认框点「取消」后无任何下载、`popup` 复位，再点其它按钮正常（v3.1）
- [ ] 删空 `%LOCALAPPDATA%\\SiliconRootTool\\apk\\*` 后逐个「安装所选」→ 能自动下载并给出「安装包已就绪」（v3.1）
- [ ] 设备未连接时点「安装所选」→ 不卡界面，且已下载的安装包保留（v3.1）"""
    if ck in t and "点「检查更新」→ 四管理器各出一行" not in t:
        t = t.replace(ck, ck + ck_add, 1)

    return t


def main():
    check_only = "--check" in sys.argv
    for path, fn in ((README, patch_readme), (RECORD, patch_record)):
        if not os.path.exists(path):
            print("missing:", path)
            continue
        before = load(path)
        after = fn(before)
        changed = after != before
        if check_only:
            print("%-24s %s  (%d bytes)" % (os.path.basename(path),
                                            "PATCHED" if changed else "ok",
                                            len(after.encode("utf-8"))))
            continue
        if changed:
            save(path, after)
            print("patched %-24s -> %d bytes" % (os.path.basename(path),
                                                 len(after.encode("utf-8"))))
        else:
            print("already ok %-20s (%d bytes)" % (os.path.basename(path),
                                                   len(after.encode("utf-8"))))


if __name__ == "__main__":
    main()
