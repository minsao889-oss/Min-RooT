#include "app.h"
#include "ui_toggle.h"

#include <algorithm>

namespace app {

// ===== 液态玻璃材质参数（对照 AndroidLiquidGlass 2.0.0-alpha03）=====
// LiquidButton: vibrancy(饱和 1.5) + blur(2dp) + lens(24dp, 12dp) + Highlight.Ambient
// LiquidToggle 旋钮: blur(8dp) + lens(10dp,5dp) + Shadow(4dp) + InnerShadow(4dp) + Ambient 高光
// 高光用 Ambient 语义：上方亮白、下方用暗色第二色，形成玻璃厚边。

namespace {
// Ambient 高光的两端色：顶部近白，底部偏冷灰（压暗）
eui::Color ambientTop(bool dark) {
    return dark ? eui::Color{1.0f, 1.0f, 1.0f, 1.0f} : eui::Color{1.0f, 1.0f, 1.0f, 1.0f};
}
eui::Color ambientBottom(bool dark) {
    return dark ? eui::Color{0.62f, 0.66f, 0.74f, 1.0f} : eui::Color{0.58f, 0.60f, 0.66f, 1.0f};
}
} // namespace

eui::GlassStyle glassSurface(float radius, float blur, float lensAmount) {
    const components::theme::ThemeColorTokens& tokens = theme();
    const bool dark = tokens.dark;

    eui::GlassStyle glass;
    glass.enabled = true;
    glass.radius = radius;
    glass.blur = blur;
    glass.saturation = 1.5f;          // ColorFilter.colorControls(saturation = 1.5f)
    glass.vibrancy = true;
    glass.lensAmount = lensAmount;
    glass.lensHeight = std::max(blur * 2.0f, lensAmount * 1.6f);
    glass.chromaticAberration = lensAmount > 0.0f ? 1.0f : 0.0f;  // chromaticAberration = true

    // 外阴影：Shape 模糊后按 offset 偏移挖洞 —— 参考 Shadow(radius = 4dp..24dp, color = Black 0.05..0.1)
    glass.castShadow = true;
    glass.shadowRadius = dark ? 14.0f : 10.0f;
    glass.shadowOffset = {0.0f, dark ? 5.0f : 4.0f};
    glass.shadowSpread = 0.0f;
    glass.shadowColor = dark ? eui::Color{0.0f, 0.0f, 0.0f, 0.55f}
                             : eui::Color{0.05f, 0.09f, 0.16f, 0.22f};
    glass.shadowAlpha = 1.0f;

    // 内阴影：形状内填色、按 offset 挖掉偏移形状、模糊后裁回形状内
    glass.innerShadow = true;
    glass.innerShadowRadius = dark ? 7.0f : 6.0f;
    glass.innerShadowOffset = {0.0f, dark ? 3.0f : 2.0f};
    glass.innerShadowAlpha = dark ? 0.42f : 0.34f;
    glass.innerShadowColor = dark ? eui::Color{0.0f, 0.0f, 0.0f, 1.0f}
                                  : eui::Color{0.12f, 0.16f, 0.24f, 1.0f};

    // 高光：Highlight.Ambient(intensity) —— 宽度 0.5dp，内侧半条边
    glass.highlight = true;
    glass.highlightWidth = 1.8f;
    glass.highlightBlur = 1.1f;
    glass.highlightAlpha = dark ? 1.0f : 1.0f;
    glass.highlightColor = ambientTop(dark);
    glass.highlightColor2 = ambientBottom(dark);

    glass.surfaceColor = dark ? eui::Color{1.0f, 1.0f, 1.0f, 0.05f}
                             : eui::Color{1.0f, 1.0f, 1.0f, 0.18f};
    return glass;
}

eui::GlassStyle glassButton(bool primary, bool enabled) {
    eui::GlassStyle glass = glassSurface(-1.0f, 3.0f, 12.0f);
    if (!enabled) {
        // 禁用：保留玻璃质感但极度压平（不折射、不加高光）
        glass.blur = 0.0f;
        glass.lensAmount = 0.0f;
        glass.lensHeight = 0.0f;
        glass.chromaticAberration = 0.0f;
        glass.saturation = 1.0f;
        glass.vibrancy = false;
        glass.castShadow = false;
        glass.innerShadow = false;
        glass.highlight = false;
        glass.surfaceColor = components::theme::withOpacity(theme().surfaceHover, 0.55f);
        return glass;
    }
    if (primary) {
        // 主按钮：染成主色的玻璃（对应 LiquidButton 的 tint + surfaceColor）
        glass.surfaceColor = components::theme::withOpacity(theme().primary, 0.72f);
        glass.innerShadowAlpha = 0.40f;
        glass.highlightAlpha = 1.0f;
        glass.shadowColor = components::theme::withOpacity(theme().primary, 0.30f);
        glass.shadowRadius = 16.0f;
        glass.shadowOffset = {0.0f, 6.0f};
    } else {
        // 次按钮：白玻璃，对应 LiquidButton(surfaceColor = White 0.3f)
        glass.surfaceColor = theme().dark ? eui::Color{1.0f, 1.0f, 1.0f, 0.16f}
                                          : eui::Color{1.0f, 1.0f, 1.0f, 0.62f};
        glass.innerShadowAlpha = theme().dark ? 0.38f : 0.28f;
    }
    return glass;
}

eui::GlassStyle glassTrack(bool active, float radius) {
    eui::GlassStyle glass = glassSurface(radius, 8.0f, 10.0f);
    const bool light = !theme().dark;
    glass.chromaticAberration = 1.0f;
    glass.castShadow = false;
    glass.highlightWidth = 1.0f;
    glass.highlightAlpha = active ? 1.0f : 0.72f;
    glass.innerShadowRadius = 5.0f;
    glass.innerShadowAlpha = active ? 0.42f : 0.32f;
    glass.surfaceColor = active
        ? components::theme::withOpacity(theme().primary, 0.78f)
        : (light ? eui::Color{0.55f, 0.56f, 0.60f, 0.30f}
                 : eui::Color{0.62f, 0.64f, 0.70f, 0.26f});
    return glass;
}

eui::GlassStyle glassKnob() {
    // LiquidToggle 旋钮：blur(8dp) + lens(5dp,10dp,色散) + Shadow(4dp,0.05) + InnerShadow(4dp)
    eui::GlassStyle glass = glassSurface(-1.0f, 8.0f, 5.0f);
    glass.lensHeight = 10.0f;
    glass.chromaticAberration = 1.0f;
    glass.castShadow = true;
    glass.shadowRadius = 5.0f;
    glass.shadowOffset = {0.0f, 2.0f};
    glass.shadowColor = eui::Color{0.0f, 0.0f, 0.0f, 0.28f};
    glass.innerShadowRadius = 4.0f;
    glass.innerShadowAlpha = 0.26f;
    glass.highlightWidth = 1.0f;
    glass.highlightBlur = 0.6f;
    glass.highlightAlpha = 1.0f;
    glass.surfaceColor = theme().dark ? eui::Color{1.0f, 1.0f, 1.0f, 0.92f}
                                      : eui::Color{1.0f, 1.0f, 1.0f, 0.95f};
    return glass;
}

components::ButtonStyle ui_button_style(bool primary, bool enabled) {
    components::ButtonStyle style(theme(), primary);
    if (!enabled) {
        style.normal = components::theme::withOpacity(theme().surfaceHover,
                                                      theme().dark ? 0.55f : 0.45f);
        style.hover = style.normal;
        style.pressed = style.normal;
        // 禁用态文字要让「看得出这是按钮，只是点不动」。
        // 浅色主题底是近白，黑字给 0.32 会淡到几乎看不见（实测就是这样），
        // 所以浅色放到 0.46；深色底本来就暗，0.32 刚好，不必跟着加。
        style.text = components::theme::withOpacity(theme().text, theme().dark ? 0.32f : 0.46f);
        style.icon = style.text;
        style.border = {0.0f, {0.0f, 0.0f, 0.0f, 0.0f}};
        style.shadow = {false, {}, 0.0f, 0.0f, {}};
        style.pressScale = 1.0f;
    }

    // LIQUID_BUTTON：液态玻璃观感。
    // 注意：本工程 EUI-NEO 的 renderGlass() 分层玻璃在小尺寸控件上不产生像素
    // （命令/uniform 都对，屏幕无变化，实测见集成说明），所以这里用
    // 「半透明面 + 白色高光边 + 柔光投影 + 胶囊圆角」表达玻璃，而不是 .glass()。
    const bool light = !theme().dark;
    if (primary) {
        style.normal = components::theme::withAlpha(theme().primary, 0.90f);
        style.hover = components::theme::withAlpha(theme().primary, 0.96f);
        style.pressed = components::theme::withAlpha(theme().primary, 0.82f);
        style.text = {0.96f, 0.98f, 1.0f, 1.0f};
        style.icon = style.text;
        style.border = {1.2f, {1.0f, 1.0f, 1.0f, light ? 0.42f : 0.18f}};
        style.shadow = {true, {0.0f, 5.0f}, 16.0f, 0.0f, {0.0f, 0.0f, 0.0f, light ? 0.16f : 0.32f}};
    } else {
        style.normal = light ? eui::Color{1.0f, 1.0f, 1.0f, 0.34f} : eui::Color{1.0f, 1.0f, 1.0f, 0.10f};
        style.hover = light ? eui::Color{1.0f, 1.0f, 1.0f, 0.46f} : eui::Color{1.0f, 1.0f, 1.0f, 0.17f};
        style.pressed = light ? eui::Color{1.0f, 1.0f, 1.0f, 0.58f} : eui::Color{1.0f, 1.0f, 1.0f, 0.25f};
        style.text = light ? eui::Color{0.13f, 0.16f, 0.21f, 1.0f} : eui::Color{0.93f, 0.95f, 0.98f, 1.0f};
        style.icon = style.text;
        style.border = {1.2f, light ? eui::Color{1.0f, 1.0f, 1.0f, 0.68f} : eui::Color{1.0f, 1.0f, 1.0f, 0.20f}};
        style.shadow = {true, {0.0f, 3.0f}, 12.0f, 0.0f, {0.0f, 0.0f, 0.0f, light ? 0.10f : 0.26f}};
    }
    style.pressScale = 1.0f;
    return style;
}

// EXPT: real liquid-glass material for buttons (blur + SDF refraction + chromatic
// aberration + 45deg highlight + inner shadow + cast shadow).
eui::GlassStyle ui_button_glass(bool primary, bool enabled,
                                float press = 0.0f, float drag = 0.0f) {
    const bool light = !theme().dark;
    eui::GlassStyle g;
    g.enabled = enabled;
    g.blur = 10.0f;
    g.saturation = 1.5f;
    g.vibrancy = true;
    g.lensAmount = 14.0f + 12.0f * press + 10.0f * drag;
    g.lensHeight = 18.0f + 10.0f * press;
    g.chromaticAberration = 1.0f;
    const eui::Color accent = theme().primary;
    g.surfaceColor = primary
        ? eui::Color{accent.r, accent.g, accent.b, (light ? 0.60f : 0.52f) - 0.10f * press}
        : (light ? eui::Color{1.0f, 1.0f, 1.0f, 0.26f - 0.06f * press}
                 : eui::Color{1.0f, 1.0f, 1.0f, 0.12f - 0.03f * press});
    g.highlight = true;
    g.highlightWidth = 1.8f;
    g.highlightBlur = 0.45f;
    g.highlightAlpha = 1.0f;
    g.highlightColor = eui::Color{0.62f, 0.65f, 0.72f, 1.0f};
    g.highlightColor2 = eui::Color{1.0f, 1.0f, 1.0f, 1.0f};
    g.innerShadow = true;
    g.innerShadowRadius = 4.0f;
    g.innerShadowAlpha = 0.22f;
    g.castShadow = true;
    g.shadowRadius = light ? 12.0f : 16.0f;
    g.shadowOffset = {0.0f, light ? 4.0f : 6.0f};
    g.shadowColor = eui::Color{0.0f, 0.0f, 0.0f, light ? 0.18f : 0.30f};
    return g;
}

void ui_frost_overlay(eui::Ui& ui, const std::string& id, float x, float y, float w, float h,
                      float radius, bool primary, bool enabled) {
    if (!enabled || w <= 2.0f || h <= 2.0f) return;
    const bool light = !theme().dark;
    const float r = std::max(1.0f, radius);
    // 整面：极淡的冷白底，像隔着磨砂玻璃看到背景，而不是一层实心色块。
    ui.rect(id + ".frost")
        .position(x + 0.5f, y + 0.5f)
        .size(std::max(1.0f, w - 1.0f), std::max(1.0f, h - 1.0f))
        .radius(std::max(0.5f, r - 0.5f))
        .color(primary ? eui::Color{0.94f, 0.97f, 1.0f, light ? 0.14f : 0.08f}
                       : eui::Color{1.0f, 1.0f, 1.0f, light ? 0.24f : 0.10f})
        .border(1.0f, primary ? eui::Color{1.0f, 1.0f, 1.0f, light ? 0.34f : 0.16f}
                              : eui::Color{1.0f, 1.0f, 1.0f, light ? 0.64f : 0.20f})
        .build();
    // 底边一条很淡的冷灰内阴影，给玻璃增加厚度。
    ui.rect(id + ".edge")
        .position(x + r, y + h - 2.0f)
        .size(std::max(1.0f, w - r * 2.0f), 1.0f)
        .radius(0.5f)
        .color(eui::Color{0.06f, 0.09f, 0.14f, primary ? 0.10f : 0.06f})
        .build();
}

void ui_divider(eui::Ui& ui, const std::string& id, float x, float y, float w, bool accent) {
    if (w <= 2.0f) return;
    const bool light = !theme().dark;
    const eui::Color line = components::theme::withAlpha(theme().text, light ? 0.10f : 0.16f);
    ui.rect(id + ".glow")
        .position(x, y - 1.0f).size(w, 3.0f)
        .color(components::theme::withAlpha(theme().text, light ? 0.025f : 0.045f))
        .build();
    ui.rect(id).position(x, y).size(w, 1.0f).color(line).build();
    if (accent) {
        const float aw = std::min(30.0f, w);
        ui.rect(id + ".accent")
            .position(x, y - 1.0f).size(aw, 3.0f).radius(1.5f)
            .gradient(components::theme::withAlpha(theme().primary, 0.95f),
                      components::theme::withAlpha(theme().primary, 0.18f))
            .build();
    }
}

void ui_title_accent(eui::Ui& ui, const std::string& id, float x, float y, float h) {
    const float w = 4.0f;
    ui.rect(id + ".glow")
        .position(x - 1.5f, y - 1.0f).size(w + 3.0f, h + 2.0f).radius(3.0f)
        .color(components::theme::withAlpha(theme().primary, 0.10f)).build();
    ui.rect(id)
        .position(x, y).size(w, h).radius(2.0f)
        .gradient(components::theme::withAlpha(theme().primary, 1.0f),
                  components::theme::withAlpha(theme().primary, 0.55f))
        .build();
}

void ui_button(eui::Ui& ui, const std::string& id, const std::string& text,
               unsigned int icon, float x, float y, float w, float h,
               bool primary, bool enabled, std::function<void()> onClick) {
    // Capsule: radius = half height.
    components::ButtonStyle style = ui_button_style(primary, enabled);
    style.radius = h * 0.5f;
    // Scale is driven by our own spring, so disable the framework ease-out pressScale.
    style.pressScale = 1.0f;

    liquid::ButtonPressState& fx = ui.state<liquid::ButtonPressState>(id + ".pressfx");
    if (!fx.init) {
        fx.init = true;
        fx.scale.init(300.0f, 0.5f, 0.0f);
        fx.tx.init(300.0f, 0.62f, 0.0f);
        fx.ty.init(300.0f, 0.62f, 0.0f);
        fx.stretch.init(300.0f, 0.6f, 0.0f);
    }
    const float safeH = std::max(h, 1.0f);
    const float pressScale = 1.0f + (4.0f / safeH) * fx.scale.value;
    const float stretch = fx.stretch.value;
    // ButtonBuilder only supports uniform scale: press growth + drag stretch.
    const float scaleNow = pressScale + stretch;
    const float dragNorm = std::min(1.0f, stretch / (4.0f / safeH));

    components::button(ui, id)
        .position(x + fx.tx.value, y + fx.ty.value).size(w, h)
        .text(text).icon(icon)
        .fontSize(h >= 46.0f ? 15.0f : 14.0f)
        .iconSize(h >= 46.0f ? 17.0f : 15.0f)
        .style(style)
        .scale(scaleNow)
        .translate(-w * (scaleNow - 1.0f) * 0.5f, -h * (scaleNow - 1.0f) * 0.5f)
        .transition(motion())
        .build();

    // 磨砂层必须跟着按钮的拖拽位移和按压缩放一起走，否则拖动按钮时
    // 原位置会残留一块“空框”，看起来像多出来一个按钮。缩放以按钮中心为基准。
    const float frostCx = x + fx.tx.value + w * 0.5f;
    const float frostCy = y + fx.ty.value + h * 0.5f;
    ui_frost_overlay(ui, id, frostCx - w * scaleNow * 0.5f, frostCy - h * scaleNow * 0.5f,
                     w * scaleNow, h * scaleNow, h * 0.5f * scaleNow, primary, enabled);

    // Interaction layer on top: press / drag / release drive the springs; the click
    // callback is dispatched from here as well.
    auto hit = ui.rect(id + ".press")
        .position(x, y).size(w, h).radius(h * 0.5f)
        .color({0.0f, 0.0f, 0.0f, 0.0f})
        .interactive(enabled)
        .hoverColor(theme().dark ? eui::Color{1.0f, 1.0f, 1.0f, 0.05f}
                                 : eui::Color{1.0f, 1.0f, 1.0f, 0.12f})
        .pressedColor({0.0f, 0.0f, 0.0f, 0.0f})
        .onPress([&fx, w](const eui::PointerEvent&, const eui::Rect& bounds) {
            fx.scale.target = 1.0f;
            fx.dragSeeded = false;
            fx.dragDx = 0.0f;
            fx.dragDy = 0.0f;
            fx.tx.target = 0.0f;
            fx.ty.target = 0.0f;
            fx.stretch.target = 0.0f;
            fx.pixelScale = (w > 0.001f && bounds.width > 0.001f) ? bounds.width / w : 1.0f;
        })
        .onDrag([&fx, w, h](const core::dsl::DragEvent& event) {
            if (!fx.dragSeeded) {
                fx.dragSeeded = true;
                fx.drag0x = static_cast<float>(event.totalX);
                fx.drag0y = static_cast<float>(event.totalY);
            }
            const float inv = (fx.pixelScale > 0.0001f) ? (1.0f / fx.pixelScale) : 1.0f;
            fx.dragDx = (static_cast<float>(event.totalX) - fx.drag0x) * inv;
            fx.dragDy = (static_cast<float>(event.totalY) - fx.drag0y) * inv;
            const float maxOff = std::min(w, h);
            fx.tx.target = maxOff * std::tanh(0.05f * fx.dragDx / maxOff);
            fx.ty.target = maxOff * std::tanh(0.05f * fx.dragDy / maxOff);
            const float len = std::sqrt(fx.dragDx * fx.dragDx + fx.dragDy * fx.dragDy);
            if (len > 0.001f) {
                fx.dirX = fx.dragDx / len;
                fx.dirY = fx.dragDy / len;
            }
            const float maxDragScale = 4.0f / std::max(h, 1.0f);
            fx.stretch.target = maxDragScale * std::min(1.0f, len / std::max(w, h));
        })
        .onRelease([&fx](const eui::PointerEvent&, const eui::Rect&) {
            fx.scale.target = 0.0f;
            fx.tx.target = 0.0f;
            fx.ty.target = 0.0f;
            fx.stretch.target = 0.0f;
        });
    if (enabled && onClick) hit.onClick(std::move(onClick));
    if (!liquid::buttonPressSettled(fx)) {
        hit.onFrame([&fx](float dt) {
            fx.scale.advance(dt);
            fx.tx.advance(dt);
            fx.ty.advance(dt);
            fx.stretch.advance(dt);
        });
    }
    hit.build();
}

} // namespace app
