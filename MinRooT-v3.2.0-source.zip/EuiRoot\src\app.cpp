#include "app.h"

#include "backend/assets.h"
#include "backend/bundle.h"
#include "backend/home_tools.h"
#include "backend/process.h"
#include "backend/scrcpy.h"
#include "backend/workspace.h"

#include <windows.h>
#include <shellapi.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdio>
#include <ctime>
#include <exception>
#include <functional>
#include <thread>

namespace app {
namespace {

// ---------------------------------------------------------------------------
// 日志辅助（必须在 logToolLine 之前定义）
// ---------------------------------------------------------------------------
// 当前时钟 HH:mm:ss：只在需要绕过 logLine 直接落盘（例如完整命令行）时用
std::string clockNow() {
    SYSTEMTIME st{};
    GetLocalTime(&st);
    char buf[16] = {0};
    std::snprintf(buf, sizeof(buf), "%02d:%02d:%02d", st.wHour, st.wMinute, st.wSecond);
    return std::string(buf);
}

// 从子进程输出里摘出最后一条有实质内容的行当「原因」。
// 不把整段 stdout 塞进日志（几十行、还夹着 adb 的进度条），也不打印堆栈。
std::string tailLine(const std::string& raw) {
    std::string best;
    std::size_t bestAt = std::string::npos;
    std::size_t pos = 0;
    while (pos <= raw.size()) {
        std::size_t end = raw.find_first_of("\r\n", pos);
        if (end == std::string::npos) end = raw.size();
        std::string line = raw.substr(pos, end - pos);
        // 掐掉首尾空白
        const std::size_t b = line.find_first_not_of(" \t");
        if (b != std::string::npos) {
            const std::size_t e = line.find_last_not_of(" \t");
            line = line.substr(b, e - b + 1);
        } else {
            line.clear();
        }
        // 进度条、空行、纯符号行不算原因
        const bool useful = !line.empty() && line.find("\b") == std::string::npos &&
                            line.size() <= 220;
        if (useful) {
            best = line;
            bestAt = pos;
        }
        if (end >= raw.size()) break;
        pos = end + 1;
        while (pos < raw.size() && (raw[pos] == '\r' || raw[pos] == '\n')) ++pos;
    }
    if (best.empty()) return std::string();
    (void)bestAt;
    return best;
}


// 脚本跑几分钟、几百行输出。界面上只留「能读的关键行」，其余一律落盘不进面板：
//   · 分节标题 / 阶段进度（[i] [OK] [WARN] [ERROR] 前缀、==== 分隔线、>> 提示）
//   · 明确的成功/失败/警告语句
// 排除：纯调试行（形如 "[DEBUG]"、"  x" 缩进的驱动回显）、括号包起来的内部计数、
// 空行、重复行（连续 5 行以上相同内容只留第一行）。
void logToolLine(const std::string& raw) {
    // 管道里拿到的是脚本进程的真实字节流：PowerShell 5.1 在管道重定向时用的是
    // 系统 ANSI（中文机器 = GBK/CP936），只有脚本自己把 [Console]::OutputEncoding
    // 设成 UTF-8 之后才变成 UTF-8。这里统一过一遍 backend::toUtf8()：
    // 已经是合法 UTF-8 就原样返回，否则按 ACP 转码 —— 两代行为都能正确显示。
    std::string line = backend::toUtf8(raw);
    // 去首尾空白
    {
        const std::size_t b = line.find_first_not_of(" \t");
        if (b == std::string::npos) return;
        const std::size_t e = line.find_last_not_of(" \t\r");
        line = line.substr(b, e - b + 1);
    }
    if (line.empty()) return;

    // 全部落盘：原始输出是排查的第一手资料
    backend::logToFile(LOG_INFO, clockNow(), std::string("  ") + line);
    if (line.size() > 220) return;

    static std::string lastShown;
    static int repeat = 0;
    if (line == lastShown) {
        if (++repeat > 4) return;      // 同一行刷屏时只留前 5 条
    } else {
        lastShown = line;
        repeat = 0;
    }

    const bool isDebug = line.rfind("[DEBUG]", 0) == 0 || line.rfind("DEBUG", 0) == 0;
    if (isDebug) return;

    static const char* const kTags[] = {"[OK]", "[i]", "[WARN]", "[ERROR]", "[!]", "[-]", "[+]"};
    std::string tag;
    for (const char* t : kTags) {
        if (line.rfind(t, 0) == 0) { tag = t; break; }
    }
    if (!tag.empty()) {
        std::string body = line.substr(tag.size());
        const std::size_t b = body.find_first_not_of(" \t");
        body = (b == std::string::npos) ? std::string() : body.substr(b);
        if (body.empty()) return;
        const std::string msg = std::string("提权输出 · ") + body;
        if (tag == "[ERROR]") { logLine(LOG_ERR, msg); return; }
        if (tag == "[WARN]") { logLine(LOG_WARN, msg); return; }
        if (tag == "[OK]") { logLine(LOG_SUCC, msg); return; }
        logLine(LOG_INFO, msg);
        return;
    }

    // 分节标题 / 分隔线 / 阶段提示
    if (line.rfind("====", 0) == 0 || line.rfind("----", 0) == 0) return;   // 分隔线没有信息量
    if (line.rfind(">>", 0) == 0 || line.rfind("==", 0) == 0 ||
        line.rfind("GhostLock", 0) == 0 || line.rfind("iQOO", 0) == 0) {
        logLine(LOG_INFO, std::string("提权输出 · ") + line);
        return;
    }
    // 明确的结论句
    if (line.find("成功") != std::string::npos || line.find("失败") != std::string::npos ||
        line.find("已就绪") != std::string::npos || line.find("超时") != std::string::npos) {
        const bool bad = line.find("失败") != std::string::npos || line.find("超时") != std::string::npos;
        logLine(bad ? LOG_WARN : LOG_SUCC, std::string("提权输出 · ") + line);
        return;
    }
    // 其余（驱动回显、括号计数、裸数据）全部丢弃
}

} // namespace

// 运行方式的中文名与说明（AppState 的静态成员，界面卡片和日志共用同一份文案）
const char* AppState::runModeLabel(const std::string& mode) {
    if (mode == "Cold") return "开机模式并重启";
    if (mode == "Refire") return "已经重启过";
    return "不重启直接打";
}

const char* AppState::runModeHint(const std::string& mode) {
    if (mode == "Cold") return "触发一次完整冷启动流程，成功后手机会重启，成功率最高";
    if (mode == "Refire") return "手机刚重启完，直接重新触发一次提权";
    return "当前系统直接打一发，本工具不会主动重启手机";
}
namespace {


void runBlocking(const std::string& label, std::function<void()> work) {
    AppState& s = state();
    s.busy = true;
    s.busyText = label;
    logLine(LOG_INFO, label);
    std::thread([work] {
        AppState& inner = state();
        try {
            work();
        } catch (const std::exception& e) {
            logLine(LOG_ERR, std::string("后台任务异常 · ") + e.what());
        } catch (...) {
            logLine(LOG_ERR, "后台任务异常 · 未知");
        }
        inner.busy = false;
        inner.busyText.clear();
        // 后台任务结束后主动唤醒渲染：EUI 空闲不重绘，界面会停在点击那一刻的样子
        core::platform::requestUiUpdate();
    }).detach();
}

void setDevice(const backend::DeviceInfo& dev) {
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    state().device = dev;
}

void setRootStatus(bool active, const std::string& detail) {
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    AppState& s = state();
    s.rootActive = active;
    s.rootDetail = detail;
}

void refreshStates() {
    AppState& s = state();
    const auto& list = backend::managers();
    for (size_t i = 0; i < list.size(); ++i) {
        backend::CheckResult r = backend::checkManager(list[i], s.device.serial);
        {
            std::lock_guard<std::recursive_mutex> guard(stateMutex());
            s.states[i] = r.state;
            s.versions[i] = r.version;
            s.lastCheck = r;
        }
        // 把每台管理器的细节写进日志（含实际命中的包名 / 未装原因），方便排查识别问题
        if (!s.device.serial.empty()) {
            const bool ok = r.state == backend::InstallState::Installed;
            logLine(ok ? LOG_SUCC : LOG_INFO,
                    std::string("检测管理器 · ") + list[i].name +
                        (ok ? " · 已安装 · " : " · 未安装 · ") +
                        [&] {
                             // message 常以「已安装 · …」开头，去掉重复状态词与冗余分隔符
                             std::string m = r.message;
                             const std::string states[2] = {"已安装", "未安装"};
                             for (const std::string& st : states) {
                                 if (m.rfind(st, 0) == 0) {
                                     m = m.substr(st.size());
                                     if (m.rfind(" \xc2\xb7 ", 0) == 0) m = m.substr(4);   // " · " = 4 字节（中点是 2 字节）
                                     break;
                                 }
                             }
                             return m;
                         }());
        }
    }
}

} // namespace

void actionRefreshDevice() {
    runBlocking("正在检测设备连接…", [] {
        AppState& s = state();
        setDevice(backend::detectDevice());
        if (s.device.ready) {
            logLine(LOG_SUCC, "连接设备 · " + s.device.message + " · 完成");
            // 连上设备顺手把四个管理器的状态刷一遍，省得用户再点一次「检测状态」
            refreshStates();
        } else {
            logLine(LOG_WARN, "连接设备 · 失败 · 原因：" + s.device.message);
        }
    });
}

void actionDetectAll() {
    runBlocking("正在检测管理器安装状态…", [] {
        AppState& s = state();
        if (s.device.serial.empty()) {
            setDevice(backend::detectDevice());
        }
        refreshStates();
        if (s.device.serial.empty()) {
            for (size_t i = 0; i < backend::managers().size(); ++i) {
                s.states[i] = backend::InstallState::NotInstalled;
                if (i == 0) {
                    logLine(LOG_WARN, std::to_string(backend::managers().size()) +
                                           " 个管理器 · 跳过检测 · 原因：未连接设备");
                }
            }
        }
    });
}

void actionInstall() {
    const auto& info = selectedManager();
    runBlocking("正在安装 " + info.name + "…", [key = info.key] {
        AppState& s = state();
        const int idx = selectedIndex();
        if (idx >= 0) s.states[static_cast<size_t>(idx)] = backend::InstallState::Installing;
        const backend::ManagerInfo* target = backend::findManager(key);
        if (!target) return;

        // 先补齐安装包：内置与 download\ 都没有就联网拉一份。
        // 这一步不需要设备，所以放在设备检查之前——用户可以先下好包再接手机。
        bool isLocal = true;
        if (backend::resolveApk(*target, &isLocal).empty()) {
            logLine(LOG_INFO, "下载安装包 · " + target->name + " · 进行中（本地无内置包）");
            std::string dlog;
            if (!backend::downloadApk(*target, dlog, nullptr)) {
                if (idx >= 0) {
                    std::lock_guard<std::recursive_mutex> guard(stateMutex());
                    s.states[static_cast<size_t>(idx)] = backend::InstallState::Failed;
                }
                logLine(LOG_ERR, "下载安装包 · " + target->name + " · 失败 · 原因：" +
                                     (dlog.empty() ? std::string("网络不通或上游地址失效")
                                                   : tailLine(dlog)));
                logLine(LOG_ERR, "安装 " + target->name + " · 取消 · 原因：没有安装包");
                core::platform::requestUiUpdate();
                return;
            }
            logLine(LOG_SUCC, "下载安装包 · " + target->name + " · 完成");
        }

        if (s.device.serial.empty()) setDevice(backend::detectDevice());
        if (s.device.serial.empty()) {
            if (idx >= 0) {
                std::lock_guard<std::recursive_mutex> guard(stateMutex());
                s.states[static_cast<size_t>(idx)] = backend::InstallState::Failed;
            }
            logLine(LOG_ERR, "安装 " + target->name +
                                 " · 取消 · 原因：未连接设备（安装包已就绪，接上手机再点「安装所选」）");
            core::platform::requestUiUpdate();
            return;
        }
        std::string output;
        const bool ok = backend::installManager(*target, s.device.serial, output);
        // 失败时把子进程的最后一句实质性报错作为「原因」行；成功不打印过程输出。
        if (!ok) {
            logLine(LOG_ERR, "安装 " + target->name + " · 失败 · 原因：" +
                                 (output.empty() ? std::string("adb install 未返回信息")
                                                 : tailLine(output)));
        }
        backend::CheckResult r = backend::checkManager(*target, s.device.serial);
        if (idx >= 0) s.states[static_cast<size_t>(idx)] = ok ? r.state : backend::InstallState::Failed;
        logLine(ok ? LOG_SUCC : LOG_ERR, "安装 " + target->name + " · " +
                                             backend::stateLabel(r.state) + " · " +
                                             (ok ? "完成" : "失败"));
    });
}

// ---- 管理器更新检测（v3.1）----
// 判定口径（三档版本里取最高的那条做基准）：
//   remote  = GitHub releases/latest 的 tag
//   local   = 内置包版本（ManagerInfo::version，随包发布时写死）
//   device  = 手机上已装版本（pm dump 读出来的 versionName）
// 只要 remote 比 local 和 device 都新，就算「有更新」。
// 没装的管理器不算更新（那是「未安装」，归「安装所选」按钮管）。
std::vector<std::string> pendingUpdateKeys() {
    std::lock_guard<std::recursive_mutex> guard(stateMutex());
    std::vector<std::string> keys;
    for (const auto& item : state().updates) {
        if (item.hasUpdate) keys.push_back(item.key);
    }
    return keys;
}

void actionCheckUpdates() {
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        if (state().updateChecking) return;
        state().updateChecking = true;
    }
    runBlocking("正在检查管理器更新…", [] {
        struct CheckGuard {
            ~CheckGuard() {
                std::lock_guard<std::recursive_mutex> guard(stateMutex());
                state().updateChecking = false;
            }
        } checkGuard;
        AppState& s = state();
        // 没连设备也能查「有没有新版」，只是没法比对手机上那一版
        if (s.device.serial.empty()) setDevice(backend::detectDevice());
        const std::string serial = s.device.serial;

        const auto& list = backend::managers();
        std::vector<backend::UpdateCheck> results(list.size());
        int updatable = 0;
        int failed = 0;
        int installedCount = 0;

        for (size_t i = 0; i < list.size(); ++i) {
            const backend::ManagerInfo& info = list[i];
            backend::UpdateCheck item;
            item.key = info.key;
            item.name = info.name;
            item.localVersion = info.version;

            // 1) 手机上装的是哪一版
            backend::CheckResult installed;
            if (!serial.empty()) {
                installed = backend::checkManager(info, serial);
                item.installed = installed.state == backend::InstallState::Installed;
                if (item.installed) {
                    item.installedVersion = installed.version;
                    ++installedCount;
                }
            }

            // 2) 上游最新是哪一版
            std::string tag;
            std::string url;
            std::string err;
            item.ok = backend::fetchLatestRelease(info, tag, url, err);
            if (!item.ok) {
                item.message = info.name + "：查询失败 —— " + err;
                logLine(LOG_WARN, "查询更新 · " + info.name + " · 失败 · 原因：" + err);
                ++failed;
                results[i] = item;
                continue;
            }
            item.latestVersion = tag;
            item.latestUrl = url;

            // 3) 比版本。未安装的条目也要比内置包：内置包旧时提示更新/安装，
            //    否则这类管理器永远不会出现在更新弹窗里。
            const bool deviceOld = item.installed &&
                                   backend::versionNewer(tag, item.installedVersion);
            const bool localOld = backend::versionNewer(tag, item.localVersion);
            const std::string localPath = backend::resolveApk(info, nullptr);
            const bool localReady = !localPath.empty();
            // 没装的项只要本地有内置包，也算“可安装”，这样检查更新才有东西可弹。
            item.hasUpdate = item.installed ? (deviceOld || localOld) : localReady;

            if (!item.installed) {
                const std::string lv = item.localVersion.empty() ? "未知" : item.localVersion;
                if (item.hasUpdate) {
                    ++updatable;
                    item.message = info.name + "：未安装，可安装内置包 " + lv;
                    logLine(LOG_SUCC, "查询更新 · " + info.name +
                                          " · 未安装 · 可安装内置包 " + lv);
                } else {
                    item.message = info.name + "：未安装（内置包缺失，上游 " + tag + "）";
                    logLine(LOG_INFO, "查询更新 · " + info.name +
                                          " · 未安装 · 内置包缺失 · 上游 " + tag);
                }
                results[i] = item;
                continue;
            }
            if (item.hasUpdate) {
                ++updatable;
                item.message = info.name + "：可更新 " + item.installedVersion + " → " + tag;
                logLine(LOG_SUCC, "查询更新 · " + info.name + " · 可更新 " +
                                      item.installedVersion + " → " + tag);
            } else {
                item.message = info.name + "：已是最新（" + item.installedVersion + "）";
                logLine(LOG_INFO, "查询更新 · " + info.name + " · 已是最新 " + item.installedVersion);
            }
            results[i] = item;
        }

        // 时间戳只用于摘要，不参与判定
        const std::time_t now = std::time(nullptr);
        std::tm local{};
        localtime_s(&local, &now);
        char stamp[16] = {0};
        std::snprintf(stamp, sizeof(stamp), "%02d:%02d:%02d", local.tm_hour, local.tm_min,
                      local.tm_sec);

        {
            std::lock_guard<std::recursive_mutex> guard(stateMutex());
            s.updates = std::move(results);
            s.updateChecking = false;
            s.updateCheckedOnce = true;
            std::string note = std::string("最近检查 ") + stamp + " · ";
            if (updatable > 0) {
                note += std::to_string(updatable) + " 项可安装/更新";
            } else if (installedCount == 0) {
                note += "全部未安装（内置包已是最新）";
            } else {
                note += "已安装项均为最新";
            }
            if (failed > 0) note += " · " + std::to_string(failed) + " 项查询失败";
            s.updateNote = note;
            logLine(updatable > 0 ? LOG_SUCC : LOG_INFO, "检查更新 · 完成 · " + note);
            // 有可更新项才弹确认框；全是最新就只把结果留在卡片上
            if (updatable > 0) {
                s.popup = Popup::ConfirmUpdate;
                logLine(LOG_INFO, "检查更新 · 请求弹窗 · " +
                                      std::to_string(updatable) + " 项");
            }
        }
        core::platform::requestUiUpdate();
    });
}

void actionApplyUpdates(const std::vector<std::string>& keys) {
    if (keys.empty()) {
        logLine(LOG_INFO, "批量更新 · 跳过 · 取消：没有需要更新的管理器");
        return;
    }
    const std::string label = keys.size() == 1
                                  ? ("正在更新 " + keys.front() + "…")
                                  : ("正在更新 " + std::to_string(keys.size()) + " 个管理器…");
    runBlocking(label, [keys] {
        AppState& s = state();
        if (s.device.serial.empty()) setDevice(backend::detectDevice());
        // 注意：这里不因为「没设备」直接 return。先把最新包下到 download\ 是有意义的动作
        // （用户可以先挂着下、等手机接上再装），只有落到 adb install 才需要设备。
        const std::string serial = s.device.serial;
        int okCount = 0;
        int failCount = 0;

        for (const std::string& key : keys) {
            const backend::ManagerInfo* info = backend::findManager(key);
            if (!info) continue;
            const int idx = indexOfManager(key);

            if (serial.empty()) {
                logLine(LOG_WARN, "更新 " + info->name +
                                      " · 跳过安装 · 原因：未连接设备");
                ++failCount;
                continue;
            }

            if (idx >= 0) {
                std::lock_guard<std::recursive_mutex> guard(stateMutex());
                s.states[static_cast<size_t>(idx)] = backend::InstallState::Installing;
            }
            std::string ilog;
            bool ok = false;
            bool localIsBuiltin = false;
            const std::string localPath = backend::resolveApk(*info, &localIsBuiltin);
            if (!localPath.empty()) {
                logLine(LOG_INFO, "更新 " + info->name +
                                      (localIsBuiltin ? " · 使用内置包" : " · 使用本地缓存包"));
                ok = backend::installManagerFromFile(*info, serial, localPath, ilog);
            } else {
                std::string dlog;
                const bool downloaded = backend::downloadApk(*info, dlog, nullptr);
                if (!downloaded) {
                    logLine(LOG_ERR, "下载最新包 · " + info->name + " · 失败 · 原因：" +
                                         (dlog.empty()
                                              ? std::string("网络不通或上游地址失效")
                                              : tailLine(dlog)));
                    ++failCount;
                    continue;
                }
                const std::string downloadedPath =
                    backend::downloadDir() + "\\" + info->apkFile;
                ok = backend::installManagerFromFile(*info, serial, downloadedPath, ilog);
            }
            if (!ok) {
                logLine(LOG_ERR, "更新 " + info->name + " · 失败 · 原因：" +
                                     (ilog.empty() ? std::string("adb install 未返回信息")
                                                   : tailLine(ilog)));
            }

            backend::CheckResult r = backend::checkManager(*info, serial);
            if (idx >= 0) {
                std::lock_guard<std::recursive_mutex> guard(stateMutex());
                s.states[static_cast<size_t>(idx)] = ok ? r.state : backend::InstallState::Failed;
                if (ok) s.versions[static_cast<size_t>(idx)] = r.version;
            }
            ok ? ++okCount : ++failCount;
        }

        std::string summary = "批量更新 · 成功 " + std::to_string(okCount) + " 项";
        if (failCount > 0) summary += " · 失败 " + std::to_string(failCount) + " 项";
        summary += " · " + std::string(failCount == 0 ? "完成" : "部分失败");
        logLine(failCount == 0 ? LOG_SUCC : LOG_WARN, summary);
        // 更新完重新比一次，卡片上的「可更新」标记会自动消失
        core::platform::requestUiUpdate();
    });
}

void actionUninstall() {
    const auto& info = selectedManager();
    runBlocking("正在卸载 " + info.name + "…", [key = info.key] {
        AppState& s = state();
        const backend::ManagerInfo* target = backend::findManager(key);
        if (!target || s.device.serial.empty()) return;
        std::string output;
        const bool ok = backend::uninstallManager(*target, s.device.serial, output);
        const int idx = selectedIndex();
        if (idx >= 0) s.states[static_cast<size_t>(idx)] = ok ? backend::InstallState::NotInstalled
                                                             : backend::InstallState::Installed;
        logLine(ok ? LOG_SUCC : LOG_ERR,
                std::string("卸载 ") + target->name + " · " +
                    (ok ? std::string("完成")
                        : ("失败 · 原因：" +
                           (output.empty() ? std::string("adb uninstall 未返回信息") : tailLine(output)))));
    });
}

void actionLaunch() {
    const auto& info = selectedManager();
    runBlocking("正在打开 " + info.name + "…", [key = info.key] {
        AppState& s = state();
        const backend::ManagerInfo* target = backend::findManager(key);
        if (!target || s.device.serial.empty()) return;
        std::string output;
        const bool ok = backend::launchManager(*target, s.device.serial, output);
        logLine(ok ? LOG_SUCC : LOG_WARN, "启动应用 " + target->name + " · " +
                                              (ok ? "完成" : ("失败 · 原因：" +
                                                      (output.empty() ? std::string("am start 未返回信息")
                                                                      : tailLine(output)))));
    });
}

void refreshRoot(bool verbose) {
    AppState& s = state();
    const backend::RootStatus status = backend::probeRoot(s.device.serial);
    bool wasActive = false;
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        wasActive = s.rootActive;
        s.rootActive = status.active;
        s.rootDetail = status.detail;
    }
    const bool changed = (status.active != wasActive);
    if ((changed || verbose) && !s.device.serial.empty()) {
        if (status.active) {
            logLine(LOG_SUCC, "检测临时 root · 已激活 · " + status.detail);
        } else {
            logLine(LOG_INFO, "检测临时 root · 未激活 · " + status.detail);
        }
    }
}

void actionConnectDevice() {
    runBlocking("正在连接设备…", [] {
        AppState& s = state();
        std::string log;
        backend::adbRestartServer(log);
        logLine(LOG_INFO, "重启 adb 服务 · 完成（手机若弹「允许 USB 调试」请点允许并勾选一律允许）");
        // 给手机一点时间弹窗并回连
        for (int i = 0; i < 10; ++i) {
            setDevice(backend::detectDevice());
            if (s.device.ready) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(700));
        }
        if (s.device.ready) {
            logLine(LOG_SUCC, "连接设备 · " + s.device.message + " · 完成");
            refreshStates();
            refreshRoot(false);
        } else {
            logLine(LOG_WARN, "连接设备 · 失败 · 原因：" + s.device.message);
        }
    });
}

void actionRebootDevice() {
    if (!state().device.ready) {
        logLine(LOG_WARN, "重启设备 · 跳过 · 原因：未连接设备");
        return;
    }
    const std::string serial = state().device.serial;
    runBlocking("正在重启设备…", [serial] {
        std::string log;
        if (backend::adbReboot(serial, log)) {
            logLine(LOG_INFO, "重启设备 · " + serial + " · 指令已下发，等待回连");
            // 重启期间设备会掉线，等它回来（最多 ~90 秒），回来就顺手刷新 root 状态
            for (int i = 0; i < 60; ++i) {
                std::this_thread::sleep_for(std::chrono::milliseconds(1500));
                const backend::DeviceInfo dev = backend::detectDevice();
                if (dev.ready && dev.serial == serial) {
                    setDevice(dev);
                    logLine(LOG_SUCC, "重启设备 · " + dev.message + " · 完成（临时 root 已失效，需重新提权）");
                    setRootStatus(false, std::string());
                    refreshStates();
                    core::platform::requestUiUpdate();
                    return;
                }
            }
            logLine(LOG_WARN, "重启设备 · 等待回连超时（90 秒）· 请检查数据线或点「连接设备」重试");
        } else {
            logLine(LOG_ERR, "重启设备 · 失败 · 原因：" +
                                 (log.empty() ? std::string("adb reboot 未返回信息") : tailLine(log)));
        }
    });
}

void actionCheckRoot() {
    runBlocking("正在检测临时 root…", [] { refreshRoot(true); });
}

void startDeviceWatcher() {
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        if (state().deviceWatchStarted) return;
        state().deviceWatchStarted = true;
    }
    // 实时监听：1.2s 一轮 adb devices，插拔 USB / 断连都能自己发现，不需要手动刷新。
    std::thread([] {
        std::string lastSerial;
        bool lastReady = false;
        int rootTick = 0;
        for (;;) {
            std::this_thread::sleep_for(std::chrono::milliseconds(1200));
            bool busy = false;
            std::string serial;
            bool rootActive = false;
            {
                std::lock_guard<std::recursive_mutex> guard(stateMutex());
                AppState& inner = state();
                busy = inner.busy;
                serial = inner.device.serial;
                rootActive = inner.rootActive;
            }
            if (busy) continue;   // 正在跑别的 adb 任务，别抢
            const backend::DeviceInfo dev = backend::detectDevice();
            const bool changed = (dev.ready != lastReady) || (dev.serial != lastSerial);
            if (changed) {
                setDevice(dev);
                lastReady = dev.ready;
                lastSerial = dev.serial;
                if (dev.ready) {
                    logLine(LOG_SUCC, "设备接入 · " + dev.message + " · 已识别");
                    refreshStates();
                    refreshRoot(false);
                } else {
                    setRootStatus(false, std::string());
                    logLine(LOG_WARN, "设备断开 · 原因：" + dev.message);
                }
                core::platform::requestUiUpdate();
            } else if (dev.ready) {
                // 连着的设备每 6 轮（≈7s）顺手看一眼 root 状态，拔了/重启了能立刻反映
                if (++rootTick >= 6) {
                    rootTick = 0;
                    const backend::RootStatus st = backend::probeRoot(dev.serial);
                    if (st.active != rootActive) {
                        setRootStatus(st.active, st.detail);
                        logLine(st.active ? LOG_SUCC : LOG_INFO,
                                (st.active ? "检测临时 root · 已激活 · " : "检测临时 root · 已失效 · ") + st.detail);
                        core::platform::requestUiUpdate();
                    } else {
                        setRootStatus(st.active, st.detail);
                    }
                }
            }
        }
    }).detach();
}

void actionElevate() {
    if (!selectedInstalled()) {
        state().popup = Popup::WarnNoManager;
        logLine(LOG_WARN, "执行提权 · 跳过 · 原因：尚未检测到已安装的管理器");
        return;
    }
    std::string log;
    if (!backend::rootToolPreflight(log)) {
        logLine(LOG_ERR, "执行提权 · 前置校验未通过 · 原因：" + tailLine(log));
        return;
    }
    logLine(LOG_INFO, "前置校验 · 通过 · " + tailLine(log));
    // 按界面选的运行方式执行（Cold/Refire/Interactive），失败由 actionRunTool 负责自动重启。
    actionRunTool(state().runMode, true);
}

void setRunMode(const std::string& mode) {
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        state().runMode = mode;
    }
    // 立刻落盘，程序被强杀/崩溃也不会退回默认值
    backend::writeIni(backend::appIniPath(), "state", "run_mode", mode);
    logLine(LOG_INFO, std::string("运行方式 · ") + AppState::runModeLabel(mode) + " · 已保存");
}

void actionOpenUrl(const std::string& url) {
    if (url.empty()) return;
    ShellExecuteW(nullptr, L"open", backend::widen(url).c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

void actionOpenApkDir() {
    const std::string dir = backend::assets::dirOf("apk");
    ShellExecuteW(nullptr, L"open", backend::widen(dir).c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

void actionRunTool(const std::string& mode, bool rebootOnFail) {
    AppState& s = state();
    if (s.toolRunning) {
        logLine(LOG_WARN, "启动提权工具 · 跳过 · 原因：上一次还在运行，请先中止");
        return;
    }
    std::string log;
    if (!backend::rootToolPreflight(log)) {
        logLine(LOG_ERR, "启动提权工具 · 前置校验未通过 · 原因：" + tailLine(log));
        return;
    }
    // 清掉上一次没关干净的提权工具实例，否则脚本会因 driver.lock 被占用直接以退出码 1 退出
    {
        std::string stale;
        const int killed = backend::killStaleRootTool(stale);
        if (killed != 0) logLine(LOG_WARN, "清理残留提权进程 · " + std::to_string(killed) +
                                                    " 个 · " + tailLine(stale));
    }
    // 把界面上选中的管理器一起传下去：设备端 ksud-launcher.sh 会用它决定
    // late-load 哪个管理器的 libksud.so，否则多管理器并存时会挑错版本。
    const backend::ManagerInfo& selInfo = backend::managers()[static_cast<size_t>(selectedIndex())];
    const std::string cmd = backend::rootToolCommand(mode, s.device.serial, selInfo.package);
    s.toolRunning = true;
    s.toolMode = mode;
    s.logPin = true;             // 重新开始任务：日志自动跟到底部
    s.logScroll.set(1.0e6f);
    // 完整命令行只在落盘文件里留一份（排查用），界面不再打印——它有两百多个字符，
    // 铺满面板还挤掉真正的关键信息。
    backend::logToFile(LOG_INFO, clockNow(),
                       std::string("启动提权工具 · Mode=") + mode + " · 管理器=" + selInfo.name);
    backend::logToFile(LOG_INFO, clockNow(), "命令行 · " + cmd);
    logLine(LOG_INFO, std::string("启动提权工具 · 运行方式=") + AppState::runModeLabel(mode) +
                          " · 管理器=" + selInfo.name + " · 进行中");

    std::thread([cmd, mode, rebootOnFail] {
        struct Ctx {
            int exitCode = 0;
            bool alreadyRoot = false;   // 脚本在第 1168 行判定已 root，会直接跳过不做事
            bool rooted = false;        // 本次真的打穿了
            std::atomic<bool> done{false};
        } ctx;
        // 流式输出：脚本跑几分钟也不至于界面一片死寂（用户会以为卡死然后乱点/关窗口）
        backend::runStreaming(
            backend::widen(cmd),
            [](const std::string& line, void* user) {
                auto* c = static_cast<Ctx*>(user);
                if (line.find("当前已经是 root") != std::string::npos) c->alreadyRoot = true;
                if (line.find("提权成功") != std::string::npos ||
                    line.find("ROOT 已就绪") != std::string::npos ||
                    line.find("already root") != std::string::npos) {
                    c->rooted = true;
                }
                // 脚本输出只挑关键行进界面：标题行、阶段提示、显式提示与非调试类报错。
                // 完整的原始输出仍然逐行落在 logs\run-*.log 里，排查时看文件即可。
                logToolLine(line);
            },
            &ctx,
            [](int code, void* user) {
                auto* c = static_cast<Ctx*>(user);
                c->exitCode = code;
                c->done.store(true);
            });
        while (!ctx.done.load()) std::this_thread::sleep_for(std::chrono::milliseconds(120));
        AppState& inner = state();
        inner.toolRunning = false;
        inner.toolExit = ctx.exitCode;

        if (ctx.exitCode != 0) {
            logLine(LOG_ERR, "提权工具 · 失败 · 原因：进程退出码 " + std::to_string(ctx.exitCode) +
                                 "（详细输出见 logs\\run-*.log）");
        } else if (ctx.alreadyRoot) {
            // 退出码 0 但脚本其实什么都没干——必须说清楚，否则用户以为「成功了却没反应」
            logLine(LOG_WARN, "提权工具 · 跳过 · 原因：设备当前已是临时 root，脚本未执行任何动作"
                              "（要重跑请先重启手机清掉临时 root，再选「① 开机模式并重启」）");
        } else if (mode == "Status") {
            logLine(LOG_SUCC, "查询 root 状态 · 完成");
        } else if (ctx.rooted) {
            logLine(LOG_SUCC, "提权工具 · 完成 · 已获得临时 root（重启后失效）");
        } else {
            logLine(LOG_WARN, "提权工具 · 结束 · 未捕获到成功标志，请对照上方关键行或 logs\\run-*.log 判断");
        }

        // 以「实际能不能 su」为准，而不是只看退出码
        const backend::RootStatus st = backend::probeRoot(inner.device.serial);
        setRootStatus(st.active, st.detail);

        if (rebootOnFail && !st.active) {
            logLine(LOG_WARN, "校验 root · 未生效（" + st.detail + "）· 自动重启手机，重启后可再执行一次");
            std::string rebootLog;
            if (backend::adbReboot(inner.device.serial, rebootLog)) {
                logLine(LOG_INFO, "重启设备 · 指令已下发，等待手机回连");
            } else {
                logLine(LOG_ERR, "重启设备 · 失败 · 原因：" +
                                     (rebootLog.empty() ? std::string("adb reboot 未返回信息")
                                                        : tailLine(rebootLog)));
            }
        } else if (st.active) {
            logLine(LOG_SUCC, "校验 root · 已生效 · " + st.detail);
        }
        core::platform::requestUiUpdate();
    }).detach();
}

// ---------------------------------------------------------------------------
// 安卓投屏（scrcpy）
// ---------------------------------------------------------------------------
namespace {

// scrcpy 的输出很啰嗦：只把报错和警告放进界面，正常流水行一律丢弃
// （完整输出仍在 logs\run-*.log 里）。
void mirrorLine(const std::string& raw) {
    const std::string line = backend::toUtf8(raw);
    if (line.empty()) return;
    if (line.find("ERROR") != std::string::npos || line.find("error") != std::string::npos) {
        logLine(LOG_ERR, "投屏输出 · " + line);
    } else if (line.find("WARN") != std::string::npos) {
        logLine(LOG_WARN, "投屏输出 · " + line);
    }
}

void mirrorDone(int code, void*) {
    AppState& s = state();
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        s.mirrorRunning = false;
        s.mirrorTask = 0;
    }
    AppState& inner = state();
    if (code == 0) {
        logLine(LOG_SUCC, "停止投屏 · 完成");
    } else {
        logLine(LOG_WARN, "投屏进程结束 · 退出码 " + std::to_string(code) +
                              " · 原因：窗口被关闭或 scrcpy 自行退出");
        if (!inner.mirrorRecordPath.empty() && inner.mirrorRecord) {
            logLine(LOG_INFO, "录屏文件 · " + inner.mirrorRecordPath);
        }
    }
    core::platform::requestUiUpdate();
}

}  // namespace

void loadMirrorSettings() {
    AppState& s = state();
    const std::string ini = backend::appIniPath();
    s.mirrorSize = backend::readIni(ini, "mirror", "size", "1080");
    s.mirrorBitRate = backend::readIni(ini, "mirror", "bitrate", "16");
    s.mirrorAudio = backend::readIni(ini, "mirror", "audio", "1") != "0";
    s.mirrorMouse = backend::readIni(ini, "mirror", "mouse", "1") != "0";
    s.mirrorRecord = backend::readIni(ini, "mirror", "record", "0") != "0";
    s.mirrorFullscreen = backend::readIni(ini, "mirror", "fullscreen", "0") != "0";
    if (!backend::scrcpyAvailable()) {
        logLine(LOG_WARN, "投屏组件检查 · 缺失 scrcpy.exe · 投屏不可用（资源包里没有 scrcpy 组件）");
    } else {
        s.mirrorVersion = backend::scrcpyVersion();
    }
}

void setMirrorSize(const std::string& size) {
    state().mirrorSize = size;
    backend::writeIni(backend::appIniPath(), "mirror", "size", size);
    logLine(LOG_INFO, "投屏分辨率 · " + (size == "0" ? std::string("原生") : size + "p") + " · 已保存");
    core::platform::requestUiUpdate();
}

void setMirrorBitRate(const std::string& rate) {
    state().mirrorBitRate = rate;
    backend::writeIni(backend::appIniPath(), "mirror", "bitrate", rate);
    logLine(LOG_INFO, "投屏码率 · " + rate + " Mbps · 已保存");
    core::platform::requestUiUpdate();
}

void toggleMirrorOption(const std::string& key) {
    AppState& s = state();
    bool value = false;
    if (key == "audio") { s.mirrorAudio = !s.mirrorAudio; value = s.mirrorAudio; }
    else if (key == "mouse") { s.mirrorMouse = !s.mirrorMouse; value = s.mirrorMouse; }
    else if (key == "record") { s.mirrorRecord = !s.mirrorRecord; value = s.mirrorRecord; }
    else if (key == "fullscreen") { s.mirrorFullscreen = !s.mirrorFullscreen; value = s.mirrorFullscreen; }
    else return;

    backend::writeIni(backend::appIniPath(), "mirror", key, value ? "1" : "0");
    const char* label = key == "audio" ? "音频转发"
                      : key == "mouse" ? "鼠标控制手机"
                      : key == "record" ? "录屏保存" : "全屏启动";
    logLine(LOG_INFO, std::string("投屏选项 · ") + label + " · " + (value ? "已开启" : "已关闭"));
    core::platform::requestUiUpdate();
}

void actionMirrorStart() {
    AppState& s = state();
    if (!backend::scrcpyAvailable()) {
        logLine(LOG_ERR, "启动投屏 · 失败 · 原因：资源包里找不到 scrcpy.exe");
        return;
    }
    if (!s.device.ready) {
        logLine(LOG_WARN, "启动投屏 · 跳过 · 原因：未连接设备（先点左下角「连接设备」）");
        return;
    }
    if (s.mirrorRunning) {
        logLine(LOG_WARN, "启动投屏 · 跳过 · 原因：投屏已在运行");
        return;
    }

    backend::MirrorOptions opt;
    opt.maxSize = s.mirrorSize;
    opt.bitRate = s.mirrorBitRate;
    opt.audio = s.mirrorAudio;
    opt.mouseControl = s.mirrorMouse;
    opt.record = s.mirrorRecord;
    opt.fullscreen = s.mirrorFullscreen;
    if (opt.record) {
        opt.recordPath = backend::makeRecordPath();
        s.mirrorRecordPath = opt.recordPath;
        logLine(LOG_INFO, "录屏 · 保存路径 " + opt.recordPath);
    } else {
        s.mirrorRecordPath.clear();
    }

    const std::string cmd = backend::buildMirrorCommand(s.device.serial, opt);
    // 命令行同样只落盘，界面留一句结构化摘要
    backend::logToFile(LOG_INFO, clockNow(), "启动投屏 · 命令行 " + cmd);

    const unsigned long long id = backend::runStreaming(
        backend::widen(cmd),
        [](const std::string& line, void*) { mirrorLine(line); },
        nullptr,
        &mirrorDone,
        backend::widen(backend::scrcpyDir()));

    s.mirrorTask = id;
    s.mirrorRunning = true;
    logLine(LOG_SUCC, "启动投屏 · 完成（鼠标可直接操作手机，Ctrl+F 全屏，关窗即停止）");
    core::platform::requestUiUpdate();
}

void actionMirrorStop() {
    AppState& s = state();
    if (!s.mirrorRunning || s.mirrorTask == 0) {
        logLine(LOG_INFO, "停止投屏 · 跳过 · 当前没有在投屏");
        return;
    }
    const unsigned long long id = s.mirrorTask;

    // 先让 scrcpy 自己正常退出（会 flush 录屏文件），2 秒还没退就强杀
    logLine(LOG_INFO, "停止投屏 · 进行中");
    backend::closeMirrorWindow();
    for (int i = 0; i < 20; ++i) {
        if (!backend::streamingRunning(id)) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    if (backend::streamingRunning(id)) {
        backend::cancelStreaming(id);
        logLine(LOG_WARN, "停止投屏 · 进程未响应关闭请求 · 已强制结束");
    }

    s.mirrorRunning = false;
    s.mirrorTask = 0;
    if (s.mirrorRecord && !s.mirrorRecordPath.empty()) {
        logLine(LOG_INFO, "录屏文件 · " + s.mirrorRecordPath);
    }
    core::platform::requestUiUpdate();
}

void actionOpenRecordDir() { backend::openFolder(backend::recordDir()); }

void actionOpenScrcpyDir() { backend::openFolder(backend::scrcpyDir()); }

// ============================================================ 主页
namespace {

// 后台采集一次设备详表，结果写回 state。
// 抽出来是因为「刷新按钮 / 设备下拉 / 周期采样」三条路都要用。
void collectHomeDetail(const std::string& wantSerial) {
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        if (state().homeBusy) return;
        state().homeBusy = true;
    }
    core::platform::requestUiUpdate();

    const backend::DeviceDetail detail = backend::detectDeviceDetail(wantSerial);
    const std::vector<std::string> devices = backend::listDeviceSerials();

    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        AppState& st = state();
        st.detail = detail;
        st.homeBusy = false;
        st.homeNote = detail.serial;
        if (!detail.error.empty()) st.homeNote = detail.error;
    }
    core::platform::requestUiUpdate();
}

} // namespace

void refreshHomeDetail() {
    std::string want;
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        want = state().homeSelectSerial;
    }
    runBlocking("正在读取设备信息…", [want] { collectHomeDetail(want); });
}

void startHomeWatcher() {
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        if (state().homeWatchStarted) return;
        state().homeWatchStarted = true;
    }
    std::thread([] {
        for (;;) {
            std::this_thread::sleep_for(std::chrono::milliseconds(4000));
            // 锁只用来读决策变量；collectHomeDetail 自己会再加锁，
            // 所以这里绝不能把 serial 的引用带出作用域。
            bool want = false;
            std::string serial;
            {
                std::lock_guard<std::recursive_mutex> guard(stateMutex());
                AppState& st = state();
                const bool visible = (st.page == Page::Home);
                const bool allowed = visible && st.homeDeviceCheck && !st.busy && !st.homeBusy;
                if (allowed) {
                    serial = st.homeMultiDevice ? st.homeSelectSerial : std::string();
                    want = (serial != st.homeNote) || !st.detail.ready;
                }
            }
            if (!want) continue;
            collectHomeDetail(serial);
        }
    }).detach();
}

void actionRebootInto(const std::string& target) {
    std::string serial;
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        serial = state().detail.serial;
    }
    if (serial.empty()) {
        logLine(LOG_WARN, "重启到目标模式 · 跳过 · 原因：没有可用设备");
        return;
    }
    runBlocking("正在下发重启指令…", [serial, target] {
        std::string log;
        const bool ok = backend::rebootInto(serial, target, log);
        logLine(ok ? LOG_SUCC : LOG_ERR, "重启到 " + target + " · " +
                                             (ok ? "指令已下发" : ("失败 · 原因：" +
                                                     (log.empty() ? std::string("reboot 目标不支持")
                                                                  : tailLine(log)))));
        if (ok) {
            std::this_thread::sleep_for(std::chrono::seconds(3));
            const backend::DeviceInfo info = backend::detectDevice();
            std::lock_guard<std::recursive_mutex> guard(stateMutex());
            state().device = info;
        }
    });
}

void actionSaveDeviceInfo() {
    backend::DeviceDetail detail;
    std::string serial;
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        detail = state().detail;
        serial = detail.serial;
    }
    if (!detail.ready) {
        logLine(LOG_WARN, "保存设备信息 · 跳过 · 原因：还没有读到设备信息（先点「刷新设备」）");
        return;
    }
    if (serial.empty()) serial = "device";
    const std::string dir = backend::appDir() + "\\logs";

    auto stamp = std::chrono::system_clock::now().time_since_epoch().count();
    char buf[64];
    std::snprintf(buf, sizeof(buf), "\\device-%s-%lld.txt", serial.c_str(),
                  static_cast<long long>(stamp));

    std::string log;
    if (backend::saveDeviceReport(detail, dir + buf, log)) {
        logLine(LOG_SUCC, "保存设备信息 · " + dir + buf + " · 完成");
        backend::openFolder(dir);
    } else {
        logLine(LOG_ERR, "保存设备信息 · 失败 · 原因：" +
                                 (log.empty() ? std::string("写文件失败（检查 logs 目录权限）")
                                              : tailLine(log)));
    }
}

// ------------------------------------------------------------------ 主页快捷工具

void actionOpenLogDir() { backend::openFolder(backend::appDir() + "\\logs"); }

void actionToggleWireless() {
    std::string serial;
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        serial = state().detail.serial;
    }
    if (serial.empty()) {
        logLine(LOG_WARN, "切换无线调试 · 跳过 · 原因：没有可用设备（需先插 USB 打一次 tcpip）");
        return;
    }

    // 已经是无线（序列号带冒号）→ 这次按「断开无线、回 USB」做
    if (serial.find(':') != std::string::npos) {
        runBlocking("正在断开无线调试…", [serial] {
            std::string log;
            backend::disableWirelessDebug(serial, log);
            logLine(LOG_SUCC, "断开无线调试 · 完成 · " + tailLine(log));
            std::lock_guard<std::recursive_mutex> guard(stateMutex());
            state().homeWireless = false;
            refreshHomeDetail();
        });
        return;
    }

    runBlocking("正在切换到无线调试…", [serial] {
        backend::WirelessResult r;
        const bool ok = backend::enableWirelessDebug(serial, 5555, std::string(), r);
        logLine(ok ? LOG_SUCC : LOG_ERR, ok ? ("切换无线调试 · " + r.serial + " · 完成")
                                                 : ("切换无线调试 · 失败 · 原因：" + tailLine(r.message)));
        if (ok) {
            logLine(LOG_INFO, "无线调试 · 拔掉 USB 后仍可用 · adb -s " + r.serial + " 直连");
            std::lock_guard<std::recursive_mutex> guard(stateMutex());
            state().homeWireless = true;
            state().detail.serial = r.serial;
        }
    });
}

void actionSwitchSlot() {
    std::string serial;
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        serial = state().detail.serial;
    }
    runBlocking("正在读取 A/B 槽位…", [serial] {
        backend::SlotResult r;
        // 先只读，读到了再问要不要真切
        if (!backend::switchSlot(serial, false, r)) {
            logLine(LOG_ERR, "读取 A/B 槽位 · 失败 · 原因：" + tailLine(r.message));
            return;
        }
        {
            std::lock_guard<std::recursive_mutex> guard(stateMutex());
            state().homeAbSlot = r.current;
        }
        logLine(LOG_INFO, "读取 A/B 槽位 · 当前 " + r.current + " · 可用 " + r.other);

        // 真要切：bootctl 需要 root，先探测；没有 root 直接给替代路径，不要报一串 SELinux 拒绝
        const backend::RootStatus root = backend::probeRoot(serial);
        if (!root.active) {
            logLine(LOG_WARN, "切换槽位 · 跳过 · 原因：临时 root 未激活（先去「提权」页打一发，"
                              "或「重启到 Fastboot」后手工 fastboot --set-active" + r.other + "）");
            return;
        }
        backend::SlotResult done;
        if (backend::switchSlot(serial, true, done)) {
            logLine(LOG_SUCC, "切换槽位 · " + done.current + " → " + done.other + " · 完成");
        } else {
            logLine(LOG_ERR, "切换槽位 · 失败 · 原因：" + tailLine(done.message));
        }
    });
}

void actionUsb3Compat() {
    std::string serial;
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        serial = state().detail.serial;
    }
    if (serial.empty()) {
        logLine(LOG_WARN, "USB3.0 兼容检查 · 跳过 · 原因：没有可用设备（先插线）");
        return;
    }
    runBlocking("正在检查 USB 传输模式…", [serial] {
        backend::Usb3Result r;
        const bool ok = backend::usb3Compat(serial, false, r);
        logLine(ok ? LOG_SUCC : LOG_WARN, "USB3.0 兼容检查 · " + tailLine(r.message) +
                                              (ok ? " · 正常" : " · 注意"));
    });
}

void actionKeepScreen(bool on) {
    std::string serial;
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        serial = state().detail.serial;
    }
    runBlocking(on ? "正在开启保持亮屏…" : "正在关闭保持亮屏…", [serial, on] {
        std::string log;
        const bool ok = backend::keepScreenOn(serial, on, log);
        logLine(ok ? LOG_SUCC : LOG_ERR, std::string("保持亮屏 · ") + (on ? "开启" : "关闭") +
                                             (ok ? " · 完成" : (" · 失败 · 原因：" + tailLine(log))));
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        state().homeKeepScreen = ok && on;
    });
}

void actionCleanTemp() {
    std::string serial;
    {
        std::lock_guard<std::recursive_mutex> guard(stateMutex());
        serial = state().detail.serial;
    }
    runBlocking("正在清理设备端临时文件…", [serial] {
        std::string log;
        const int count = backend::cleanTempFiles(serial, log);


        logLine(count > 0 ? LOG_SUCC : LOG_INFO,
                std::string("清理设备临时文件 · 删除 ") + std::to_string(count) + " 项 · 完成");
    });
}

void actionSelfCheck() {
    runBlocking("正在自检…", [] {
        int problems = 0;
        const auto fail = [&problems](const std::string& what, const std::string& why) {
            ++problems;
            logLine(LOG_ERR, "自检 · " + what + " · 失败 · 原因：" + why);
        };

        // adb：路径必须存在
        const std::string adbExe = backend::adbPath();
        if (adbExe.empty() || !backend::fileExists(adbExe)) {
            fail("adb", adbExe.empty() ? std::string("找不到 adb.exe（资源包里没有 adb）")
                                       : ("找不到 " + adbExe));
        } else {
            logLine(LOG_INFO, "自检 · adb · " + adbExe + " · 存在");
        }

        // 关键资源目录
        for (const char* sub : {"roottool", "scrcpy"}) {
            const std::string path = backend::assets::dirOf(sub);
            if (!backend::fileExists(path)) {
                fail(std::string("资源 ") + sub, "找不到 " + path);
            }
        }

        // 加密资源包完整性（锁定形态下逐文件 AES-GCM 认证）
        const backend::IntegrityResult pak = backend::verifyBundle();
        if (!pak.locked) {
            logLine(LOG_INFO, "自检 · 资源形态 · 明文目录（开发模式）");
        } else if (pak.bad == 0) {
            logLine(LOG_SUCC, "自检 · 加密资源包 · " + std::to_string(pak.checked) +
                                  " 个文件全部通过认证");
        } else {
            fail("加密资源包", std::to_string(pak.bad) + " 个文件被改动 · 首例：" + pak.detail);
        }

        // scrcpy 能不能起来（版本号有回显即通过）
        if (backend::scrcpyAvailable()) {
            logLine(LOG_INFO, "自检 · scrcpy · 可用");
        } else {
            fail("scrcpy", "--version 无回显（文件缺失或被拦截）");
        }

        // 设备连接
        const std::vector<std::string> serials = backend::listDeviceSerials();
        if (serials.empty()) {
            logLine(LOG_WARN, "自检 · 设备 · 未连接（不影响其它项）");
        } else {
            logLine(LOG_SUCC, "自检 · 设备 · " + std::to_string(serials.size()) + " 台在线");
        }

        logLine(problems == 0 ? LOG_SUCC : LOG_WARN,
                problems == 0
                    ? std::string("自检 · 全部通过 · 完成")
                    : ("自检 · 完成 · 发现 " + std::to_string(problems) + " 项异常"));
    });
}

} // namespace app

