#include "backend/process.h"

#include <windows.h>
#include <shellapi.h>

#include <algorithm>
#include <atomic>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <thread>

namespace backend {
namespace {

// 兜底代码页：本机 CP_ACP 可能是 65001（Windows 设置里开了「Beta: 使用 Unicode UTF-8」），
// 这时拿 CP_ACP 去解 GBK 字节会把每个汉字都变成 U+FFFD（界面上就是一串「?」/「λ」）。
// 这种机器退回 OEM 代码页（中文机器 = 936），实在拿不到才硬用 936。
unsigned int fallbackCodePage() {
    const unsigned int acp = GetACP();
    if (acp != CP_UTF8 && acp != 0) return acp;
    const unsigned int oem = GetOEMCP();
    if (oem != CP_UTF8 && oem != 0) return oem;
    return 936;
}

// 严格转码：遇到非法字节就失败（MB_ERR_INVALID_CHARS），用来在多个候选代码页里挑对的那个。
bool strictCodePageToUtf8(const std::string& raw, unsigned int codePage, std::string& out) {
    if (raw.empty()) { out.clear(); return true; }
    if (codePage == 0 || codePage == CP_UTF8) return false;
    const int wlen = MultiByteToWideChar(codePage, MB_ERR_INVALID_CHARS, raw.data(),
                                         static_cast<int>(raw.size()), nullptr, 0);
    if (wlen <= 0) return false;
    std::wstring wide(static_cast<size_t>(wlen), L'\0');
    if (MultiByteToWideChar(codePage, MB_ERR_INVALID_CHARS, raw.data(), static_cast<int>(raw.size()),
                            wide.data(), wlen) <= 0) return false;
    const int ulen = WideCharToMultiByte(CP_UTF8, 0, wide.data(), wlen, nullptr, 0, nullptr, nullptr);
    if (ulen <= 0) return false;
    std::string utf8(static_cast<size_t>(ulen), '\0');
    WideCharToMultiByte(CP_UTF8, 0, wide.data(), wlen, utf8.data(), ulen, nullptr, nullptr);
    out.swap(utf8);
    return true;
}

std::string codePageToUtf8(const std::string& raw, unsigned int codePage) {
    std::string out;
    if (strictCodePageToUtf8(raw, codePage, out)) return out;
    if (raw.empty()) return {};
    const int wlen = MultiByteToWideChar(codePage, 0, raw.data(), static_cast<int>(raw.size()), nullptr, 0);
    if (wlen <= 0) return raw;
    std::wstring wide(static_cast<size_t>(wlen), L'\0');
    MultiByteToWideChar(codePage, 0, raw.data(), static_cast<int>(raw.size()), wide.data(), wlen);
    const int ulen = WideCharToMultiByte(CP_UTF8, 0, wide.data(), wlen, nullptr, 0, nullptr, nullptr);
    if (ulen <= 0) return raw;
    std::string utf8(static_cast<size_t>(ulen), '\0');
    WideCharToMultiByte(CP_UTF8, 0, wide.data(), wlen, utf8.data(), ulen, nullptr, nullptr);
    return utf8;
}

// 把「非 UTF-8 的一段原始字节」转成 UTF-8：按候选代码页逐个严格试，
// 谁不产生替换字符就用谁。顺序：系统兜底页(936) -> 936 -> ACP -> OEMCP -> 1252。
std::string ansiSegmentToUtf8(const std::string& raw) {
    if (raw.empty()) return {};
    const unsigned int candidates[] = {fallbackCodePage(), 936u, GetACP(), GetOEMCP(), 1252u};
    for (unsigned int cp : candidates) {
        std::string out;
        if (strictCodePageToUtf8(raw, cp, out)) return out;
    }
    return codePageToUtf8(raw, fallbackCodePage());
}

bool looksLikeUtf8(const std::string& s) {
    size_t i = 0;
    while (i < s.size()) {
        const unsigned char c = static_cast<unsigned char>(s[i]);
        int extra = 0;
        if (c < 0x80) extra = 0;
        else if ((c & 0xE0) == 0xC0) extra = 1;
        else if ((c & 0xF0) == 0xE0) extra = 2;
        else if ((c & 0xF8) == 0xF0) extra = 3;
        else return false;
        if (extra == 0) { i += 1; continue; }
        if (i + static_cast<size_t>(extra) >= s.size()) return false;
        for (int k = 1; k <= extra; ++k) {
            if ((static_cast<unsigned char>(s[i + k]) & 0xC0) != 0x80) return false;
        }
        i += static_cast<size_t>(extra) + 1;
    }
    return true;
}


// 判断 s[i] 起的单个 UTF-8 字符是否结构合法；合法时 advance = 该字符字节数。
bool utf8CharAdvance(const std::string& s, size_t i, size_t& advance) {
    const unsigned char c = static_cast<unsigned char>(s[i]);
    size_t extra = 0;
    if (c < 0x80) { advance = 1; return true; }
    if ((c & 0xE0) == 0xC0) extra = 1;
    else if ((c & 0xF0) == 0xE0) extra = 2;
    else if ((c & 0xF8) == 0xF0) extra = 3;
    else return false;
    if (i + extra >= s.size()) return false;
    for (size_t k = 1; k <= extra; ++k) {
        if ((static_cast<unsigned char>(s[i + k]) & 0xC0) != 0x80) return false;
    }
    advance = extra + 1;
    return true;
}

// 找一个可以重新开始按 UTF-8 解析的位置：
// 只有「结构合法的 3 字节及以上字符」才被认为是 UTF-8 文本的起点，
// 避免把 GBK 双字节里偶然长得像 UTF-8 两字节序列的字节对误判成 UTF-8。
size_t findUtf8Resume(const std::string& s, size_t from) {
    for (size_t i = from; i < s.size(); ++i) {
        size_t advance = 0;
        if (!utf8CharAdvance(s, i, advance)) continue;
        if (advance >= 3) return i;
    }
    return s.size();
}

struct StreamJob {
    unsigned long long id = 0;
    std::atomic<HANDLE> process{nullptr};
    std::thread worker;
    std::atomic<bool> done{false};
    int exitCode = -1;
};

std::mutex g_jobsMutex;
std::vector<StreamJob*> g_jobs;
std::atomic<unsigned long long> g_nextId{1};

} // namespace

std::string toUtf8(const std::string& raw) {
    if (raw.empty()) return {};
    if (looksLikeUtf8(raw)) return raw;
    // 逐段转换：合法的 UTF-8 片段原样保留，非法片段按系统 ANSI（中文机器 = GBK/CP936）解码。
    // 之前是整串二选一，一旦出现「UTF-8 前缀 + ANSI 尾部」（PowerShell 5.1 解析失败时
    // 脚本顶部的 OutputEncoding 还没生效，stderr 走 ANSI）就会把正确的 UTF-8 部分
    // 再按 CP_ACP 转一遍，直接转成 mojibake，日志面板与 logs\run-*.log 同时花掉。
    std::string out;
    out.reserve(raw.size());
    size_t cursor = 0;
    while (cursor < raw.size()) {
        const unsigned char lead = static_cast<unsigned char>(raw[cursor]);
        if (lead < 0x80) {
            size_t end = cursor;
            while (end < raw.size() && static_cast<unsigned char>(raw[end]) < 0x80) ++end;
            out.append(raw, cursor, end - cursor);
            cursor = end;
            continue;
        }
        // 只有「结构合法的 3 字节及以上字符」才算 UTF-8 文本起点。
        // 2 字节序列不认：GBK 里像 0xD2 0xBB 这种字节对在结构上完全符合 UTF-8 双字节字符，
        // 若放行就会把整段 GBK 中文按 UTF-8 解成乱码。
        size_t advance = 0;
        if (utf8CharAdvance(raw, cursor, advance) && advance >= 3) {
            out.append(raw, cursor, advance);
            cursor += advance;
            continue;
        }
        const size_t resume = findUtf8Resume(raw, cursor + 1);
        // 兜底不能写 CP_ACP：开了「Beta: 使用 Unicode UTF-8」的机器 ACP 就是 65001，
        // 等于拿 UTF-8 去解 GBK 字节，整段中文全变 U+FFFD。用 ansiSegmentToUtf8 逐候选代码页严格试。
        out += ansiSegmentToUtf8(raw.substr(cursor, resume - cursor));
        cursor = resume;
    }
    if (out.empty()) return raw;
    return out;
}

std::wstring widen(const std::string& text) {
    if (text.empty()) return {};
    const int wlen = MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), nullptr, 0);
    if (wlen <= 0) return {};
    std::wstring wide(static_cast<size_t>(wlen), L'\0');
    MultiByteToWideChar(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), wide.data(), wlen);
    return wide;
}

std::string narrow(const std::wstring& text) {
    if (text.empty()) return {};
    const int ulen = WideCharToMultiByte(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), nullptr, 0, nullptr, nullptr);
    if (ulen <= 0) return {};
    std::string utf8(static_cast<size_t>(ulen), '\0');
    WideCharToMultiByte(CP_UTF8, 0, text.data(), static_cast<int>(text.size()), utf8.data(), ulen, nullptr, nullptr);
    return utf8;
}

ProcessResult run(const std::wstring& commandLine, unsigned int timeoutMs, bool hideWindow) {
    ProcessResult result;

    SECURITY_ATTRIBUTES sa{};
    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;

    HANDLE readPipe = nullptr;
    HANDLE writePipe = nullptr;
    if (!CreatePipe(&readPipe, &writePipe, &sa, 0)) {
        result.error = "CreatePipe 失败";
        return result;
    }
    SetHandleInformation(readPipe, HANDLE_FLAG_INHERIT, 0);

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
    si.wShowWindow = hideWindow ? SW_HIDE : SW_SHOWNORMAL;
    si.hStdOutput = writePipe;
    si.hStdError = writePipe;
    si.hStdInput = nullptr;

    PROCESS_INFORMATION pi{};
    std::wstring mutableCmd = commandLine;
    const BOOL ok = CreateProcessW(nullptr, mutableCmd.data(), nullptr, nullptr, TRUE,
                                   CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi);
    CloseHandle(writePipe);

    if (!ok) {
        CloseHandle(readPipe);
        char buf[256] = {};
        std::snprintf(buf, sizeof(buf), "CreateProcess 失败，错误码 %lu", GetLastError());
        result.error = buf;
        return result;
    }
    result.started = true;

    std::string buffer;
    char chunk[4096];
    DWORD read = 0;
    const ULONGLONG start = GetTickCount64();

    while (true) {
        const DWORD avail = [&] {
            DWORD n = 0;
            if (!PeekNamedPipe(readPipe, nullptr, 0, nullptr, &n, nullptr)) return (DWORD)0;
            return n;
        }();
        if (avail > 0) {
            if (!ReadFile(readPipe, chunk, std::min<DWORD>(avail, sizeof(chunk)), &read, nullptr) || read == 0) break;
            buffer.append(chunk, read);
        } else {
            if (WaitForSingleObject(pi.hProcess, 20) == WAIT_OBJECT_0) {
                // 进程退出后把残留数据读完
                while (ReadFile(readPipe, chunk, sizeof(chunk), &read, nullptr) && read > 0) {
                    buffer.append(chunk, read);
                }
                break;
            }
        }
        if (timeoutMs > 0 && (GetTickCount64() - start) > timeoutMs) {
            TerminateProcess(pi.hProcess, 1);
            buffer += "\n[超时，已终止]";
            break;
        }
    }

    DWORD code = 1;
    GetExitCodeProcess(pi.hProcess, &code);
    result.exitCode = static_cast<int>(code);
    result.out = toUtf8(buffer);

    CloseHandle(readPipe);
    CloseHandle(pi.hThread);
    CloseHandle(pi.hProcess);
    return result;
}

unsigned long long runStreaming(const std::wstring& commandLine,
                                void (*onLine)(const std::string&, void*),
                                void* user,
                                void (*onDone)(int, void*),
                                const std::wstring& workDir) {
    auto* job = new StreamJob();
    job->id = g_nextId.fetch_add(1);

    const std::wstring cmd = commandLine;
    job->worker = std::thread([job, cmd, workDir, onLine, user, onDone] {
        // 真·流式：边读管道边按行回调。
        // 之前是等进程退出才一次性切行，提权那种动辄几分钟的流程在界面上毫无动静，
        // 用户会以为卡死然后重复点/关窗口，制造一堆孤儿进程。
        SECURITY_ATTRIBUTES sa{};
        sa.nLength = sizeof(sa);
        sa.bInheritHandle = TRUE;

        HANDLE readPipe = nullptr, writePipe = nullptr;
        if (!CreatePipe(&readPipe, &writePipe, &sa, 0)) {
            job->exitCode = -1;
            job->done.store(true);
            if (onDone) onDone(-1, user);
            return;
        }
        SetHandleInformation(readPipe, HANDLE_FLAG_INHERIT, 0);

        STARTUPINFOW si{};
        si.cb = sizeof(si);
        si.dwFlags = STARTF_USESTDHANDLES | STARTF_USESHOWWINDOW;
        si.wShowWindow = SW_HIDE;
        si.hStdOutput = writePipe;
        si.hStdError = writePipe;
        si.hStdInput = nullptr;

        PROCESS_INFORMATION pi{};
        std::wstring mutableCmd = cmd;
        const BOOL ok = CreateProcessW(nullptr, mutableCmd.data(), nullptr, nullptr, TRUE,
                                       CREATE_NO_WINDOW, nullptr,
                                       workDir.empty() ? nullptr : workDir.c_str(), &si, &pi);
        CloseHandle(writePipe);
        if (!ok) {
            CloseHandle(readPipe);
            job->exitCode = -1;
            job->done.store(true);
            if (onDone) onDone(-1, user);
            return;
        }
        job->process.store(pi.hProcess);

        std::string acc;
        char chunk[4096];
        DWORD read = 0;
        auto flushLines = [&](bool force) {
            size_t start = 0;
            for (size_t i = 0; i < acc.size(); ++i) {
                if (acc[i] == '\n' || acc[i] == '\r') {
                    std::string line = acc.substr(start, i - start);
                    while (!line.empty() && (line.back() == ' ' || line.back() == '\t')) line.pop_back();
                    // 子进程输出的编码是混的：脚本自己设了 OutputEncoding 才是 UTF-8，
                    // 解析失败/未设置时是系统 ANSI。这里在源头统一转一次，
                    // 保证所有 runStreaming 调用点（提权、投屏……）拿到的都是 UTF-8。
                    if (!line.empty() && onLine) onLine(toUtf8(line), user);
                    start = i + 1;
                }
            }
            acc.erase(0, start);
            if (force && !acc.empty()) {
                if (onLine) onLine(toUtf8(acc), user);
                acc.clear();
            }
        };

        while (true) {
            const DWORD avail = [&] {
                DWORD n = 0;
                if (!PeekNamedPipe(readPipe, nullptr, 0, nullptr, &n, nullptr)) return (DWORD)0;
                return n;
            }();
            if (avail > 0) {
                if (!ReadFile(readPipe, chunk, std::min<DWORD>(avail, sizeof(chunk)), &read, nullptr) || read == 0) break;
                acc.append(chunk, read);
                flushLines(false);
            } else if (WaitForSingleObject(pi.hProcess, 30) == WAIT_OBJECT_0) {
                while (ReadFile(readPipe, chunk, sizeof(chunk), &read, nullptr) && read > 0) {
                    acc.append(chunk, read);
                    flushLines(false);
                }
                break;
            }
        }
        flushLines(true);

        DWORD code = 1;
        GetExitCodeProcess(pi.hProcess, &code);
        job->process.store(nullptr);
        CloseHandle(readPipe);
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);

        job->exitCode = static_cast<int>(code);
        job->done.store(true);
        if (onDone) onDone(job->exitCode, user);
    });
    job->worker.detach();

    std::lock_guard<std::mutex> lock(g_jobsMutex);
    g_jobs.push_back(job);
    return job->id;
}

bool cancelStreaming(unsigned long long id) {
    std::lock_guard<std::mutex> lock(g_jobsMutex);
    for (auto* job : g_jobs) {
        if (job->id != id) continue;
        HANDLE h = job->process.load();
        if (!h) return false;
        TerminateProcess(h, 1);
        return true;
    }
    return false;
}

bool streamingRunning(unsigned long long id) {
    std::lock_guard<std::mutex> lock(g_jobsMutex);
    for (auto* job : g_jobs) {
        if (job->id == id) return !job->done.load();
    }
    return false;
}

void pollStreaming() {
    std::lock_guard<std::mutex> lock(g_jobsMutex);
    for (auto it = g_jobs.begin(); it != g_jobs.end();) {
        if ((*it)->done.load()) it = g_jobs.erase(it);
        else ++it;
    }
}

bool isAdmin() {
    BOOL admin = FALSE;
    PSID group = nullptr;
    SID_IDENTIFIER_AUTHORITY authority = SECURITY_NT_AUTHORITY;
    if (AllocateAndInitializeSid(&authority, 2, SECURITY_BUILTIN_DOMAIN_RID, DOMAIN_ALIAS_RID_ADMINS,
                                 0, 0, 0, 0, 0, 0, &group)) {
        CheckTokenMembership(nullptr, group, &admin);
        FreeSid(group);
    }
    return admin != FALSE;
}

bool relaunchAsAdmin(const std::string& args) {
    wchar_t path[MAX_PATH] = {};
    GetModuleFileNameW(nullptr, path, MAX_PATH);
    SHELLEXECUTEINFOW info{};
    info.cbSize = sizeof(info);
    info.lpVerb = L"runas";
    info.lpFile = path;
    const std::wstring wideArgs = widen(args);
    info.lpParameters = wideArgs.empty() ? nullptr : wideArgs.c_str();
    info.nShow = SW_SHOWNORMAL;
    info.fMask = SEE_MASK_NOCLOSEPROCESS;
    if (!ShellExecuteExW(&info)) return false;
    if (info.hProcess) CloseHandle(info.hProcess);
    return true;
}

} // namespace backend
