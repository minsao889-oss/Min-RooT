#pragma once
// Win32 子进程封装：同步执行并捕获 stdout/stderr，支持 UTF-8 输出解码。
#include <string>
#include <vector>

namespace backend {

struct ProcessResult {
    int exitCode = -1;
    std::string out;     // 合并后的 stdout + stderr（UTF-8）
    bool started = false;
    std::string error;   // 启动失败原因（UTF-8）
};

// 把 Windows 本地编码（ANSI/GBK）或 UTF-8 的字节流统一转成 UTF-8
std::string toUtf8(const std::string& raw);

// 把 UTF-8 字符串转成 std::wstring（用于 Win32 API）
std::wstring widen(const std::string& text);
// 把宽字符转成 UTF-8
std::string narrow(const std::wstring& text);

// 同步执行命令行，等待结束并收集全部输出。
// hideWindow=true 时不弹控制台窗口。
ProcessResult run(const std::wstring& commandLine, unsigned int timeoutMs = 180000, bool hideWindow = true);

// 在后台线程异步执行，onLine 对每一行输出回调，onDone 结束时回调。
// workDir 非空时以该目录作为子进程工作目录（scrcpy 这类要靠同目录找 scrcpy-server 的程序必须传）。
// 返回任务 id；可调用 cancelStreaming 中止。
unsigned long long runStreaming(const std::wstring& commandLine,
                                void (*onLine)(const std::string&, void*) = nullptr,
                                void* user = nullptr,
                                void (*onDone)(int, void*) = nullptr,
                                const std::wstring& workDir = std::wstring());
// 结束指定任务（TerminateProcess）；返回是否真的发了终止信号
bool cancelStreaming(unsigned long long id);
// 任务是否还在跑
bool streamingRunning(unsigned long long id);
void pollStreaming();

// 当前进程是否管理员
bool isAdmin();
// 以管理员身份重启自己（会退出当前进程）
bool relaunchAsAdmin(const std::string& args);

} // namespace backend
