#pragma once
// 液态玻璃胶囊开关的「物理层」：AndroidLiquidGlass LiquidToggle 弹簧动画的 1:1 移植。
//
// 与旧实现的差别：旋钮位置不再靠 .transition(motion()) 补间（那只是固定时长缓动，
// 没有过冲/回弹/按压放大），改由 5 条半隐式欧拉积分的弹簧逐帧算出：
//   value  旋钮位置 0..1      k=1000 zeta=1.0
//   press  按压量   0..1      k=300  zeta=0.5   ← 过冲来源
//   scaleX 横向缩放  1..1.5    k=250  zeta=0.6
//   scaleY 纵向缩放  1..1.5    k=250  zeta=0.7
//   speed  速度平滑            k=300  zeta=0.5   → 速度拉伸（快拉时把手拉扁）
//
// 每帧驱动用 Element::onFrame（core/dsl.h:770，字段 core/dsl.h:187），由
// Runtime::updateFrameCallback 在每帧 update 阶段回调；只有「没收敛」时才挂，
// 收敛后不挂 → 框架可以停帧休眠，静止的开关不空转（同 heart_switch.h:136 的做法）。
//
// 状态存在 Ui::state<T>（core/dsl.h:1502）里，按元素 id 分桶，引用在堆上稳定，
// 所以 lambda 里捕获引用是安全的（compose 每帧重建 Element，但 state 不重建）。

#include "app.h"

#include <algorithm>
#include <cmath>
#include <functional>
#include <string>
#include <vector>

// ---- 临时诊断开关：确认 onFrame / onPress 是否真的被调用（验证完必须改回 0）----
#define LIQUID_TOGGLE_PROBE 0
#if LIQUID_TOGGLE_PROBE
#include <cstdarg>
#include <cstdio>
#endif

namespace app {
namespace liquid {

#if LIQUID_TOGGLE_PROBE
inline void probe(const char* fmt, ...) {
    if (FILE* f = std::fopen("C:\\srtbuild\\toggle_dbg.log", "a")) {
        va_list ap;
        va_start(ap, fmt);
        std::vfprintf(f, fmt, ap);
        va_end(ap);
        std::fputc('\n', f);
        std::fclose(f);
    }
}
#else
inline void probe(const char*, ...) {}
#endif

// ---- 几何：与 AndroidLiquidGlass 参考实现一致，不要动 ----
constexpr float kTrackW = 64.0f;
constexpr float kTrackH = 28.0f;
constexpr float kKnobW = 40.0f;
constexpr float kKnobH = 24.0f;
constexpr float kPad = 2.0f;
constexpr float kTravel = kTrackW - kKnobW - kPad * 2.0f;  // 20
constexpr float kPressScale = 1.5f;                        // 按下时旋钮最大放大

// ---- 弹簧参数（drag = 2 * zeta * sqrt(k)）----
constexpr float kValueK = 1000.0f;
constexpr float kValueZeta = 1.0f;
constexpr float kPressK = 300.0f;
constexpr float kPressZeta = 0.5f;
constexpr float kScaleXK = 250.0f;
constexpr float kScaleXZeta = 0.6f;
constexpr float kScaleYK = 250.0f;
constexpr float kScaleYZeta = 0.7f;
constexpr float kSpeedK = 300.0f;
constexpr float kSpeedZeta = 0.5f;

// ---- 收敛 / 拖拽参数 ----
constexpr float kEps = 0.001f;          // DRAG_VISIBLE：位置收敛阈值
constexpr float kSettleSpan = 0.025f;   // DRAG_SETTLE_SPAN：位置到位后才松 press
constexpr float kDragStartDp = 3.0f;    // 拖过 3dp 才算拖拽
constexpr float kStretchRef = 50.0f;    // v = speed / 50
constexpr float kMaxDt = 0.064f;        // 单帧 dt 上限（防卡顿后炸开）
constexpr float kSubstepRate = 720.0f;  // 子步数 ≈ dt * 720
constexpr float kSnapVelocity = 62.5f;  // |v| <= eps * 62.5 视为静止

inline float clamp01(float v) { return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v); }

struct Spring {
    float value = 0.0f;
    float target = 0.0f;
    float velocity = 0.0f;
    float k = 1.0f;
    float drag = 2.0f;

    void init(float stiffness, float zeta, float initial) {
        k = stiffness;
        drag = 2.0f * zeta * std::sqrt(stiffness);
        value = initial;
        target = initial;
        velocity = 0.0f;
    }

    // 半隐式欧拉 + 子步（逐字等价于 AndroidLiquidGlass 的 SpringAnimator）
    void advance(float dt) {
        dt = std::min(dt, kMaxDt);
        if (!(dt > 0.0f)) return;
        int substeps = static_cast<int>(dt * kSubstepRate + 0.5f);
        substeps = std::max(1, std::min(64, substeps));
        const float h = dt / static_cast<float>(substeps);
        for (int i = 0; i < substeps; ++i) {
            const float offset = value - target;
            const float accel = -k * offset - drag * velocity;  // ω2 == k
            velocity += accel * h;
            value += velocity * h;
        }
        if (settled()) {
            value = target;
            velocity = 0.0f;
        }
    }

    bool settled() const {
        return std::fabs(value - target) <= kEps && std::fabs(velocity) <= kEps * kSnapVelocity;
    }
};

struct ToggleState {
    bool init = false;
    Spring value;
    Spring press;
    Spring scaleX;
    Spring scaleY;
    Spring speed;
    bool dragging = false;      // 本次按下是否已进入拖拽
    bool pendingRelease = false;  // 已松手，等 value 到位后再让 press 回落
    bool dragSeeded = false;    // 首帧 onDrag 只用来对齐基线（避开按下瞬间的指针跳变）
    float dragTotal0 = 0.0f;    // 首帧 onDrag 的 totalX，作为拖拽零点（像素）
    float pressBase = 0.0f;     // 按下瞬间的 value，拖拽位移以它为基准
    float dragDp = 0.0f;        // 累计拖拽位移（dp）
    float pixelScale = 1.0f;    // 每 dp 多少像素：onPress 用 bounds.width / 64 反推
};

inline void reset(ToggleState& s, bool on) {
    s.init = true;
    s.value.init(kValueK, kValueZeta, on ? 1.0f : 0.0f);
    s.press.init(kPressK, kPressZeta, 0.0f);
    s.scaleX.init(kScaleXK, kScaleXZeta, 1.0f);
    s.scaleY.init(kScaleYK, kScaleYZeta, 1.0f);
    s.speed.init(kSpeedK, kSpeedZeta, 0.0f);
    s.dragging = false;
    s.pendingRelease = false;
    s.dragSeeded = false;
    s.dragTotal0 = 0.0f;
    s.pressBase = 0.0f;
    s.dragDp = 0.0f;
    s.pixelScale = 1.0f;
}

inline bool allSettled(const ToggleState& s) {
    return !s.dragging && !s.pendingRelease && s.value.settled() && s.press.settled() &&
           s.scaleX.settled() && s.scaleY.settled() && s.speed.settled();
}

inline void tick(ToggleState& s, float dt) {
    s.value.advance(dt);
    // speed 跟的是旋钮的实际速度 → 速度拉伸
    s.speed.target = std::fabs(s.value.velocity);
    // 缩放目标由 press 的当前值决定（press 自己会过冲，缩放跟着一起弹）
    s.scaleX.target = 1.0f + s.press.value * (kPressScale - 1.0f);
    s.scaleY.target = s.scaleX.target;
    s.speed.advance(dt);
    s.press.advance(dt);
    s.scaleX.advance(dt);
    s.scaleY.advance(dt);
}

inline void beginPress(ToggleState& s, float pixelScale) {
    s.pixelScale = pixelScale > 0.0f ? pixelScale : 1.0f;
    s.dragDp = 0.0f;
    s.dragging = false;
    s.dragSeeded = false;
    s.dragTotal0 = 0.0f;
    s.pressBase = s.value.value;
    s.pendingRelease = false;
    s.press.target = 1.0f;
}

inline void endPress(ToggleState& s) {
    s.dragging = false;
    s.dragDp = 0.0f;
    s.pendingRelease = true;  // press/scale 等 value 收敛后再回落
}

// 画一个开关。x,y 是轨道左上角的绝对坐标；on 是业务侧当前状态。
// hover/pressed 给两处调用点各自的口径留了默认值（首页走 hoverTint()，镜像页传自己的）。
inline void toggle(eui::Ui& ui, const std::string& id, float x, float y, bool on,
                   std::function<void()> onClick,
                   eui::Color hover = hoverTint(), eui::Color pressed = pressedTint(),
                   bool panelHit = false) {
    ToggleState& fx = ui.state<ToggleState>(id + ".spring");
    if (!fx.init) reset(fx, on);
    if (!fx.dragging && !fx.pendingRelease) fx.value.target = on ? 1.0f : 0.0f;
    probe("COMPOSE %s on=%d settled=%d v=%.3f/%.3f p=%.3f/%.3f sx=%.3f", id.c_str(), on ? 1 : 0,
          allSettled(fx) ? 1 : 0, fx.value.value, fx.value.target, fx.press.value, fx.press.target,
          fx.scaleX.value);

    // 子元素坐标相对这层 stack：与旧实现同构（轨道/命中层在 0,0，旋钮在 (knobX,knobY)）。
    // 玻璃的背景采样基准就是这层 stack，绝对坐标会丢掉边缘高光/折射。
    const float knobX = kPad + kTravel * clamp01(fx.value.value);
    const float knobY = (kTrackH - kKnobH) * 0.5f;  // 2
    const float v = fx.speed.value * (1.0f / kStretchRef);
    const float stretchX = 1.0f - std::clamp(v * 0.75f, -0.2f, 0.2f);
    const float stretchY = 1.0f - std::clamp(v * 0.25f, -0.2f, 0.2f);
    const float sx = fx.scaleX.value * stretchX;
    const float sy = fx.scaleY.value * stretchY;
    const bool animating = !allSettled(fx);

    ui.stack(id + ".box")
        .position(x, y)
        .size(kTrackW, kTrackH)
        .content([&ui, &fx, id, on, onClick, knobX, knobY, sx, sy, animating, hover, pressed, panelHit] {
            // ── 配色：照搬 AndroidLiquidGlass LiquidToggle 的令牌 ──────────────────
            // 轨道：开 = 绿色 accent（亮色 #34C759 / 暗色 #30D158）
            //       关 = 中性灰（亮色 #787878 @0.20 / 暗色 #787880 @0.36）
            // 旋钮：静止 = 白色实体面（alpha≈1），按下 = 白色面淡出、露出玻璃
            // 之前这里是跟主题 primary（蓝色）走的，所以"开"也是灰蓝色，看不出开关语义。
            const bool light = !theme().dark;
            const eui::Color accent = light ? eui::Color{0.204f, 0.780f, 0.349f, 0.88f}   // #34C759
                                           : eui::Color{0.188f, 0.820f, 0.345f, 0.86f};  // #30D158
            const eui::Color neutral = light ? eui::Color{0.520f, 0.535f, 0.585f, 0.58f}
                                            : eui::Color{0.470f, 0.470f, 0.500f, 0.36f}; // #787880 36%
            // 开关切换过程里颜色也要跟着 value 走，不然"半开"时颜色是跳变的
            const float t = clamp01(fx.value.value);
            eui::Color trackColor;
            trackColor.r = neutral.r + (accent.r - neutral.r) * t;
            trackColor.g = neutral.g + (accent.g - neutral.g) * t;
            trackColor.b = neutral.b + (accent.b - neutral.b) * t;
            trackColor.a = neutral.a + (accent.a - neutral.a) * t;

            // ---- track: flat frosted capsule, no specular highlight ----
            ui.rect(id + ".track")
                .size(kTrackW, kTrackH)
                .radius(kTrackH * 0.5f)
                .color(trackColor)
                .border(1.0f, light ? eui::Color{1.0f, 1.0f, 1.0f, 0.30f}
                                    : eui::Color{1.0f, 1.0f, 1.0f, 0.14f})
                .shadow(8.0f, 0.0f, 2.0f, eui::Color{0.0f, 0.0f, 0.0f, light ? 0.10f : 0.22f})
                .transition(motion())
                .build();

            // ---- knob: flat glass face; no top gloss ----
            const eui::Color knobSurface = {1.0f, 1.0f, 1.0f,
                                            0.97f - 0.18f * clamp01(fx.press.value)};
            ui.rect(id + ".knob")
                .position(knobX, knobY)
                .size(kKnobW, kKnobH)
                .radius(kKnobH * 0.5f)
                .scale(sx, sy)
                .transformOrigin(0.5f, 0.5f)
                .color(knobSurface)
                .border(1.0f, eui::Color{1.0f, 1.0f, 1.0f, light ? 0.55f : 0.40f})
                .shadow(7.0f, 0.0f, 2.5f, eui::Color{0.0f, 0.0f, 0.0f, light ? 0.22f : 0.36f})
                .build();

            // ---- hit layer: press / drag / release + per-frame spring integration ----
            eui::Color hitColor = panelHit ? components::theme::withAlpha(theme().text, 0.0f) : hover;
            hitColor.a = 0.0f;
            core::dsl::RectBuilder hit =
                panelHit ? components::panel(ui, id + ".hit", theme()) : ui.rect(id + ".hit");
            hit.size(kTrackW, kTrackH)
                .radius(kTrackH * 0.5f)
                .color(hitColor)
                .interactive(true)
                .hoverColor(hover)
                .pressedColor(pressed)
                .onPress([&fx, id](const eui::PointerEvent&, const eui::Rect& bounds) {
                    probe("PRESS %s bounds=%.1fx%.1f", id.c_str(), bounds.width, bounds.height);
                    beginPress(fx, bounds.width / kTrackW);
                })
                .onDrag([&fx](const core::dsl::DragEvent& event) {
                    if (!fx.dragSeeded) {
                        fx.dragSeeded = true;
                        fx.dragTotal0 = static_cast<float>(event.totalX);
                    }
                    fx.dragDp = (static_cast<float>(event.totalX) - fx.dragTotal0) / fx.pixelScale;
                    if (!fx.dragging && std::fabs(fx.dragDp) >= kDragStartDp) fx.dragging = true;
                    if (fx.dragging) fx.value.target = clamp01(fx.pressBase + fx.dragDp / kTravel);
                })
                .onRelease([&fx, id, on, onClick](const eui::PointerEvent&, const eui::Rect&) {
                    const bool flip = fx.dragging && ((fx.value.value >= 0.5f) != on);
                    fx.value.target = (on != flip) ? 1.0f : 0.0f;
                    probe("RELEASE %s dragging=%d flip=%d on=%d v=%.3f tgt=%.3f", id.c_str(),
                          fx.dragging ? 1 : 0, flip ? 1 : 0, on ? 1 : 0, fx.value.value,
                          fx.value.target);
                    if (flip || !fx.dragging) {
                        if (onClick) onClick();
                    }
                    endPress(fx);
                });
            if (animating) {
                hit.onFrame([&fx, id](float dt) {
                    probe("FRAME %s dt=%.4f", id.c_str(), dt);
                    tick(fx, dt);
                    // release waits for the knob to arrive, then press/scale spring back
                    if (fx.pendingRelease &&
                        std::fabs(fx.value.value - fx.value.target) <= kSettleSpan) {
                        fx.pendingRelease = false;
                        fx.press.target = 0.0f;
                        probe("IDLE %s", id.c_str());
                    }
                });
            }
            hit.build();
        }).build();
}


// ============================================================ card glass
// Large panels/cards: same layered glass as buttons but wider blur radius,
// softer rim highlight and a deeper cast shadow so they float above the video.
// ---------------------------------------------------------------- frosted glass card
// Card look: vertical frosted gradient (lighter top) + bright rim + soft shadow.
// We do NOT use .glass(): the framework renderGlass swallows the border and its
// layers produce no pixels for these element sizes (verified by A/B tests).
inline void glassCard(eui::Ui& ui, const std::string& id, float x, float y, float w, float h,
                      float radius, const eui::Color& tint) {
    const bool light = !theme().dark;
    const float a = tint.a;
    // Light theme: frosted white panel (keeps dark text readable).
    // Dark theme: translucent dark panel (matches the original contrast so faint
    // captions stay legible) with a bright rim to read as glass.
    const eui::Color top = light
        ? eui::Color{1.0f, 1.0f, 1.0f, std::min(0.62f, a * 0.55f + 0.30f)}
        : eui::Color{0.086f, 0.102f, 0.137f, 0.46f};
    const eui::Color bottom = light
        ? eui::Color{1.0f, 1.0f, 1.0f, std::max(0.34f, a * 0.35f + 0.26f)}
        : eui::Color{0.051f, 0.063f, 0.090f, 0.50f};
    // Soft shadow as three nested layers drawn BEFORE the frosted face.
    // The face itself uses the framework blur path, which forces alpha=1 and
    // mixes the blurred backdrop with the fill; putting the shadow on the same
    // element made it bleed into that mix and turned the big cards grey.
    for (int i = 2; i >= 1; --i) {
        const float pad = static_cast<float>(i) * 6.0f;
        ui.rect(id + ".soft" + std::to_string(i))
            .position(x - pad, y - pad + 9.0f)
            .size(w + pad * 2.0f, h + pad * 2.0f)
            .radius(radius + pad)
            .color(eui::Color{0.0f, 0.0f, 0.0f, (light ? 0.030f : 0.075f) * static_cast<float>(3 - i)})
            .build();
    }
    ui.rect(id)
        .position(x, y).size(w, h).radius(radius)
        .gradient(top, bottom)
        .blur(0.0f)
        .border(2.0f, eui::Color{1.0f, 1.0f, 1.0f, light ? 1.0f : 0.18f})
        .shadow(0.0f, 0.0f, 0.0f, eui::Color{0.0f, 0.0f, 0.0f, 0.0f})
        .build();
    ui.rect(id + ".bevel")
        .position(x + 3.5f, y + 3.5f).size(std::max(1.0f, w - 7.0f), std::max(1.0f, h - 7.0f))
        .radius(std::max(1.0f, radius - 3.5f))
        .color({0.0f, 0.0f, 0.0f, 0.0f})
        .border(1.0f, eui::Color{1.0f, 1.0f, 1.0f, light ? 0.60f : 0.10f})
        .build();
    const float sh = std::min(h * 0.42f, 110.0f);
    ui.rect(id + ".sheen")
        .position(x + 4.0f, y + 4.0f).size(std::max(1.0f, w - 8.0f), std::max(1.0f, sh))
        .radius(std::max(1.0f, radius - 4.0f))
        .gradient(eui::Color{1.0f, 1.0f, 1.0f, light ? 0.34f : 0.05f},
                  eui::Color{1.0f, 1.0f, 1.0f, 0.0f})
        .build();
}

inline eui::GlassStyle cardGlass(const eui::Color& tint) {
    eui::GlassStyle g;
    g.enabled = true;
    g.blur = 12.0f;
    g.saturation = 1.5f;
    g.vibrancy = true;
    g.lensAmount = 8.0f;
    g.lensHeight = 16.0f;
    g.chromaticAberration = 1.0f;
    g.surfaceColor = tint;
    g.highlight = true;
    g.highlightWidth = 1.0f;
    g.highlightBlur = 0.6f;
    g.highlightAlpha = 0.72f;
    g.innerShadow = true;
    g.innerShadowRadius = 4.0f;
    g.innerShadowAlpha = 0.16f;
    g.castShadow = true;
    g.shadowRadius = 18.0f;
    g.shadowOffset = {0.0f, 6.0f};
    g.shadowColor = eui::Color{0.0f, 0.0f, 0.0f, 0.18f};
    return g;
}

// ============================================================ button press spring
// Press grows the capsule by 4dp (LiquidButton.kt: lerp(1, 1+4dp/height, progress)).
// Dragging the finger inside the button makes it follow with a tanh damped offset
// and stretch along the drag direction, then spring back on release.
constexpr float kButtonPressGrow = 0.14f;

struct ButtonPressState {
    bool init = false;
    Spring scale;    // 0 = idle, 1 = fully pressed
    Spring tx;       // horizontal follow offset (dp)
    Spring ty;       // vertical follow offset (dp)
    Spring stretch;  // extra scale contributed by the drag distance
    bool dragSeeded = false;
    float drag0x = 0.0f;
    float drag0y = 0.0f;
    float dragDx = 0.0f;
    float dragDy = 0.0f;
    float dirX = 1.0f;
    float dirY = 0.0f;
    float pixelScale = 1.0f;
};

inline bool buttonPressSettled(const ButtonPressState& s) {
    return s.scale.settled() && s.tx.settled() && s.ty.settled() && s.stretch.settled();
}

// Interaction layer + spring for ad-hoc buttons that build components::button
// directly (the framework only eases pressScale, it has no spring).
// Returns the visual scale the caller should apply to the button.
inline float pressSpring(eui::Ui& ui, const std::string& id, float x, float y, float w, float h,
                         bool enabled, std::function<void()> onClick) {
    ButtonPressState& fx = ui.state<ButtonPressState>(id + ".pressfx");
    if (!fx.init) {
        fx.init = true;
        fx.scale.init(300.0f, 0.5f, 0.0f);
        fx.tx.init(300.0f, 0.62f, 0.0f);
        fx.ty.init(300.0f, 0.62f, 0.0f);
        fx.stretch.init(300.0f, 0.6f, 0.0f);
    }
    auto hit = ui.rect(id + ".press")
        .position(x, y).size(w, h).radius(h * 0.5f)
        .color({0.0f, 0.0f, 0.0f, 0.0f})
        .interactive(enabled)
        .hoverColor(theme().dark ? eui::Color{1.0f, 1.0f, 1.0f, 0.05f}
                                 : eui::Color{1.0f, 1.0f, 1.0f, 0.12f})
        .pressedColor({0.0f, 0.0f, 0.0f, 0.0f})
        .onPress([&fx, w](const eui::PointerEvent&, const eui::Rect& bounds) {
            fx.scale.target = 1.0f;
            fx.dragSeeded = false;
            fx.dragDx = 0.0f;
            fx.dragDy = 0.0f;
            fx.tx.target = 0.0f;
            fx.ty.target = 0.0f;
            fx.stretch.target = 0.0f;
            fx.pixelScale = (w > 0.001f && bounds.width > 0.001f) ? bounds.width / w : 1.0f;
        })
        .onDrag([&fx, w, h](const core::dsl::DragEvent& event) {
            if (!fx.dragSeeded) {
                fx.dragSeeded = true;
                fx.drag0x = static_cast<float>(event.totalX);
                fx.drag0y = static_cast<float>(event.totalY);
            }
            const float inv = (fx.pixelScale > 0.0001f) ? (1.0f / fx.pixelScale) : 1.0f;
            fx.dragDx = (static_cast<float>(event.totalX) - fx.drag0x) * inv;
            fx.dragDy = (static_cast<float>(event.totalY) - fx.drag0y) * inv;
            const float maxOff = std::min(w, h);
            fx.tx.target = maxOff * std::tanh(0.05f * fx.dragDx / maxOff);
            fx.ty.target = maxOff * std::tanh(0.05f * fx.dragDy / maxOff);
            const float len = std::sqrt(fx.dragDx * fx.dragDx + fx.dragDy * fx.dragDy);
            if (len > 0.001f) {
                fx.dirX = fx.dragDx / len;
                fx.dirY = fx.dragDy / len;
            }
            const float maxDragScale = 4.0f / std::max(h, 1.0f);
            fx.stretch.target = maxDragScale * std::min(1.0f, len / std::max(w, h));
        })
        .onRelease([&fx](const eui::PointerEvent&, const eui::Rect&) {
            fx.scale.target = 0.0f;
            fx.tx.target = 0.0f;
            fx.ty.target = 0.0f;
            fx.stretch.target = 0.0f;
        });
    if (enabled && onClick) hit.onClick(std::move(onClick));
    if (!buttonPressSettled(fx)) {
        hit.onFrame([&fx](float dt) {
            fx.scale.advance(dt);
            fx.tx.advance(dt);
            fx.ty.advance(dt);
            fx.stretch.advance(dt);
        });
    }
    hit.build();
    return 1.0f + (4.0f / std::max(h, 1.0f)) * (fx.scale.value + fx.stretch.value);
}


// ============================================================ LiquidTabBar
// Glass track + spring-driven glass pill. Press grows the pill (1.05x), raises its
// refraction strength, drag slides it, release snaps and bounces back.
struct TabBarState {
    bool init = false;
    Spring slide;
    Spring press;
    bool dragging = false;
    bool dragSeeded = false;
    float dragTotal0 = 0.0f;
    float pressBase = 0.0f;
    float pixelScale = 1.0f;
    int pressIndex = 0;
};

inline bool tabSettled(const TabBarState& s) {
    return s.slide.settled() && s.press.settled();
}

inline void tabbar(eui::Ui& ui, const std::string& id, float x, float y, float w, float h,
                   const std::vector<std::string>& labels, int selected,
                   std::function<void(int)> onSelect) {
    const int n = static_cast<int>(labels.size());
    if (n <= 0) return;

    TabBarState& fx = ui.state<TabBarState>(id + ".spring");
    if (!fx.init) {
        fx.init = true;
        fx.slide.init(300.0f, 0.62f, static_cast<float>(selected));
        fx.press.init(300.0f, 0.5f, 0.0f);
        fx.pressIndex = selected;
    }
    if (!fx.dragging) fx.slide.target = static_cast<float>(selected);

    const bool light = !theme().dark;
    const float pad = 4.0f;
    const float segW = (w - pad * 2.0f) / static_cast<float>(n);
    const float innerH = h - pad * 2.0f;
    const float indW = segW - 8.0f;
    const float grow = 1.0f + 0.14f * fx.press.value;
    const float indW2 = indW * grow;
    const float indH2 = innerH * grow;
    const float indX = pad + fx.slide.value * segW + (indW - indW2) * 0.5f;
    const float indY = pad + (innerH - indH2) * 0.5f;
    const int activeIdx = static_cast<int>(std::lround(
        std::clamp(fx.slide.value, 0.0f, static_cast<float>(n - 1))));
    const bool animating = !tabSettled(fx);

    ui.stack(id).position(x, y).size(w, h).content([&] {
            eui::GlassStyle tabTrackGlass;
        tabTrackGlass.enabled = true;
        tabTrackGlass.blur = 8.0f;
        tabTrackGlass.saturation = 1.5f;
        tabTrackGlass.vibrancy = true;
        tabTrackGlass.lensAmount = 5.0f;
        tabTrackGlass.lensHeight = 10.0f;
        tabTrackGlass.surfaceColor = light ? eui::Color{1.0f, 1.0f, 1.0f, 0.22f}
                                          : eui::Color{1.0f, 1.0f, 1.0f, 0.07f};
        tabTrackGlass.highlight = true;
        tabTrackGlass.highlightWidth = 1.0f;
        tabTrackGlass.highlightBlur = 0.5f;
        tabTrackGlass.highlightAlpha = 0.55f;
        tabTrackGlass.innerShadow = true;
        tabTrackGlass.innerShadowRadius = 6.0f;
        tabTrackGlass.innerShadowAlpha = 0.18f;
        ui.rect(id + ".track")
            .size(w, h)
            .radius(h * 0.5f)
            .color(light ? eui::Color{1.0f, 1.0f, 1.0f, 0.52f} : eui::Color{1.0f, 1.0f, 1.0f, 0.12f})
            .border(1.0f, light ? eui::Color{1.0f, 1.0f, 1.0f, 0.90f} : eui::Color{1.0f, 1.0f, 1.0f, 0.16f})
            .build();

        // Sliding highlight pill: real glass. Press raises refraction strength
        // (lensAmount/lensHeight) and the shadow, exactly like LiquidBottomTabs.
        eui::GlassStyle tabIndGlass;
        tabIndGlass.enabled = true;
        tabIndGlass.blur = 9.0f;
        tabIndGlass.saturation = 1.5f;
        tabIndGlass.vibrancy = true;
        tabIndGlass.lensAmount = 4.0f + 26.0f * fx.press.value;
        tabIndGlass.lensHeight = 10.0f + 20.0f * fx.press.value;
        tabIndGlass.chromaticAberration = 1.0f;
        tabIndGlass.surfaceColor = eui::Color{theme().primary.r, theme().primary.g, theme().primary.b,
                                             (light ? 0.72f : 0.66f) + 0.18f * fx.press.value};
        tabIndGlass.highlight = true;
        tabIndGlass.highlightWidth = 1.2f;
        tabIndGlass.highlightBlur = 0.7f;
        tabIndGlass.highlightAlpha = 0.85f;
        tabIndGlass.highlightColor = eui::Color{0.55f, 0.56f, 0.62f, 1.0f};
        tabIndGlass.highlightColor2 = eui::Color{0.97f, 0.98f, 1.0f, 1.0f};
        tabIndGlass.innerShadow = true;
        tabIndGlass.innerShadowRadius = 4.0f;
        tabIndGlass.innerShadowAlpha = 0.20f;
        tabIndGlass.castShadow = true;
        tabIndGlass.shadowRadius = 12.0f + 8.0f * fx.press.value;
        tabIndGlass.shadowOffset = {0.0f, 2.0f + 3.0f * fx.press.value};
        tabIndGlass.shadowColor = eui::Color{0.0f, 0.0f, 0.0f, light ? 0.16f : 0.30f};
        ui.rect(id + ".ind")
            .position(indX, indY)
            .size(indW2, indH2)
            .radius(indH2 * 0.5f)
            .color(theme().primary)
            .border(1.4f, eui::Color{1.0f, 1.0f, 1.0f, 0.42f})
            .shadow(10.0f + 8.0f * fx.press.value, 0.0f, 2.0f + 3.0f * fx.press.value,
                    eui::Color{0.0f, 0.0f, 0.0f, light ? 0.20f : 0.34f})
            .build();


        for (int i = 0; i < n; ++i) {
            const float sx = pad + static_cast<float>(i) * segW;
            const bool on = (i == activeIdx);
            ui.text(id + ".label." + std::to_string(i))
                .position(sx, (h - 18.0f * (1.0f + 0.10f * fx.press.value)) * 0.5f)
                .size(segW, 18.0f)
                .text(labels[static_cast<std::size_t>(i)])
                .fontSize(13.5f * (1.0f + 0.10f * fx.press.value))
                .lineHeight(18.0f)
                .fontWeight(on ? 760 : 620)
                .horizontalAlign(eui::HorizontalAlign::Center)
                .color(on ? eui::Color{1.0f, 1.0f, 1.0f, 1.0f} : textPrimary())
                .build();
        }

        // ?????????????в??????????е?? + ???????????????? slide ????
        auto hit = ui.rect(id + ".hit")
            .size(w, h)
            .radius(h * 0.5f)
            .color({0.0f, 0.0f, 0.0f, 0.0f})
            .interactive(true)
            .hoverColor(hoverTint())
            .pressedColor(pressedTint())
            .onPress([&fx, n, pad, segW, w, onSelect](const eui::PointerEvent& event, const eui::Rect& bounds) {
                fx.press.target = 1.0f;
                fx.dragging = false;
                fx.dragSeeded = false;
                fx.dragTotal0 = 0.0f;
                fx.pixelScale = (w > 0.001f && bounds.width > 0.001f) ? bounds.width / w : 1.0f;
                // Segment i spans [i*segW, (i+1)*segW): use FLOOR, not round.
                // Rounding made the right half of each segment pick the next one,
                // which is exactly what looked like "the click did not select".
                const float localDp = static_cast<float>(event.x - bounds.x) / fx.pixelScale;
                int hitIndex = static_cast<int>(std::floor((localDp - pad) / segW));
                if (hitIndex < 0) hitIndex = 0;
                if (hitIndex > n - 1) hitIndex = n - 1;
                fx.pressIndex = hitIndex;
                // press: highlight pill springs to the finger at once (click and drag both start here)
                fx.pressBase = static_cast<float>(fx.pressIndex);
                fx.slide.target = fx.pressBase;
                // Click anywhere in the bar selects immediately (no need to wait for release).
                if (onSelect) onSelect(fx.pressIndex);
            })
            .onDrag([&fx, n, segW](const core::dsl::DragEvent& event) {
                if (!fx.dragSeeded) {
                    fx.dragSeeded = true;
                    fx.dragTotal0 = static_cast<float>(event.totalX);
                }
                const float dp = (static_cast<float>(event.totalX) - fx.dragTotal0) / fx.pixelScale;
                if (!fx.dragging && std::fabs(dp) >= 3.0f) {
                    fx.dragging = true;
                    fx.pressBase = static_cast<float>(fx.pressIndex);
                }
                if (fx.dragging) {
                    fx.slide.target = std::clamp(fx.pressBase + dp / segW,
                                                 0.0f, static_cast<float>(n - 1));
                }
            })
            .onRelease([&fx, n, onSelect](const eui::PointerEvent&, const eui::Rect&) {
                fx.press.target = 0.0f;
                int idx = fx.pressIndex;
                if (fx.dragging) {
                    idx = static_cast<int>(std::lround(std::clamp(fx.slide.target,
                                                                  0.0f,
                                                                  static_cast<float>(n - 1))));
                }
                const bool changed = (idx != fx.pressIndex);
                fx.slide.target = static_cast<float>(idx);
                fx.dragging = false;
                fx.pressIndex = idx;
                // Press already committed the selection (instant response); only a drag that
                // landed on another segment needs a second commit here.
                if (onSelect && changed) onSelect(idx);
            });
        // ??????????? onFrame?????????????????????
        if (animating) {
            hit.onFrame([&fx](float dt) {
                fx.slide.advance(dt);
                fx.press.advance(dt);
            });
        }
        hit.build();
    }).build();
}

}  // namespace liquid

}  // namespace app
